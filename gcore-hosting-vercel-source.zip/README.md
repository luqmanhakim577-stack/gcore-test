# Gcore hosting website

Next.js (App Router) + TypeScript + Tailwind. **BILLmanager 6 is the single source of truth** for prices,
billing periods, specs, locations, add-ons and order URLs. Nothing commercial is hardcoded.

Design and decisions: [ARCHITECTURE.md](ARCHITECTURE.md). Status: Phases 0-7 done (see the table below).
What only the owner can supply: [docs/OWNER-FACTS.md](docs/OWNER-FACTS.md). Going live: [docs/LAUNCH.md](docs/LAUNCH.md).

## How commercial data flows

```
calc feed (index)  ─┐
                    ├─ sync ─ normalize ─ reconcile ─ validate ─▶ snapshot (Redis) ─▶ pages + /api/v1
BILLmanager         ─┘                                              ▲
pricelist.export                              POST /api/internal/sync (HMAC) · 10-min scheduler
```

- **calc feed** (`hosting-calc-prod.i.gc.onl`): complete index of plans. Cheap, but it can drift from BILLmanager.
- **BILLmanager `pricelist.export`**: authoritative per-plan detail, order links, add-ons. Public function, no credentials.
- When the two disagree, **BILLmanager wins** and the plan is flagged (`price-mismatch`).
- Pages/API read only the stored snapshot, never BILLmanager at request time.

## Commands

```bash
npm install
npm run catalog:sync      # fetch live data into .cache/catalog.json (dev) or Redis (REDIS_URL)
npm run catalog:report    # data-quality report: what in BILLmanager needs attention
npm run dev               # http://localhost:3000, API at /api/v1/plans
npm test                  # unit + contract + API + security + page-render tests (recorded real responses)
npm run build             # runs a catalog sync first (prebuild), then pre-renders every page from the snapshot
npm run test:ssr          # after a build: asserts on the pre-rendered HTML files (prices, links, SEO basics)
npm run typecheck
npm run check:replicas    # after a build: two real replicas + Redis, proves they follow each other (REDIS_URL optional)
npm run fixtures:capture  # re-record real upstream responses into tests/fixtures
```

## Configuration

See [.env.example](.env.example). Production requires `REDIS_URL`, `REVALIDATE_HMAC_SECRET` (>= 32 chars) and an https
`SITE_URL`, and refuses to start without them. Set `TRUSTED_PROXY_HOPS` to the number of proxies in front of the app.
No BILLmanager credentials are used or needed.

## Endpoints

| Endpoint | Auth | Purpose |
|---|---|---|
| `GET /api/v1/plans` `?kind&location&currency&include=unverified&limit&offset` | public, rate limited, ETag | machine-readable catalog; verified plans only by default |
| `GET /api/v1/plans/{id}` | public | one plan (labelled `verified: false` when BILLmanager did not confirm it) |
| `GET /api/v1/locations` | public | locations and products per location |
| `GET /api/v1/openapi.json` | public | OpenAPI 3.1 contract, generated from the schemas the handlers and tests use |
| `GET /llms.txt`, `/llms-full.txt` | public | machine-readable site index and full catalog + guides, rendered from the snapshot |
| `GET /api/health` | public | snapshot age only; no plan data |
| `POST /api/internal/sync` `{force?}` | HMAC | run a sync, revalidate exactly the changed tags |
| `POST /api/internal/revalidate` `{tags[], scope?}` | HMAC | manual invalidation; `scope: "fleet"` (default) revalidates this replica and announces to the others, `"local"` this replica only. Tags: `site`, `catalog`, `kind:{vps\|dedicated}`, `location:{slug}`, `plan:{id}`, `group:{kind}:{slug}` |

Internal requests are signed: `HMAC-SHA256(secret, "{timestamp}.{nonce}.{METHOD}.{path}.{body}")` in headers
`x-timestamp`, `x-nonce`, `x-signature` (see `src/lib/security/hmac.ts`). 5-minute window, one-time nonce.

## SEO decisions (Phase 4)

- **Canonical + hreflang:** every page is self-canonical (never with a query) with `en` and `x-default`
  alternates. Add a locale to `src/lib/seo/config.ts` and translated content to get hreflang everywhere.
- **URL variants:** `?period=`, `?utm_*`, `?sort=` and any other query never become indexed pages. The middleware
  answers them with `X-Robots-Tag: noindex, follow` and a canonical `Link` header. They are deliberately **not**
  blocked in robots.txt, because a blocked URL cannot show its canonical.
- **Structured data** comes from the same normalized objects and the same `specRows()` as the visible HTML, so
  markup and page cannot drift. `Product` carries one `Offer` per billing period (they are different purchases, not
  a price range), with `billingDuration` in months. `Offer.url` is the plan's canonical page, where the offer is
  shown; the BILLmanager order link is in the HTML. Markup is emitted only for confirmed, orderable plans.
- **Sitemap:** one file (about 400 URLs). `lastmod` is the last real content change of the plans on the page
  (`source.changedAt`), not the sync time. Withheld plans, USD twins and noindex pages are never listed.
- **Not done on purpose:** `AggregateRating`/reviews (no data), Organization address/contact/legal name (not in any
  data source: needs the owner). `FAQPage` exists only on the guides, where the Q&A is visible (Phase 6).
- Structured data is validated by our own rules in CI. It has **not** been run through Google's Rich Results Test
  or Search Console, which need the public site. Valid markup does not guarantee rich results or AI citations.

## Configurator (Phase 5)

What it offers is limited to what BILLmanager's data and documentation actually support
(`src/lib/catalog/configurator.ts`):

| Option | Source rule | Verified how |
|---|---|---|
| Extra IPv4 / IPv6 addresses | "Based on order", integer, pieces. `addonlimit` ("Tariff plan includes") is in the plan price; each further step costs the add-on's period price | docs; 337 IPv4 add-ons all included=1, step 1; prices linear in the period except 3 rounding cases (BILLmanager's period price is always used) |
| Dedicated traffic tier | single-choice children of the parent traffic add-on (linked by add-on type id); the zero-priced tier is what the plan includes; the others are surcharges | docs ("Client can choose"); every one of 151 dedicated plans has exactly one included tier |
| *Not offered:* VPS disk / RAM / vCPU | billed as "Do not bill": fixed to the plan | all 180 VPS plans: included quantity == the plan's own spec (units are GiB or MiB per plan, converted) |
| *Not offered:* OS, Windows / MSSQL licences, burst-billed "unlimited traffic" | names only / price meaning unclear | tests assert they are never offered |

The total shown is **an estimate** (plan period price + selected extras at BILLmanager period prices); the order
page is authoritative.

**Order prefill is OFF (`ORDER_ADDON_PARAMS=off`).** With it on, links carry `addon_<id>=<qty>` (and
`addon_<parentId>=<choiceId>` for traffic) appended inside BILLmanager's own `redirect` value. Verified: our
encoding reproduces BILLmanager's own links byte for byte, and the register page echoes the appended pair back in
its parsed redirect. **Not verified:** that the order form, after login, pre-selects the options. That needs one
real test order by someone with an account (this project never creates accounts or logs in). To verify:
1. set `ORDER_ADDON_PARAMS=on` in a staging environment and revalidate (`POST /api/internal/revalidate {"tags":["catalog"]}`);
2. on a plan page choose 3 IPv4 addresses, click Order, log in, and check the order form shows 3 addresses and the
   same total as the estimate; repeat for a dedicated traffic tier;
3. if they match, enable it in production; if not, leave it off (the page then tells the customer which options to add).

## AEO / GEO (Phase 6)

What is machine-readable, and where each piece comes from:

| Piece | Source | Guard |
|---|---|---|
| `/api/v1/openapi.json` | zod schemas in `src/lib/api/schemas.ts`, shared with the handlers | tests parse every real response with the schemas (`.strict()`); validated with swagger-parser |
| `/llms.txt`, `/llms-full.txt` | the catalog snapshot (listed plans only) and the guides | build-output tests: every listed plan present with identical prices, nothing withheld, USD or order URL, every link resolves to a pre-rendered page |
| `/learn/*` guides and glossary | `src/content/learn.ts` (general industry explanations) | `tests/content/claims.test.ts`: no absolute marketing claims, no first-person capability claims, no named third-party providers or certifications |
| Catalog numbers inside the guides | computed at render time from the snapshot (`src/lib/aeo/learn-data.ts`) | build-output tests compare them with the snapshot |
| Facts about Gcore's own infrastructure | `src/content/facts.ts`, **empty** until the owner supplies sourced facts | schema requires scope, evidence level, source and date |

Rules the generated files state for machines: a price is for the whole billing period; a missing spec is unknown, never
zero; port speed is not a throughput guarantee; unmetered is not unlimited use; DDoS scope, SLA, CPU model and allocation,
network and upstreams, data center operators and support terms are **not stated** by this site, and their absence is not
evidence either way.

Honest limits: `llms.txt` is a convention that some tools read, `FAQPage` rich results are restricted by Google to a few
site types, and none of this guarantees that any assistant cites or recommends the site. Nothing here has been measured
against real AI-assistant traffic: the site is not public yet.

## Snapshot schema

`CATALOG_SCHEMA` (model.ts) must be bumped whenever stored plan fields change. A snapshot with another schema is
never reused: the next sync refetches all BILLmanager detail, and page-data cache keys change with it (Next persists
its data cache in `.next/cache`; during development delete `.next` after changing data shapes).

## Cache tags

`plan:{id}` · `location:{slug}` · `kind:{vps|dedicated}` · `group:{kind}:{slug}` · `catalog` · `site` (everything; on every
cached loader, used by a replica that booted from an older snapshot). A sync revalidates only the tags of plans whose
content hash changed.

## Status

| Phase | State |
|---|---|
| 0 Scaffold, env validation, Docker | done (Docker files written, not built on this machine: Docker not installed) |
| 1 BILLmanager integration, normalization, reconciliation, quality flags | done, 72 contract/price/period tests on real recordings |
| 2 Snapshot store, sync, tag revalidation, public API, HMAC, rate limiting | done, 106 tests total; verified over real HTTP |
| 3 Pages: home, VPS and dedicated hubs, location pages with comparison tables, plan pages, locations, no-JS period selector, order buttons | done: 390 pages pre-rendered (SSG + ISR), 136 unit tests + 6 build-output tests, checked in a browser at 375/768/1280 px |
| 4 SEO layer: sitemap.xml (real lastmod), robots.txt, canonical + hreflang, Open Graph, JSON-LD (Organization, WebSite, BreadcrumbList, ItemList, Product + Offer per billing period), noindex for URL variants, 404 | done: 161 unit tests + 17 build-output tests (every JSON-LD block validated, prices in markup equal the snapshot) |
| 5 Configurator (extra IPv4/IPv6 addresses, dedicated traffic tier), option price tables, order-link builder | done: 190 unit/component tests + 19 build-output tests; all 330 listed plans configurable; checked in a browser. **Order prefill (`addon_N`) is unverified and switched off**, see below |
| 6 AEO: llms.txt, llms-full.txt, OpenAPI, six guides + glossary with Q&A, facts registry | done: 228 unit/component tests + 33 build-output tests; 395 HTML pages pre-rendered. Everything about Gcore's own network, DDoS, SLA and CPU policy waits for owner facts (`docs/OWNER-FACTS.md`) |
| 7 Hardening, performance, mobile QA, launch checklist | done, with three items that need a real Redis, Docker and the public site: see [docs/LAUNCH.md](docs/LAUNCH.md) |

Known gaps: 6 EUR plans whose calc-feed price disagrees with BILLmanager, and plan 176811, are withheld from the
site until the owner confirms the correct price.

Not verified: the Redis code paths against a **real** Redis (they are tested against an in-repo fake and, end to end,
against a wire-protocol stand-in), the Docker image, CDN behaviour, Google's Rich Results Test and Core Web Vitals
field data. [docs/LAUNCH.md](docs/LAUNCH.md) says how to close each.

## Design

Matches the live gcore.hosting landing page (measured 2026-11-02): aubergine `#1E1224` with a violet glow, Montserrat
(self-hosted in `public/fonts`, OFL), the brand gradient `#FF9A70 → #FF4C00 → #FFBC9F` on pill buttons and plan-name pills,
white-bordered plan cards with a white price box and large orange price, orange triangle bullets, two-tone headings, a
floating white header bar and a light footer band. Tokens and component classes (`.btn`, `.plan-card`, `.panel`, `.glass`,
`.pill`, `.price-box`, `.tri-list`, `.stat`, `.qa`, `.dtable`) are in `src/app/globals.css`.

Deliberate differences from the live page: the button gradient core is `#E04300` instead of `#FF4C00` so white button text
meets WCAG AA (4.8:1 instead of 3.5:1); no hero artwork (raster assets were not copied); none of the live page's
capability claims ("Free CDN & DDoS Protection", "99.99% uptime", "Tier III/IV") or promotional prices are repeated,
because no data source states them (docs/OWNER-FACTS.md); FAQ answers stay open (FAQPage markup is only emitted where the
Q&A is visible). The font uses `font-display: optional` with a preload, so a late font never shifts the layout.

## Hardening and operations (Phase 7)

- **CSP and headers** (`next.config.ts`): static CSP (a nonce would make every page dynamic; see ARCHITECTURE.md update 11),
  HSTS, COOP, frame denial, `Permissions-Policy`. Machine-readable responses get `default-src 'none'` and open `GET` CORS.
  Tests: `tests/security/headers.test.ts` (config) and `tests/ssr/security-output.test.ts` (every built page).
- **Replicas**: a sync announces its changed tags in a Redis stream; every replica replays it and revalidates its own cache;
  a replica built from an older snapshot revalidates everything once at boot. `npm run check:replicas` proves it with real
  servers (against `REDIS_URL`, or a bundled stand-in without it).
- **Fixed on the way**: `revalidateTag` throws outside a request, so the in-process scheduler never refreshed the page cache
  (now applied through a signed loopback call); the live snapshot in Redis expired after 7 days without a successful sync (now
  no expiry); the rate limiter trusted the left-most, client-supplied `X-Forwarded-For` entry (now `TRUSTED_PROXY_HOPS`);
  a missing favicon returned 404 on every visit; `next`'s nested PostCSS had two advisories (`npm audit`: 0 now).
- **Startup validation**: production refuses to start without `REDIS_URL`, `REVALIDATE_HMAC_SECRET` and an https `SITE_URL`.
- **Performance** (`tests/ssr/budgets.test.ts`): 118 KB gzip JS per route, 8 KB CSS, 24 KB gzip HTML, nothing render-blocking.
  Measured: about 107 KB JS (React and Next runtime), 4 KB CSS, at most 16 KB HTML; Lighthouse mobile 97-99 performance,
  100 accessibility / best practices / SEO, CLS 0, LCP 1.6-2.0 s (local server, simulated slow connection).
- **Touch targets**: buttons, navigation and breadcrumb links are at least 44 px high on phones.
