import { readFileSync } from 'node:fs';
import path from 'node:path';
import type { NextConfig } from 'next';

const isDev = process.env.NODE_ENV === 'development';

/**
 * Content Security Policy. A nonce-based policy would be stricter for scripts, but Next can only apply a nonce
 * while rendering a request, so every page would become dynamic: no static generation or ISR, no CDN caching
 * (Next documents this trade-off). This site renders no user-supplied content and has no cookies, accounts or
 * forms that change state, so the architecture keeps pages static and uses a policy that still shuts the
 * channels that matter here: no plugins, no <base> hijack, no framing, no third-party origins for anything,
 * no connections to other hosts. `'unsafe-inline'` for scripts is needed for the inline bootstrap Next writes
 * into each static page. The residual risk (injected inline script) is handled where it would start: the only
 * dangerouslySetInnerHTML is JSON-LD, escaped by serializeLd, and tests scan every pre-rendered page.
 */
export const CSP_DIRECTIVES: Record<string, string[]> = {
  'default-src': ["'self'"],
  'script-src': ["'self'", "'unsafe-inline'", ...(isDev ? ["'unsafe-eval'"] : [])],
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': ["'self'", 'data:'],
  'font-src': ["'self'"],
  'connect-src': ["'self'", ...(isDev ? ['ws:', 'wss:'] : [])],
  'manifest-src': ["'self'"],
  'frame-src': ["'none'"],
  'object-src': ["'none'"],
  'base-uri': ["'none'"],
  'form-action': ["'self'"],
  'frame-ancestors': ["'none'"],
  ...(isDev ? {} : { 'upgrade-insecure-requests': [] }),
};

export const serializeCsp = (d: Record<string, string[]>) =>
  Object.entries(d)
    .map(([name, values]) => [name, ...values].join(' '))
    .join('; ');

/** Machine-readable responses are never rendered: they get the most restrictive policy. */
const DATA_CSP = "default-src 'none'; base-uri 'none'; frame-ancestors 'none'";

export const baseSecurityHeaders = [
  { key: 'Content-Security-Policy', value: serializeCsp(CSP_DIRECTIVES) },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
  { key: 'X-Permitted-Cross-Domain-Policies', value: 'none' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), browsing-topics=()' },
  // Not "preload": that is a long-lived commitment for the whole domain, to be made deliberately (docs/LAUNCH.md).
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains' },
];

/** Public, read-only data may be fetched from any origin (browser-based tools, agents). Nothing here uses cookies. */
const publicDataHeaders = [
  { key: 'Content-Security-Policy', value: DATA_CSP },
  { key: 'Access-Control-Allow-Origin', value: '*' },
  { key: 'Access-Control-Allow-Methods', value: 'GET, HEAD, OPTIONS' },
];

/** Which snapshot this build rendered its pages from; a replica compares it with the live one at boot. */
function buildCatalogId(): string {
  try {
    const info = JSON.parse(readFileSync(path.join(process.cwd(), '.cache', 'build-info.json'), 'utf8')) as { catalogId?: string };
    return info.catalogId ?? 'none';
  } catch {
    return 'none';
  }
}

const config: NextConfig = {
  output: 'standalone',
  poweredByHeader: false,
  serverExternalPackages: ['ioredis', 'pino'],
  reactStrictMode: true,
  env: { BUILD_CATALOG_ID: buildCatalogId() },
  async headers() {
    return [
      { source: '/:path*', headers: baseSecurityHeaders },
      // Later rules override earlier ones for the same header key.
      { source: '/api/v1/:path*', headers: publicDataHeaders },
      { source: '/llms.txt', headers: publicDataHeaders },
      { source: '/llms-full.txt', headers: publicDataHeaders },
      { source: '/api/:path*', headers: [{ key: 'X-Robots-Tag', value: 'noindex' }] },
      // Next's default for ISR pages is "stale-while-revalidate=31532400": a CDN honouring it could serve a price
      // that is months old to the first visitor after an idle spell. Keep stale reuse to a minute.
      {
        source: '/((?!api/|_next/|llms).*)',
        headers: [{ key: 'Cache-Control', value: 'public, s-maxage=600, stale-while-revalidate=60' }],
      },
      // Font files carry their version in the name, so they never change in place.
      { source: '/fonts/:file*', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
    ];
  },
};

export default config;
