import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  // Vitest 5 transforms with oxc; Next's tsconfig uses jsx: "preserve", so ask for the automatic runtime.
  oxc: { jsx: { runtime: 'automatic' } },
  test: {
    environment: 'node',
    // Tests that normalize the full recorded catalog take ~4 s alone; the 5 s default fails them on a busy CI runner.
    testTimeout: 30_000,
    include: ['tests/**/*.test.{ts,tsx}'],
    exclude: ['tests/ssr/**', 'node_modules/**'],
  },
});
