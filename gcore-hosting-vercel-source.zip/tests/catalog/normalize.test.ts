import { beforeAll, describe, expect, it } from 'vitest';
import { parseCalcFeed } from '@/lib/billmanager/calc-feed';
import { parsePricelistExport } from '@/lib/billmanager/pricelist';
import { buildCatalog } from '@/lib/catalog/build';
import { isTrustworthy, type Catalog, type Plan } from '@/lib/catalog/model';
import { crossCheckIncludedResources } from '@/lib/catalog/normalize';
import { withheldSpecs } from '@/lib/format';
import { PERIODS, type PeriodKey } from '@/lib/catalog/money';
import type { S2State } from '@/lib/catalog/normalize';
import { fixture, HIDDEN_ID, S2_RECORDED_IDS } from '../helpers/upstream';

const BM = 'https://hosting.gcore.com';
const NOW = '2026-11-01T12:00:00.000Z';

const vpsFeed = parseCalcFeed('vps', fixture('calc-vps.json'), NOW);
const dedFeed = parseCalcFeed('dedicated', fixture('calc-dedicated.json'), NOW);

function s2States(): Map<string, S2State> {
  const m = new Map<string, S2State>();
  for (const id of S2_RECORDED_IDS) {
    const r = parsePricelistExport(fixture(`s2-${id}.json`));
    if (!r.ok) throw new Error('fixture must parse');
    m.set(id, { status: 'ok', plan: r.plans[0]!, at: NOW });
  }
  m.set(HIDDEN_ID, { status: 'not-public', at: NOW });
  return m;
}

let catalog: Catalog;
const byId = (id: string): Plan => {
  const p = catalog.plans.find((x) => x.id === id);
  if (!p) throw new Error(`plan ${id} missing`);
  return p;
};

beforeAll(() => {
  catalog = buildCatalog({
    feeds: [vpsFeed, dedFeed].map((f) => ({ kind: f.kind, rows: f.rows, fetchedAt: NOW })),
    s2: s2States(),
    billmanagerBaseUrl: BM,
    version: 1,
    now: NOW,
  });
});

describe('price accuracy', () => {
  it('every plan price equals the source value for every period (decimal strings, no float drift)', () => {
    for (const feed of [vpsFeed, dedFeed]) {
      for (const row of feed.rows) {
        const plan = byId(row.id);
        if (plan.flags.some((f) => f.code === 'price-mismatch')) continue; // BILLmanager wins; covered below
        const src = row.server_price;
        const expected: Record<PeriodKey, number> = {
          monthly: src.monthly,
          quarterly: src.quarterly,
          semiannually: src.semiannually,
          annually: src.annually,
        };
        for (const k of PERIODS) {
          expect(Number(plan.prices[k].amount), `${row.id}/${k}`).toBeCloseTo(expected[k], 6);
          expect(plan.prices[k].amount).toMatch(/^\d+\.\d{2,4}$/);
          expect(plan.prices[k].currency).toBe(src.currency);
        }
      }
    }
  });

  it('recorded BILLmanager plans: calc feed and BILLmanager agree to the cent', () => {
    for (const id of S2_RECORDED_IDS) {
      const p = byId(id);
      expect(p.flags.filter((f) => f.code === 'price-mismatch'), id).toEqual([]);
    }
  });

  it('known example matches the live numbers captured on 2026-11-01', () => {
    const p = byId('170193');
    expect(p.name).toBe('KVM-HIGHCPU-SSD-4-ANX');
    expect(p.prices.monthly.amount).toBe('59.99');
    expect(p.prices.quarterly.amount).toBe('170.97');
    expect(p.prices.semiannually.amount).toBe('323.95');
    expect(p.prices.annually.amount).toBe('575.90');
    expect(p.currency).toBe('EUR');
  });

  it('per-month equivalents are derived from, and never replace, the period price', () => {
    const p = byId('170193');
    expect(p.perMonthEquiv.annually.amount).toBe('47.99'); // 575.90 / 12
    expect(p.prices.annually.amount).toBe('575.90');
  });
});

describe('billing period accuracy', () => {
  it('order links exist per period and carry that period and plan id', () => {
    const months: Record<PeriodKey, string> = { monthly: '1', quarterly: '3', semiannually: '6', annually: '12' };
    for (const id of S2_RECORDED_IDS) {
      const p = byId(id);
      expect(Object.keys(p.order.byPeriod).sort(), id).toEqual([...PERIODS].sort());
      for (const k of PERIODS) {
        const inner = new URLSearchParams(new URL(p.order.byPeriod[k]!).searchParams.get('redirect')!);
        expect(inner.get('period')).toBe(months[k]);
        expect(inner.get('pricelist')).toBe(id);
      }
    }
  });
});

describe('availability and order links', () => {
  it('plans confirmed by BILLmanager are orderable with a validated link', () => {
    const p = byId('170193');
    expect(p.availability).toBe('orderable');
    expect(p.order.base).toMatch(/^https:\/\/hosting\.gcore\.com\/billmgr\?func=register/);
  });

  it('a plan BILLmanager does not expose is "unknown" and has no order link', () => {
    const p = byId(HIDDEN_ID);
    expect(p.availability).toBe('unknown');
    expect(p.order.byPeriod).toEqual({});
    expect(p.flags.map((f) => f.code)).toContain('no-s2');
  });

  it('plans not requested from BILLmanager (USD, not attempted) are never orderable', () => {
    const notAsked = catalog.plans.filter((p) => !s2States().has(p.id));
    expect(notAsked.length).toBeGreaterThan(500);
    expect(notAsked.every((p) => p.availability === 'unknown' && Object.keys(p.order.byPeriod).length === 0)).toBe(true);
  });
});

describe('data-quality detection (real anomalies in BILLmanager, ARCHITECTURE.md 2.2)', () => {
  it('flags dedicated 176811: quarterly price above 3 x monthly', () => {
    const p = byId('176811');
    expect(p.flags.find((f) => f.code === 'period-price-anomaly')?.severity).toBe('error');
    expect(isTrustworthy(p)).toBe(false);
    // prices are published as BILLmanager states them, never "fixed"
    expect(p.prices.monthly.amount).toBe('693.00');
    expect(p.prices.quarterly.amount).toBe('3087.00');
  });

  it('flags the VPS plans with no period discount when their peers all have one', () => {
    for (const id of ['170274', '176572', '176665']) {
      expect(byId(id).flags.map((f) => f.code), id).toContain('missing-period-discount');
    }
    expect(byId('170193').flags.map((f) => f.code)).not.toContain('missing-period-discount');
  });

  it('flags plans published in one currency only', () => {
    const singles = catalog.plans.filter((p) => p.flags.some((f) => f.code === 'no-currency-twin'));
    expect(singles).toHaveLength(6);
    expect(singles.every((p) => p.kind === 'dedicated')).toBe(true);
  });

  it('clean plans are trustworthy', () => {
    expect(isTrustworthy(byId('170193'))).toBe(true);
    expect(isTrustworthy(byId('145809'))).toBe(true);
  });

  it('error-flagged plans are the minority and every one is explained', () => {
    const errors = catalog.plans.filter((p) => !isTrustworthy(p));
    expect(errors.map((p) => p.id)).toEqual(['176811']);
  });
});

describe('specs', () => {
  it('no real row has an unparseable spec string', () => {
    const bad = catalog.plans.flatMap((p) =>
      p.flags.filter((f) => f.code === 'spec-unparsed').map((f) => `${p.id} ${p.name}: ${f.message}`),
    );
    expect(bad).toEqual([]);
  });

  it('parses VPS specs and takes the disk type from BILLmanager text, not the plan name', () => {
    const p = byId('170193');
    expect(p.specs).toMatchObject({ vcpu: 12, ramMiB: 24 * 1024, portMbps: 200, traffic: { kind: 'unlimited' } });
    expect(p.specs.disks).toEqual([{ count: 1, sizeGB: 500, type: 'SSD', typeSource: 'billmanager' }]);
    expect(p.flags.filter((f) => f.code === 'spec-mismatch')).toEqual([]);
  });

  it('BILLmanager\'s included disk/RAM/vCPU agree with the feed on recorded plans, in GiB or MiB', () => {
    for (const id of ['170193', '173283', '170158']) {
      expect(byId(id).flags.filter((f) => f.code === 'addon-spec-mismatch'), id).toEqual([]);
    }
  });

  it('flags a feed/billing disagreement and withholds that spec', () => {
    const add = (name: string, included: number, unit: string) => ({ id: '1', name, billType: '1', included, unit, prices: {} });
    const flags: Plan['flags'] = [];
    crossCheckIncludedResources(
      [add('Disk space', 102400, 'MiB'), add('RAM', 4096, 'MiB'), add('CPU number', 6, 'pcs')],
      { vcpu: 8, ramMiB: 4096, disks: [{ count: 1, sizeGB: 100, type: 'SSD', typeSource: 'billmanager' }] },
      flags,
    );
    expect(flags.map((f) => f.message)).toEqual(['vCPU: calc feed 8 vs BILLmanager included resource 6']); // 102400 MiB == 100 GiB: no flag
    expect([...withheldSpecs({ flags })]).toEqual(['vcpu']);
  });

  it('handles MB RAM and Gb-style units on the same plan family', () => {
    expect(byId('173283').specs.ramMiB).toBe(1024);
  });

  it('parses dedicated specs including GPU, multi-group disks and metered traffic', () => {
    const p = byId('145809');
    expect(p.kind).toBe('dedicated');
    expect(p.specs.gpu).toBe('2xNVTT4');
    expect(p.specs.cpuModel).toBe('Silver-4208');
    expect(p.specs.cpuSockets).toBe(1);
    expect(p.specRaw['connection_speed']).toBe('10 Gbps'); // plan name carries 2x10GbE; feed agrees
    expect(p.specs.portMbps).toBe(10000);
    expect(p.specs.traffic?.kind).toBe('metered');
    expect(p.specRaw['hdd']).toBe('2x240SSD');
  });

  it('never treats the calc feed os_price as a public price (meaning unconfirmed, D3)', () => {
    const p = byId('170193');
    expect(p.osPriceUnconfirmed?.monthly.amount).toBe('25.00');
    expect(Object.keys(p)).not.toContain('osPrice');
  });
});

describe('locations', () => {
  it('derives slugs from the city (or country for bare "DC n")', () => {
    const ids = new Set(catalog.locations.map((l) => l.id));
    for (const id of ['ashburn', 'frankfurt', 'sao-paulo', 'hong-kong', 'amsterdam', 'luxembourg', 'tel-aviv']) {
      expect(ids.has(id), id).toBe(true);
    }
    const lux = catalog.locations.find((l) => l.id === 'luxembourg')!;
    expect(lux).toMatchObject({ country: 'Luxembourg', city: 'Luxembourg', dcLabel: 'DC 2', kinds: ['dedicated'] });
  });

  it('each location has exactly one BILLmanager code per product kind', () => {
    const codes = new Map<string, Set<string>>();
    for (const p of catalog.plans) {
      const key = `${p.locationId}/${p.kind}`;
      (codes.get(key) ?? codes.set(key, new Set()).get(key)!).add(p.name.split('-').at(-1)!);
    }
    const multi = [...codes.entries()].filter(([, s]) => s.size > 1).map(([k, s]) => `${k}: ${[...s].join(',')}`);
    expect(multi).toEqual([]);
  });

  it('records when VPS and dedicated use different codes for one city (Sao Paulo: SP3 vs ASP5)', () => {
    const sp = catalog.locations.find((l) => l.id === 'sao-paulo')!;
    expect(sp.codes).toEqual({ vps: 'SP3', dedicated: 'ASP5' });
    const ash = catalog.locations.find((l) => l.id === 'ashburn')!;
    expect(ash.codes).toEqual({ vps: 'ANX', dedicated: 'ANX' });
  });

  it('every plan references an existing location', () => {
    const ids = new Set(catalog.locations.map((l) => l.id));
    expect(catalog.plans.every((p) => ids.has(p.locationId))).toBe(true);
  });

  it('plan slugs are unique per kind, location and currency', () => {
    const seen = new Set<string>();
    for (const p of catalog.plans) {
      const key = `${p.kind}|${p.locationId}|${p.currency}|${p.slug}`;
      expect(seen.has(key), key).toBe(false);
      seen.add(key);
    }
  });
});
