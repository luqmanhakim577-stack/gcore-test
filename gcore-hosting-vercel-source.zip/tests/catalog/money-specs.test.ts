import { describe, expect, it } from 'vitest';
import {
  parseCpu,
  parseDedicatedDisks,
  parsePortMbps,
  parseRamMiB,
  parseTraffic,
  parseVcpu,
  parseVpsDescription,
  parseVpsDiskGB,
} from '@/lib/billmanager/specs';
import { normalizeAmount, perMonth, savingPercent, toMoney } from '@/lib/catalog/money';
import { slugify } from '@/lib/catalog/hash';

describe('money', () => {
  it('uses decimal strings without float artefacts', () => {
    expect(normalizeAmount(0.1 + 0.2)).toBe('0.30');
    expect(normalizeAmount(59.99)).toBe('59.99');
    expect(normalizeAmount('170.9700')).toBe('170.97');
    expect(normalizeAmount('0.0013')).toBe('0.0013');
    expect(normalizeAmount(2.4)).toBe('2.40');
    expect(normalizeAmount('0')).toBe('0.00');
  });
  it('rejects non-finite amounts', () => {
    expect(() => normalizeAmount('abc')).toThrow();
  });
  it('per-month equivalent and saving percentage', () => {
    const monthly = toMoney(59.99, 'EUR');
    const annual = toMoney(575.9, 'EUR');
    expect(perMonth(annual, 'annually').amount).toBe('47.99');
    expect(savingPercent(monthly, annual, 'annually')).toBe(20);
    expect(savingPercent(toMoney(0, 'EUR'), annual, 'annually')).toBe(0);
  });
});

describe('spec parsers (formats seen in the live feeds)', () => {
  it('RAM', () => {
    expect(parseRamMiB('24 GB')).toBe(24576);
    expect(parseRamMiB('16 Gb')).toBe(16384);
    expect(parseRamMiB('128Gb')).toBe(131072);
    expect(parseRamMiB('1024 MB')).toBe(1024);
    expect(parseRamMiB('lots')).toBeUndefined();
  });
  it('vCPU and VPS disk', () => {
    expect(parseVcpu('12 vCPU')).toBe(12);
    expect(parseVcpu('12 cores')).toBeUndefined();
    expect(parseVpsDiskGB('500 GB')).toBe(500);
    expect(parseVpsDiskGB('20 Gb')).toBe(20);
  });
  it('dedicated storage', () => {
    expect(parseDedicatedDisks('2x960SSD')).toEqual([{ count: 2, sizeGB: 960, type: 'SSD', typeSource: 'billmanager' }]);
    expect(parseDedicatedDisks('250SSD')?.[0]).toMatchObject({ count: 1, sizeGB: 250 });
    expect(parseDedicatedDisks('2x2000SSD + 2x4000SATA')).toHaveLength(2);
    expect(parseDedicatedDisks('2x7600NVMe')?.[0]?.type).toBe('NVMe');
    expect(parseDedicatedDisks('2x500SSD + 8x4000SAS')?.[1]).toMatchObject({ count: 8, type: 'SAS' });
    expect(parseDedicatedDisks('weird')).toBeUndefined();
  });
  it('dedicated CPU', () => {
    expect(parseCpu('2xSilver-4214')).toEqual({ cpuSockets: 2, cpuModel: 'Silver-4214' });
    expect(parseCpu('E-2136')).toEqual({ cpuSockets: 1, cpuModel: 'E-2136' });
    expect(parseCpu('2xE5-2630v4')).toEqual({ cpuSockets: 2, cpuModel: 'E5-2630v4' });
  });
  it('port speed and traffic', () => {
    expect(parsePortMbps('200Mbit/s')).toBe(200);
    expect(parsePortMbps('1 Gbps')).toBe(1000);
    expect(parsePortMbps('10 Gbps')).toBe(10000);
    expect(parseTraffic('∞')).toEqual({ kind: 'unlimited' });
    expect(parseTraffic('10000GB')).toEqual({ kind: 'metered', includedGB: 10000 });
    expect(parseTraffic('30 TB')).toEqual({ kind: 'metered', includedGB: 30000 });
    expect(parseTraffic('unlimited')).toBeUndefined();
  });
  it('BILLmanager VPS description line', () => {
    const d = parseVpsDescription(
      'KVM-HIGHCPU-SSD-4 Location: USA, Ashburn, DC 2 vCPU: 12x | RAM: 24GB | Disk: 500GB SSD | Network speed: 200Mbit/s, traffic unlimited',
    );
    expect(d).toEqual({ vcpu: 12, ramMiB: 24576, diskGB: 500, diskType: 'SSD', portMbps: 200, trafficUnlimited: true });
  });
});

describe('slugify', () => {
  it('strips diacritics, handles + and spaces', () => {
    expect(slugify('São Paulo')).toBe('sao-paulo');
    expect(slugify('Hong Kong')).toBe('hong-kong');
    expect(slugify('2xSilver-4214-128Gb-2x960SSD+R')).toBe('2xsilver-4214-128gb-2x960ssd-plus-r');
  });
});
