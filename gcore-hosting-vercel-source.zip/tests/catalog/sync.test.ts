import { beforeEach, describe, expect, it } from 'vitest';
import { CATALOG_SCHEMA } from '@/lib/catalog/model';
import { MemoryStore } from '@/lib/catalog/store';
import { runSync, type SyncConfig } from '@/lib/catalog/sync';
import { fakeUpstream, fixtureJson, type FakeUpstream } from '../helpers/upstream';

let up: FakeUpstream;
let store: MemoryStore;
let clock: number;

const cfg = (): SyncConfig => ({
  calcBaseUrl: 'https://hosting-calc-prod.i.gc.onl',
  billmanagerBaseUrl: 'https://hosting.gcore.com',
  s2Currencies: ['EUR'],
  s2BatchSize: 5,
  s2Concurrency: 2,
  s2MaxAgeMs: 6 * 3600_000,
  maxDropRatio: 0.2,
  s2BackoffMs: 0,
  fetchImpl: up.fetch,
  now: () => new Date(clock),
});

const T0 = Date.parse('2026-11-01T12:00:00Z');
const CHANGED_ID = '170193'; // VPS, Ashburn, EUR, recorded in BILLmanager fixtures

beforeEach(() => {
  up = fakeUpstream();
  store = new MemoryStore();
  clock = T0;
});

type Row = { id: string; server_price: Record<string, number | string> };
const vpsRow = (id: string) => (up.state.calcVps as Row[]).find((r) => r.id === id)!;

describe('catalog sync', () => {
  it('first run publishes version 1 with orderable plans only where BILLmanager confirms them', async () => {
    const out = await runSync(store, cfg());
    expect(out.status).toBe('published');
    const live = (await store.getLive())!;
    expect(live.version).toBe(1);
    expect(live.stats.plans).toBe(672);
    expect(live.stats.orderable).toBe(6);
    expect(live.stats.byKind).toEqual({ vps: 360, dedicated: 312 });
    expect((await store.getMeta())?.lastError).toBeUndefined();
  });

  it('second run with no upstream changes publishes nothing and makes no BILLmanager detail requests for confirmed plans', async () => {
    await runSync(store, cfg());
    up.calls.billmgr.length = 0;
    clock += 60_000;
    const out = await runSync(store, cfg());
    expect(out).toMatchObject({ status: 'unchanged', refreshed: false });
    expect(up.calls.billmgr).toHaveLength(0);
    expect((await store.getLive())!.version).toBe(1);
    expect((await store.getMeta())!.lastCheckedAt).toBe(new Date(clock).toISOString());
  });

  it('a calc-feed price change refetches only that plan and invalidates only its tags', async () => {
    await runSync(store, cfg());
    up.calls.billmgr.length = 0;

    // Change the price consistently in BOTH sources, as a real BILLmanager tariff edit would.
    vpsRow(CHANGED_ID).server_price['monthly'] = 61.99;
    vpsRow(CHANGED_ID).server_price['quarterly'] = 176.67;
    vpsRow(CHANGED_ID).server_price['semiannually'] = 334.75;
    vpsRow(CHANGED_ID).server_price['annually'] = 595.1;
    const raw = structuredClone(fixtureJson<{ doc: { pricelist: Array<{ price: { period: Array<Record<string, string>> } }> } }>(`s2-${CHANGED_ID}.json`).doc.pricelist[0]!);
    const costs = ['61.9900', '176.6700', '334.7500', '595.1000'];
    raw.price.period.forEach((p, i) => (p['$cost'] = costs[i]!));
    up.state.s2Overrides.set(CHANGED_ID, raw);

    clock += 60_000;
    const out = await runSync(store, cfg());
    if (out.status !== 'published') throw new Error(`expected published, got ${out.status}`);

    expect(out.diff.changed).toEqual([CHANGED_ID]);
    expect(out.diff.added).toEqual([]);
    expect(out.diff.removed).toEqual([]);
    expect(out.tags).toContain(`plan:${CHANGED_ID}`);
    expect(out.tags).toContain('location:ashburn');
    expect(out.tags).toContain('kind:vps');
    expect(out.tags.filter((t) => t.startsWith('plan:'))).toEqual([`plan:${CHANGED_ID}`]);
    expect(out.tags).not.toContain('kind:dedicated');
    expect(out.tags).not.toContain('location:frankfurt');

    expect(up.calls.billmgr.flatMap((c) => c.ids)).toEqual([CHANGED_ID]);
    const plan = out.catalog.plans.find((p) => p.id === CHANGED_ID)!;
    expect(plan.prices.monthly.amount).toBe('61.99');
    expect(plan.prices.annually.amount).toBe('595.10');
    expect(plan.flags.map((f) => f.code)).not.toContain('price-mismatch');
    expect((await store.getLive())!.version).toBe(2);
  });

  it('changedAt (sitemap lastmod) moves only for plans whose content changed', async () => {
    await runSync(store, cfg());
    const t0 = new Date(T0).toISOString();
    const first = (await store.getLive())!;
    expect(first.plans.every((p) => p.source.changedAt === t0)).toBe(true);

    vpsRow(CHANGED_ID).server_price['monthly'] = 99.99;
    clock += 60_000;
    const t1 = new Date(clock).toISOString();
    await runSync(store, cfg());
    const second = (await store.getLive())!;
    expect(second.plans.find((p) => p.id === CHANGED_ID)!.source.changedAt).toBe(t1);
    expect(second.plans.filter((p) => p.source.changedAt === t1)).toHaveLength(1);
    expect(second.plans.filter((p) => p.source.changedAt === t0)).toHaveLength(671);

    clock += 60_000; // a later sync with no change must not touch anything
    await runSync(store, cfg());
    const third = (await store.getLive())!;
    expect(third.plans.find((p) => p.id === CHANGED_ID)!.source.changedAt).toBe(t1);
    expect(third.plans.filter((p) => p.source.changedAt === t0)).toHaveLength(671);
  });

  it('a snapshot written by older code (other schema) is never reused: all BILLmanager detail is refetched', async () => {
    await runSync(store, cfg());
    const live = (await store.getLive())!;
    expect(live.schema).toBe(CATALOG_SCHEMA);

    // Simulate a snapshot from before schema versioning: same content, no schema marker.
    delete live.schema;
    await store.publish(live, (await store.getMeta())!);
    up.calls.billmgr.length = 0;
    clock += 60_000;
    const out = await runSync(store, cfg());
    expect(up.calls.billmgr.flatMap((c) => c.ids).length).toBeGreaterThan(300); // every EUR plan refetched
    expect(['published', 'unchanged']).toContain(out.status);
    expect((await store.getLive())!.schema).toBe(CATALOG_SCHEMA);
  });

  it('when the sources disagree, BILLmanager wins and the mismatch is flagged', async () => {
    await runSync(store, cfg());
    vpsRow(CHANGED_ID).server_price['monthly'] = 99.99; // calc feed drifts, BILLmanager unchanged
    clock += 60_000;
    const out = await runSync(store, cfg());
    if (out.status !== 'published') throw new Error('expected published');
    const plan = out.catalog.plans.find((p) => p.id === CHANGED_ID)!;
    expect(plan.prices.monthly.amount).toBe('59.99');
    expect(plan.flags.find((f) => f.code === 'price-mismatch')?.severity).toBe('error');
  });

  it('keeps the previous snapshot when the calc feed fails and records the error', async () => {
    await runSync(store, cfg());
    up.state.calcStatus = 503;
    clock += 60_000;
    const out = await runSync(store, cfg());
    expect(out.status).toBe('failed');
    expect((await store.getLive())!.version).toBe(1);
    expect((await store.getMeta())!.lastError?.message).toMatch(/calc feed/);
  });

  it('rejects a feed that suddenly shrinks and keeps serving the old snapshot', async () => {
    await runSync(store, cfg());
    up.state.calcVps = (up.state.calcVps as unknown[]).slice(0, 100);
    clock += 60_000;
    const out = await runSync(store, cfg());
    expect(out.status).toBe('rejected');
    expect((await store.getLive())!.stats.plans).toBe(672);
  });

  it('does not run twice at once', async () => {
    const token = await store.acquireLock(60_000);
    expect(token).not.toBeNull();
    expect((await runSync(store, cfg())).status).toBe('locked');
    await store.releaseLock(token!);
    expect((await runSync(store, cfg())).status).toBe('published');
  });

  it('a BILLmanager outage keeps confirmed plans orderable (marked stale) instead of flipping them to unknown', async () => {
    await runSync(store, cfg());
    up.state.billmgrStatus = 504;
    clock += 7 * 3600_000; // detail now older than 6h, so a refetch is attempted
    const out = await runSync(store, { ...cfg(), s2MaxAgeMs: 6 * 3600_000 });
    const live = (await store.getLive())!;
    const plan = live.plans.find((p) => p.id === CHANGED_ID)!;
    expect(plan.availability).toBe('orderable');
    expect(plan.flags.map((f) => f.code)).toContain('s2-stale');
    expect(live.stats.orderable).toBe(6);
    expect(['published', 'unchanged']).toContain(out.status);
  });

  it('a plan whose price changed during a BILLmanager outage is not published with old availability or links', async () => {
    await runSync(store, cfg());
    up.state.billmgrStatus = 504;
    vpsRow(CHANGED_ID).server_price['monthly'] = 70;
    clock += 60_000;
    await runSync(store, cfg());
    const plan = (await store.getLive())!.plans.find((p) => p.id === CHANGED_ID)!;
    expect(plan.availability).toBe('unknown');
    expect(plan.order.byPeriod).toEqual({});
  });
});
