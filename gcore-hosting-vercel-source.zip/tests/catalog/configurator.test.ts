import { describe, expect, it } from 'vitest';
import {
  SelectionError,
  buildConfigModel,
  buildOrderLink,
  defaultSelection,
  quote,
  validateSelection,
  type ConfigModel,
  type Selection,
} from '@/lib/catalog/configurator';
import { fxAdd, fxMulInt, fxToString, toFx } from '@/lib/catalog/fx';
import type { Plan } from '@/lib/catalog/model';
import { PERIODS } from '@/lib/catalog/periods';
import { normalizeAmount } from '@/lib/catalog/money';
import { fixtureCatalog } from '../helpers/catalog';
import { S2_RECORDED_IDS } from '../helpers/upstream';

const catalog = fixtureCatalog();
const plan = (id: string): Plan => catalog.plans.find((p) => p.id === id)!;
const model = (id: string): ConfigModel => buildConfigModel(plan(id))!;

describe('fixed-point money', () => {
  it('round-trips BILLmanager amounts and matches normalizeAmount formatting', () => {
    for (const s of ['0', '0.16', '2.40', '59.99', '575.90', '0.0013', '1234.5']) {
      expect(fxToString(toFx(normalizeAmount(s)))).toBe(normalizeAmount(s));
    }
  });
  it('is exact where floats are not', () => {
    expect(fxToString(fxAdd(toFx('0.10'), toFx('0.20')))).toBe('0.30');
    expect(fxToString(fxMulInt(toFx('0.16'), 3))).toBe('0.48');
    expect(() => toFx('abc')).toThrow();
    expect(() => toFx('1.23456')).toThrow();
  });
});

describe('configurator model from real BILLmanager add-ons', () => {
  it('VPS: one extra-IPv4 control, no traffic control, resources are fixed to the plan', () => {
    const m = model('170193');
    expect(m.quantities).toEqual([
      {
        id: '170197',
        label: 'Public IPv4-address',
        included: 1,
        step: 1,
        max: 10,
        unitPrices: { monthly: '2.40', quarterly: '7.20', semiannually: '14.40', annually: '28.80' },
      },
    ]);
    expect(m.traffic).toBeNull();
    expect(m.fixedResources).toBe(true);
  });

  it('dedicated: extra IPv4 and IPv6, and a single-choice traffic tier with the included tier as default', () => {
    const m = model('125840');
    expect(m.quantities.map((q) => [q.label, q.included, q.max, q.unitPrices.monthly])).toEqual([
      ['Public IPv4-address', 1, 15, '2.00'],
      ['IPv6-addresses', 1, 15, '0.16'],
    ]);
    expect(m.fixedResources).toBe(false);
    const t = m.traffic!;
    expect(t.parentId).toBe('125842'); // the "Traffic" add-on the children belong to
    expect(t.defaultId).toBe('125846');
    expect(t.choices.map((c) => [c.id, c.prices.monthly, c.prices.annually])).toEqual([
      ['125846', '0.00', '0.00'],
      ['125847', '60.00', '720.00'],
      ['125848', '115.00', '1380.00'],
    ]);
    expect(t.choices[1]!.label).toContain('60TB traffic included'); // BILLmanager's own wording, verbatim
  });

  it('never offers what cannot be changed or whose meaning is unverified', () => {
    const labels = JSON.stringify(model('125840'));
    for (const nope of ['Windows', 'Mssql', 'Operating', 'burst', 'Burst', 'unlimited traffic']) expect(labels).not.toContain(nope);
    expect(model('125840').traffic!.choices.map((c) => c.id)).not.toContain('125849'); // burst-billed option
    const vps = JSON.stringify(model('170193'));
    for (const nope of ['Disk', 'RAM', 'CPU number', 'IPv6 network']) expect(vps).not.toContain(nope);
  });

  it('every recorded plan yields a well-formed model', () => {
    for (const id of S2_RECORDED_IDS) {
      const m = buildConfigModel(plan(id));
      if (!m) continue;
      for (const q of m.quantities) {
        expect(q.max).toBeGreaterThan(q.included);
        for (const p of PERIODS) expect(Number(q.unitPrices[p]), `${id} ${q.label} ${p}`).toBeGreaterThan(0);
      }
    }
  });

  it('returns no model when a plan has nothing configurable', () => {
    expect(buildConfigModel({ kind: 'dedicated', currency: 'EUR', addons: [] })).toBeNull();
  });
});

describe('estimated total', () => {
  const m = model('125840');
  const base = plan('125840').prices;
  const sel = (over: Partial<Selection> = {}): Selection => ({ ...defaultSelection(m), ...over });

  it('the default configuration costs exactly the plan price', () => {
    for (const p of PERIODS) {
      const q = quote(m, base[p].amount, p, defaultSelection(m));
      expect(q.total).toBe(base[p].amount);
      expect(q.lines).toEqual([]);
    }
  });

  it('adds extra addresses at BILLmanager period prices (not monthly x months)', () => {
    const q = quote(m, base.monthly.amount, 'monthly', sel({ quantities: { '125843': 3, '125844': 5 } }));
    // 266.00 + 2 extra IPv4 x 2.00 + 4 extra IPv6 x 0.16
    expect(q.lines.map((l) => [l.label, l.detail, l.amount])).toEqual([
      ['Public IPv4-address', '2 × 2.00', '4.00'],
      ['IPv6-addresses', '4 × 0.16', '0.64'],
    ]);
    expect(q.total).toBe('270.64');
    const y = quote(m, base.annually.amount, 'annually', sel({ quantities: { '125843': 3, '125844': 5 } }));
    expect(y.total).toBe('3247.68'); // 3192.00 + 2 x 24.00 + 4 x 1.92
  });

  it('adds the chosen traffic tier surcharge', () => {
    expect(quote(m, base.monthly.amount, 'monthly', sel({ traffic: '125847' })).total).toBe('326.00');
    expect(quote(m, base.monthly.amount, 'monthly', sel({ traffic: '125848' })).total).toBe('381.00');
    const all = quote(m, base.annually.amount, 'annually', sel({ quantities: { '125843': 3, '125844': 5 }, traffic: '125847' }));
    expect(all.total).toBe('3967.68');
  });

  it('rejects impossible selections instead of pricing them', () => {
    const bad: Selection[] = [
      sel({ quantities: { '125843': 0 } }), // below what the plan includes
      sel({ quantities: { '125843': 16 } }), // above the maximum
      sel({ quantities: { '125843': 1.5 } }),
      sel({ quantities: { '999': 2 } }), // unknown option
      sel({ traffic: '125849' }), // not an offered tier (burst option)
      sel({ traffic: 'x' }),
    ];
    for (const s of bad) expect(() => validateSelection(m, s)).toThrow(SelectionError);
    expect(() => quote(m, '266.00', 'monthly', bad[0]!)).toThrow(SelectionError);
  });
});

describe('order links', () => {
  const m = model('125840');
  const p = plan('125840');

  it('BILLmanager re-encoding is reproduced byte for byte (so appended pairs are encoded the way it encodes)', () => {
    for (const id of S2_RECORDED_IDS) {
      for (const link of Object.values(plan(id).order.byPeriod)) {
        const decoded = new URL(link).searchParams.get('redirect')!;
        const raw = /[?&]redirect=([^&]*)/.exec(link)![1];
        expect(encodeURIComponent(decoded), link).toBe(raw);
      }
    }
  });

  it('the default configuration, or params off, returns BILLmanager\'s link unmodified', () => {
    for (const period of PERIODS) {
      const link = p.order.byPeriod[period]!;
      expect(buildOrderLink(link, m, defaultSelection(m), { params: true })).toBe(link);
      expect(buildOrderLink(link, m, { ...defaultSelection(m), quantities: { '125843': 4 }, traffic: '125847' }, { params: false })).toBe(link);
    }
  });

  it('with params on, appends addon_<id>=<value> pairs inside the redirect value', () => {
    const link = p.order.byPeriod.quarterly!;
    const out = buildOrderLink(link, m, { quantities: { '125843': 3, '125844': 1 }, traffic: '125847' }, { params: true });
    const redirect = new URL(out).searchParams.get('redirect')!;
    expect(redirect).toBe(`${new URL(link).searchParams.get('redirect')!}&addon_125843=3&addon_125842=125847`);
    expect(redirect).toContain('period=3');
    expect(redirect).toContain('pricelist=125840');
    expect(new URL(out).origin).toBe('https://hosting.gcore.com');
    // nothing leaks to the outer query string
    expect([...new URL(out).searchParams.keys()].sort()).toEqual(['func', 'redirect']);
  });

  it('refuses a selection that is not valid for the plan, and a link without a redirect', () => {
    expect(() => buildOrderLink(p.order.byPeriod.monthly!, m, { quantities: { '125843': 99 } }, { params: true })).toThrow(SelectionError);
    expect(() => buildOrderLink('https://hosting.gcore.com/billmgr?func=register', m, { quantities: { '125843': 2 } }, { params: true })).toThrow(/redirect/);
  });

  it('only digits can reach the link: hostile ids in the model are ignored, not emitted', () => {
    const evil = structuredClone(p);
    evil.addons[1]!.id = '1&evil=1';
    const em = buildConfigModel(evil)!;
    expect(JSON.stringify(em)).not.toContain('evil');
  });
});
