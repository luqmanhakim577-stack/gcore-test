import { describe, expect, it } from 'vitest';
import { SIGNATURE_WINDOW_SECONDS, signRequest, verifyRequest } from '@/lib/security/hmac';
import { checkRateLimit, clientKeyOf, MemoryLimits } from '@/lib/security/limits';

const SECRET = 'x'.repeat(40);
const headersOf = (h: Record<string, string>) => ({ get: (n: string) => h[n.toLowerCase()] ?? null });
const NOW = 1_800_000_000_000;

describe('HMAC request signing', () => {
  const body = '{"force":true}';
  const signed = (over: Parameters<typeof signRequest>[4] = {}) =>
    signRequest(SECRET, 'POST', '/api/internal/sync', body, { now: NOW, ...over });

  it('accepts a correctly signed request', () => {
    const r = verifyRequest(SECRET, 'POST', '/api/internal/sync', body, headersOf(signed({ nonce: 'n1' })), NOW);
    expect(r).toEqual({ ok: true, nonce: 'n1' });
  });

  it('rejects a tampered body, path, method or secret', () => {
    const h = headersOf(signed());
    expect(verifyRequest(SECRET, 'POST', '/api/internal/sync', '{"force":false}', h, NOW)).toMatchObject({ ok: false, reason: 'bad-signature' });
    expect(verifyRequest(SECRET, 'POST', '/api/internal/revalidate', body, h, NOW)).toMatchObject({ ok: false });
    expect(verifyRequest(SECRET, 'GET', '/api/internal/sync', body, h, NOW)).toMatchObject({ ok: false });
    expect(verifyRequest('y'.repeat(40), 'POST', '/api/internal/sync', body, h, NOW)).toMatchObject({ ok: false });
  });

  it('rejects stale and far-future timestamps', () => {
    const old = headersOf(signed());
    const later = NOW + (SIGNATURE_WINDOW_SECONDS + 5) * 1000;
    expect(verifyRequest(SECRET, 'POST', '/api/internal/sync', body, old, later)).toMatchObject({ ok: false, reason: 'stale' });
    const future = headersOf(signed({ now: NOW + (SIGNATURE_WINDOW_SECONDS + 5) * 1000 }));
    expect(verifyRequest(SECRET, 'POST', '/api/internal/sync', body, future, NOW)).toMatchObject({ ok: false, reason: 'stale' });
  });

  it('rejects missing or malformed headers without throwing', () => {
    expect(verifyRequest(SECRET, 'POST', '/x', '', headersOf({}), NOW)).toMatchObject({ ok: false, reason: 'missing' });
    const s = signed();
    const bad = { ...s, 'x-signature': 'zz-not-hex' };
    expect(verifyRequest(SECRET, 'POST', '/api/internal/sync', body, headersOf(bad), NOW)).toMatchObject({ ok: false });
    const short = { ...s, 'x-signature': s['x-signature'].slice(0, 10) };
    expect(verifyRequest(SECRET, 'POST', '/api/internal/sync', body, headersOf(short), NOW)).toMatchObject({ ok: false });
    expect(verifyRequest(SECRET, 'POST', '/x', '', headersOf({ ...s, 'x-timestamp': 'abc' }), NOW)).toMatchObject({ ok: false });
  });
});

describe('rate limiting and replay primitives', () => {
  it('counts per key within a window and resets after it', async () => {
    let t = 0;
    const mem = new MemoryLimits(() => t);
    const policy = { name: 'p', limit: 3, windowSeconds: 60 };
    const results = [];
    for (let i = 0; i < 5; i++) results.push(await checkRateLimit(policy, '1.1.1.1', mem));
    expect(results.map((r) => r.allowed)).toEqual([true, true, true, false, false]);
    expect(await checkRateLimit(policy, '2.2.2.2', mem)).toMatchObject({ allowed: true }); // other client unaffected
    t = 61_000;
    expect(await checkRateLimit(policy, '1.1.1.1', mem)).toMatchObject({ allowed: true });
  });

  it('reports a Retry-After when blocked', async () => {
    const mem = new MemoryLimits(() => 0);
    const policy = { name: 'p', limit: 1, windowSeconds: 30 };
    await checkRateLimit(policy, 'a', mem);
    const r = await checkRateLimit(policy, 'a', mem);
    expect(r).toEqual({ allowed: false, retryAfter: 30 });
  });

  it('fails open when the backend errors', async () => {
    const broken = { hit: async () => { throw new Error('redis down'); }, once: async () => true };
    expect(await checkRateLimit({ name: 'p', limit: 1, windowSeconds: 1 }, 'a', broken)).toMatchObject({ allowed: true });
  });

  it('once() is true the first time and false inside the TTL', async () => {
    let t = 0;
    const mem = new MemoryLimits(() => t);
    expect(await mem.once('n', 10)).toBe(true);
    expect(await mem.once('n', 10)).toBe(false);
    t = 11_000;
    expect(await mem.once('n', 10)).toBe(true);
  });

  it('derives a safe client key from forwarding headers', () => {
    expect(clientKeyOf(headersOf({ 'x-real-ip': '198.51.100.4' }), 1)).toBe('198.51.100.4');
    expect(clientKeyOf(headersOf({}), 1)).toBe('unknown');
    expect(clientKeyOf(headersOf({ 'x-forwarded-for': '<script>alert(1)</script>' }), 1)).not.toMatch(/[<>()]/);
  });

  describe('trusted proxies', () => {
    it('takes the entry our own proxy appended, not the one the client wrote', () => {
      // client sent "X-Forwarded-For: 1.1.1.1"; our single proxy appended the address it really saw
      expect(clientKeyOf(headersOf({ 'x-forwarded-for': '1.1.1.1, 203.0.113.9' }), 1)).toBe('203.0.113.9');
      // CDN then load balancer: client, CDN edge
      expect(clientKeyOf(headersOf({ 'x-forwarded-for': '9.9.9.9, 203.0.113.9, 198.51.100.77' }), 2)).toBe('203.0.113.9');
    });

    it('an attacker cannot mint new buckets by changing the header they send', () => {
      const keys = new Set(
        ['1.1.1.1', '2.2.2.2', '3.3.3.3, 4.4.4.4'].map((spoof) => clientKeyOf(headersOf({ 'x-forwarded-for': `${spoof}, 203.0.113.9` }), 1)),
      );
      expect([...keys]).toEqual(['203.0.113.9']);
    });

    it('uses the first entry when the chain is shorter than the configured hops', () => {
      expect(clientKeyOf(headersOf({ 'x-forwarded-for': '203.0.113.9' }), 2)).toBe('203.0.113.9');
    });

    it('trusts no header at all when there is no proxy (hops 0)', () => {
      expect(clientKeyOf(headersOf({ 'x-forwarded-for': '203.0.113.9', 'x-real-ip': '203.0.113.9' }), 0)).toBe('unknown');
    });

    it('buckets IPv6 clients by /64 so one subscriber cannot rotate addresses', () => {
      const a = clientKeyOf(headersOf({ 'x-forwarded-for': '2001:db8:aaaa:1::1' }), 1);
      const b = clientKeyOf(headersOf({ 'x-forwarded-for': '2001:db8:aaaa:1:ffff:ffff:ffff:ffff' }), 1);
      const other = clientKeyOf(headersOf({ 'x-forwarded-for': '2001:db8:aaaa:2::1' }), 1);
      expect(a).toBe(b);
      expect(a).not.toBe(other);
      expect(a).toBe('2001:db8:aaaa:1::/64');
    });
  });
});
