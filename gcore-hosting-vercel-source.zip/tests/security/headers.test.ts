import { describe, expect, it } from 'vitest';
import config, { CSP_DIRECTIVES, serializeCsp } from '../../next.config';

type Rule = { source: string; headers: Array<{ key: string; value: string }> };
const rules = async () => (await config.headers!()) as Rule[];

/** Headers the browser ends up with for a path: later matching rules override earlier ones for the same key. */
async function headersFor(source: string): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  for (const r of await rules()) {
    const re = new RegExp('^' + r.source.replace(/:path\*/g, '.*').replace(/\//g, '\\/') + '$');
    if (re.test(source)) for (const h of r.headers) out.set(h.key, h.value);
  }
  return out;
}

describe('security headers', () => {
  it('pages get a CSP that shuts the dangerous channels and allows no third-party origin', async () => {
    const csp = (await headersFor('/vps')).get('Content-Security-Policy')!;
    const d = Object.fromEntries(csp.split('; ').map((p) => [p.split(' ')[0], p.split(' ').slice(1)]));

    expect(d['default-src']).toEqual(["'self'"]);
    expect(d['object-src']).toEqual(["'none'"]);
    expect(d['base-uri']).toEqual(["'none'"]);
    expect(d['frame-ancestors']).toEqual(["'none'"]);
    expect(d['frame-src']).toEqual(["'none'"]);
    expect(d['form-action']).toEqual(["'self'"]);
    expect(d['connect-src']).toEqual(["'self'"]);
    // nothing may be loaded from another host, whatever the directive
    expect(csp).not.toMatch(/https?:|\*/);
    expect(csp).not.toMatch(/unsafe-eval/); // production policy
    // the one concession, stated rather than hidden
    expect(d['script-src']).toEqual(["'self'", "'unsafe-inline'"]);
    expect(csp).toContain('upgrade-insecure-requests');
  });

  it('the serialized policy has no empty or duplicate directives', () => {
    const names = serializeCsp(CSP_DIRECTIVES).split('; ').map((p) => p.split(' ')[0]);
    expect(new Set(names).size).toBe(names.length);
    expect(names.every(Boolean)).toBe(true);
  });

  it('every page carries the baseline hardening headers', async () => {
    const h = await headersFor('/vps/ashburn');
    expect(h.get('X-Content-Type-Options')).toBe('nosniff');
    expect(h.get('X-Frame-Options')).toBe('DENY');
    expect(h.get('Referrer-Policy')).toBe('strict-origin-when-cross-origin');
    expect(h.get('Cross-Origin-Opener-Policy')).toBe('same-origin');
    expect(h.get('Strict-Transport-Security')).toMatch(/max-age=\d{8,}; includeSubDomains$/);
    expect(h.get('Strict-Transport-Security')).not.toMatch(/preload/); // a deliberate, separate decision
    expect(h.get('Permissions-Policy')).toMatch(/camera=\(\).*microphone=\(\).*geolocation=\(\)/);
  });

  it('machine-readable responses are never rendered (default-src none), are readable cross-origin, and are not CORS-open elsewhere', async () => {
    for (const p of ['/api/v1/plans', '/api/v1/openapi.json', '/llms.txt', '/llms-full.txt']) {
      const h = await headersFor(p);
      expect(h.get('Content-Security-Policy'), p).toMatch(/^default-src 'none'/);
      expect(h.get('Access-Control-Allow-Origin'), p).toBe('*');
      expect(h.get('Access-Control-Allow-Methods'), p).toBe('GET, HEAD, OPTIONS');
    }
    for (const p of ['/', '/vps', '/api/internal/sync', '/api/internal/revalidate', '/api/health']) {
      expect((await headersFor(p)).has('Access-Control-Allow-Origin'), `${p} must not be CORS-open`).toBe(false);
    }
  });

  it('API responses are kept out of search indexes', async () => {
    for (const p of ['/api/health', '/api/v1/plans', '/api/internal/sync']) expect((await headersFor(p)).get('X-Robots-Tag'), p).toBe('noindex');
    expect((await headersFor('/llms.txt')).has('X-Robots-Tag')).toBe(false);
  });
});
