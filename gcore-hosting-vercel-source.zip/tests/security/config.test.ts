import { describe, expect, it } from 'vitest';
import { assertProductionConfig, getEnv, productionConfigProblems } from '@/lib/env';

const env = (over: Record<string, string>) => getEnv({ ...over } as NodeJS.ProcessEnv);
const GOOD = { REDIS_URL: 'redis://redis:6379', REVALIDATE_HMAC_SECRET: 'x'.repeat(32), SITE_URL: 'https://gcore.hosting' };

describe('production configuration', () => {
  it('accepts a complete configuration', () => {
    expect(productionConfigProblems(env(GOOD))).toEqual([]);
    expect(() => assertProductionConfig(env(GOOD))).not.toThrow();
  });

  it('names every missing piece at once, so one deploy attempt shows all of them', () => {
    const problems = productionConfigProblems(env({ SITE_URL: 'http://gcore.hosting' }));
    expect(problems).toHaveLength(3);
    expect(problems.join('\n')).toMatch(/REDIS_URL/);
    expect(problems.join('\n')).toMatch(/REVALIDATE_HMAC_SECRET/);
    expect(problems.join('\n')).toMatch(/SITE_URL must be https/);
    expect(() => assertProductionConfig(env({}))).toThrow(/Invalid production configuration/);
  });

  it('rejects a short secret at parse time', () => {
    expect(() => env({ ...GOOD, REVALIDATE_HMAC_SECRET: 'short' })).toThrow(/at least 32/);
  });

  it('allows the file snapshot only when explicitly opted in, and http only on localhost', () => {
    const local = { REVALIDATE_HMAC_SECRET: 'x'.repeat(32), SITE_URL: 'http://localhost:3000' };
    expect(productionConfigProblems(env(local))).toHaveLength(1);
    expect(productionConfigProblems(env({ ...local, ALLOW_FILE_STORE: '1' }))).toEqual([]);
    expect(() => env({ ...local, ALLOW_FILE_STORE: 'yes' })).toThrow();
  });

  it('bounds the trusted proxy count', () => {
    expect(env({ TRUSTED_PROXY_HOPS: '2' }).TRUSTED_PROXY_HOPS).toBe(2);
    expect(env({}).TRUSTED_PROXY_HOPS).toBe(1);
    expect(() => env({ TRUSTED_PROXY_HOPS: '99' })).toThrow();
    expect(() => env({ TRUSTED_PROXY_HOPS: '-1' })).toThrow();
  });
});
