import { NextRequest } from 'next/server';
import { describe, expect, it } from 'vitest';
import { config, middleware } from '@/middleware';
import { isTrustworthy } from '@/lib/catalog/model';
import { listedPlans, planPath } from '@/lib/catalog/views';
import { absoluteUrl } from '@/lib/seo/config';
import { alternatesFor, pageMetadata } from '@/lib/seo/meta';
import { AI_CRAWLERS, robotsConfig } from '@/lib/seo/robots';
import { sitemapEntries } from '@/lib/seo/sitemap';
import { fixtureCatalog } from '../helpers/catalog';

const catalog = fixtureCatalog();

describe('sitemap', () => {
  const entries = sitemapEntries(catalog);
  const paths = entries.map((e) => e.path);

  it('contains every listed plan page, hub, location and the home page, once each', () => {
    expect(new Set(paths).size).toBe(paths.length);
    for (const kind of ['vps', 'dedicated'] as const) for (const p of listedPlans(catalog, kind)) expect(paths).toContain(planPath(p));
    for (const must of ['/', '/vps', '/dedicated-servers', '/locations', '/vps/ashburn', '/locations/ashburn']) expect(paths).toContain(must);
  });

  it('never contains withheld, unconfirmed or USD plans, queries or non-page routes', () => {
    const excluded = catalog.plans.filter((p) => !listedPlans(catalog, p.kind).some((l) => l.id === p.id));
    expect(excluded.length).toBeGreaterThan(600);
    const joined = paths.join('\n');
    for (const p of excluded) expect(joined, `plan ${p.id}`).not.toContain(`-${p.id}`);
    expect(catalog.plans.filter((p) => !isTrustworthy(p)).some((p) => joined.includes(`-${p.id}`))).toBe(false);
    expect(paths.every((p) => p.startsWith('/') && !/[?#]/.test(p) && !p.startsWith('/api'))).toBe(true);
  });

  it('lastModified is the latest real change among the plans on that page', () => {
    const c = structuredClone(catalog);
    const target = c.plans.find((p) => p.id === '170193')!;
    target.source.changedAt = '2026-12-24T00:00:00.000Z';
    const e = Object.fromEntries(sitemapEntries(c).map((x) => [x.path, x.lastModified]));
    expect(e[planPath(target)]).toBe('2026-12-24T00:00:00.000Z');
    expect(e['/vps/ashburn']).toBe('2026-12-24T00:00:00.000Z');
    expect(e['/vps']).toBe('2026-12-24T00:00:00.000Z');
    expect(e['/vps/istanbul']).toBe('2026-11-01T12:00:00.000Z'); // untouched location keeps its date
    expect(e['/dedicated-servers']).toBe('2026-11-01T12:00:00.000Z');
  });
});

describe('robots', () => {
  const r = robotsConfig();
  const rules = r.rules as Array<{ userAgent: string; allow: string; disallow: string[] }>;

  it('points at the sitemap and keeps internal endpoints out', () => {
    expect(r.sitemap).toBe('https://gcore.hosting/sitemap.xml');
    for (const rule of rules) expect(rule.disallow).toEqual(['/api/internal/']);
  });
  it('allows search and AI crawlers explicitly (policy D7) and does not block the public API', () => {
    const agents = rules.map((x) => x.userAgent);
    expect(agents).toContain('*');
    for (const a of AI_CRAWLERS) expect(agents).toContain(a);
    expect(rules.every((x) => x.allow === '/' && !x.disallow.includes('/api/v1/'))).toBe(true);
  });
  it('does not block query URLs (they must stay crawlable so their canonical is seen)', () => {
    expect(JSON.stringify(r)).not.toMatch(/\*\?|\?\*/);
  });
});

describe('page metadata helper', () => {
  it('canonical and hreflang are self-referencing, query-free and include x-default', () => {
    const a = alternatesFor('/vps/frankfurt');
    expect(a.canonical).toBe('/vps/frankfurt');
    expect(a.languages).toEqual({ en: '/vps/frankfurt', 'x-default': '/vps/frankfurt' });
  });
  it('open graph and twitter mirror the title and description', () => {
    const m = pageMetadata({ pathname: '/vps', title: 'VPS in 15 locations', description: 'd' });
    expect((m.openGraph as any).title).toBe('VPS in 15 locations | Gcore Hosting');
    expect((m.openGraph as any).url).toBe('/vps');
    expect((m.twitter as any).description).toBe('d');
    expect(m.robots).toBeUndefined();
    expect(pageMetadata({ pathname: '/x', title: 't', description: 'd', noindex: true }).robots).toEqual({ index: false, follow: true });
  });
  it('absoluteUrl strips query and fragment and never ends with a slash', () => {
    expect(absoluteUrl('/vps/frankfurt?period=annually#x')).toBe('https://gcore.hosting/vps/frankfurt');
    expect(absoluteUrl('/')).toBe('https://gcore.hosting');
  });
});

describe('middleware: URL variants are never indexed', () => {
  const run = (url: string) => middleware(new NextRequest(`http://localhost${url}`));

  it('adds noindex and a canonical Link header when any query parameter is present', () => {
    for (const q of ['?period=annually', '?utm_source=x&utm_medium=y', '?sort=price&cpu=8', '?a']) {
      const res = run(`/vps/frankfurt${q}`);
      expect(res.headers.get('x-robots-tag'), q).toBe('noindex, follow');
      expect(res.headers.get('link'), q).toBe('<https://gcore.hosting/vps/frankfurt>; rel="canonical"');
    }
  });
  it('leaves clean URLs and Next RSC requests untouched', () => {
    expect(run('/vps/frankfurt').headers.get('x-robots-tag')).toBeNull();
    expect(run('/vps/frankfurt?_rsc=abc').headers.get('x-robots-tag')).toBeNull();
  });
  it('is scoped to pages: not the API, Next internals or metadata files', () => {
    const re = new RegExp(`^${config.matcher[0]!.replace(/\(\?!/, '(?!')}$`);
    for (const p of ['/api/v1/plans', '/_next/static/x.js', '/robots.txt', '/sitemap.xml']) expect(re.test(p), p).toBe(false);
    for (const p of ['/', '/vps', '/vps/frankfurt/kvm-ssd-1-175003']) expect(re.test(p), p).toBe(true);
  });
});
