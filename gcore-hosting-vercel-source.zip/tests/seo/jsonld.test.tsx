import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import { Breadcrumbs, JsonLd } from '@/components/layout';
import { PlanPage } from '@/components/pages';
import { PERIODS } from '@/lib/catalog/money';
import { planPageView } from '@/lib/catalog/views';
import { specRows } from '@/lib/format';
import { breadcrumbLd, itemListLd, organizationLd, productLd, serializeLd, websiteLd } from '@/lib/seo/jsonld';
import { extractLd, validateLd } from '../helpers/ld';
import { fixtureCatalog } from '../helpers/catalog';

const catalog = fixtureCatalog();
const view = planPageView(catalog, 'vps', '170193')!;

describe('typed JSON-LD builders', () => {
  it('organization and website share stable @ids and validate', () => {
    expect(validateLd(organizationLd() as never)).toEqual([]);
    expect(validateLd(websiteLd() as never)).toEqual([]);
    expect(websiteLd().publisher).toEqual({ '@id': (organizationLd() as any)['@id'] });
  });

  it('breadcrumbs: consecutive positions, absolute URLs, never a query string', () => {
    const ld = breadcrumbLd([
      { label: 'Home', href: '/' },
      { label: 'VPS', href: '/vps' },
      { label: 'Frankfurt', href: '/vps/frankfurt?period=annually' },
    ]);
    expect(validateLd(ld as never)).toEqual([]);
    expect((ld.itemListElement as any[]).map((i) => i.item)).toEqual([
      'https://gcore.hosting',
      'https://gcore.hosting/vps',
      'https://gcore.hosting/vps/frankfurt',
    ]);
  });

  it('product: one Offer per billing period carrying exactly the BILLmanager prices', () => {
    const ld = productLd(view.plan, view.location, 'desc');
    expect(validateLd(ld as never)).toEqual([]);
    const offers = ld.offers as any[];
    expect(offers).toHaveLength(4);
    PERIODS.forEach((p, i) => {
      expect(offers[i].price).toBe(view.plan.prices[p].amount);
      expect(offers[i].priceCurrency).toBe('EUR');
    });
    expect(offers.map((o) => o.priceSpecification.billingDuration.value)).toEqual([1, 3, 6, 12]);
    expect(offers[0].price).toBe('59.99');
    expect(offers[3].price).toBe('575.90');
    expect(ld.sku).toBe('170193');
    expect(ld.url).toBe('https://gcore.hosting/vps/ashburn/kvm-highcpu-ssd-4-170193');
  });

  it('product specs come from the same rows the page displays', () => {
    const ld = productLd(view.plan, view.location, 'desc');
    const names = (ld.additionalProperty as any[]).map((p) => p.name);
    expect(names).toEqual(specRows(view.plan).map((r) => r.label));
    const ram = (ld.additionalProperty as any[]).find((p) => p.name === 'RAM');
    expect(ram).toMatchObject({ value: 24, unitText: 'GB' });
    expect((ld.additionalProperty as any[]).find((p) => p.name === 'vCPU').value).toBe(12);
  });

  it('a spec BILLmanager contradicts is absent from the markup and from the page', () => {
    const p = structuredClone(view.plan);
    p.flags.push({ severity: 'warn', code: 'spec-mismatch', message: 'vCPU: calc feed 8 vs BILLmanager description 6' });
    expect(specRows(p).map((r) => r.label)).not.toContain('vCPU');
    const names = (productLd(p, view.location, 'd').additionalProperty as any[]).map((x) => x.name);
    expect(names).not.toContain('vCPU');
  });

  it('item lists validate and reject nothing silently', () => {
    const ld = itemListLd('Plans', [{ name: 'A', href: '/vps/a' }, { name: 'B', href: '/vps/b' }]);
    expect(validateLd(ld as never)).toEqual([]);
    expect(validateLd({ '@context': 'https://schema.org', '@type': 'ItemList', itemListElement: [] })).toContain('ItemList is empty');
  });

  it('the validator itself catches broken markup', () => {
    const bad = productLd(view.plan, view.location, 'desc') as any;
    bad.offers[1].price = 170.97; // a number, not a decimal string
    bad.offers[2].priceSpecification.price = '1.00';
    const problems = validateLd(bad);
    expect(problems.some((x) => /offer 1: price/.test(x))).toBe(true);
    expect(problems.some((x) => /offer 2: priceSpecification disagrees/.test(x))).toBe(true);
  });
});

describe('serialization is safe to inline in HTML', () => {
  it('cannot close the script element or open a comment, and round-trips', () => {
    const evil = { name: '</script><script>alert(1)</script><!-- & \u2028', n: 1 };
    const s = serializeLd(evil);
    expect(s).not.toContain('</');
    expect(s).not.toContain('<!--');
    expect(s).not.toMatch(/[<>&\u2028]/);
    expect(JSON.parse(s)).toEqual(evil);
  });

  it('JsonLd renders a parseable script tag', () => {
    const html = renderToStaticMarkup(<JsonLd data={organizationLd()} />);
    expect(extractLd(html)).toEqual([organizationLd()]);
  });
});

describe('markup matches the page', () => {
  it('breadcrumb JSON-LD lists the same trail as the visible breadcrumb', () => {
    const html = renderToStaticMarkup(
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'VPS', href: '/vps' }, { label: 'Ashburn', href: '/vps/ashburn' }]} />,
    );
    const ld = extractLd(html)[0] as any;
    const visible = [...html.matchAll(/<(?:a|span)[^>]*>([^<]+)<\/(?:a|span)>/g)].map((m) => m[1]).filter((x) => x !== '/'); // drop the separators
    expect(ld.itemListElement.map((i: any) => i.name)).toEqual(visible);
  });

  it('plan page emits Product JSON-LD whose prices are all visible in the same HTML', () => {
    const html = renderToStaticMarkup(<PlanPage v={view} />);
    const lds = extractLd(html);
    expect(lds.map((l) => l['@type']).sort()).toEqual(['BreadcrumbList', 'Product']);
    for (const l of lds) expect(validateLd(l)).toEqual([]);
    const product = lds.find((l) => l['@type'] === 'Product') as any;
    const text = html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ');
    for (const o of product.offers) expect(text).toContain(Number(o.price).toLocaleString('en', { style: 'currency', currency: 'EUR' }));
  });

  it('a withheld plan emits no Product and no Offer', () => {
    const bad = planPageView(catalog, 'dedicated', '176811')!;
    const html = renderToStaticMarkup(<PlanPage v={bad} />);
    const types = extractLd(html).map((l) => l['@type']);
    expect(types).toEqual(['BreadcrumbList']);
    expect(html).not.toContain('"Offer"');
  });
});
