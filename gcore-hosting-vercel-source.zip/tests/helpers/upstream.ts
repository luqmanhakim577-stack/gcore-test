import { readFileSync } from 'node:fs';
import path from 'node:path';

const dir = path.join(__dirname, '..', 'fixtures');

export const fixture = (name: string): string => readFileSync(path.join(dir, name), 'utf8');
export const fixtureJson = <T = unknown>(name: string): T => JSON.parse(fixture(name)) as T;

/** Plans we recorded from the real BILLmanager. */
export const S2_RECORDED_IDS = ['170193', '173283', '170158', '145809', '125840', '176811'] as const;
export const HIDDEN_ID = '123762';

const hiddenBody = (id: string) => fixture('s2-hidden-123762.json').replace(/123762/g, id);

export interface FakeUpstream {
  fetch: typeof fetch;
  calls: { calc: number; billmgr: Array<{ ids: string[] }> };
  /** Mutable knobs for scenarios. */
  state: {
    calcVps: unknown[];
    calcDedicated: unknown[];
    /** Override recorded S2 plan objects by id (parsed `doc.pricelist[0]`). */
    s2Overrides: Map<string, unknown>;
    calcStatus: number;
    billmgrStatus: number;
  };
}

/**
 * A fake of both upstreams serving the recorded real responses.
 * Ids without a recording behave like plans BILLmanager does not expose anonymously.
 */
export function fakeUpstream(): FakeUpstream {
  const recorded = new Map<string, unknown>();
  for (const id of S2_RECORDED_IDS) {
    const doc = fixtureJson<{ doc: { pricelist: unknown[] } }>(`s2-${id}.json`).doc.pricelist[0];
    recorded.set(id, doc);
  }
  const state: FakeUpstream['state'] = {
    calcVps: fixtureJson<unknown[]>('calc-vps.json'),
    calcDedicated: fixtureJson<unknown[]>('calc-dedicated.json'),
    s2Overrides: new Map(),
    calcStatus: 200,
    billmgrStatus: 200,
  };
  const calls: FakeUpstream['calls'] = { calc: 0, billmgr: [] };

  const fakeFetch = (async (input: RequestInfo | URL) => {
    const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
    if (url.hostname === 'hosting-calc-prod.i.gc.onl') {
      calls.calc++;
      if (state.calcStatus !== 200) return new Response('upstream error', { status: state.calcStatus });
      const body = url.pathname.startsWith('/vps') ? state.calcVps : state.calcDedicated;
      // The real feed serves JSON as text/html; keep that quirk.
      return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } });
    }
    if (url.hostname === 'hosting.gcore.com' && url.pathname === '/billmgr') {
      const ids = (url.searchParams.get('pricelist') ?? '').split(',').filter(Boolean);
      calls.billmgr.push({ ids });
      if (state.billmgrStatus !== 200) return new Response('Gateway Time-out', { status: state.billmgrStatus });
      const firstHidden = ids.find((id) => !recorded.has(id) && !state.s2Overrides.has(id));
      if (firstHidden) return new Response(hiddenBody(firstHidden), { status: 200 });
      const plans = ids.map((id) => state.s2Overrides.get(id) ?? recorded.get(id));
      return new Response(JSON.stringify({ doc: { pricelist: plans } }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    throw new Error(`Unexpected host in test: ${url.href}`);
  }) as typeof fetch;

  return { fetch: fakeFetch, calls, state };
}
