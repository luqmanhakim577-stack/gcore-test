/**
 * Structural validation of JSON-LD against the properties we rely on (Google's Product snippet and
 * Breadcrumb requirements plus schema.org types). It checks shape and cross-consistency, not just
 * "is it JSON". Returns a list of problems; empty means valid.
 */
type Json = Record<string, unknown>;

const isObj = (v: unknown): v is Json => typeof v === 'object' && v !== null && !Array.isArray(v);
const str = (v: unknown) => typeof v === 'string' && v.length > 0;

export function extractLd(html: string): Json[] {
  const out: Json[] = [];
  for (const m of html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)) {
    const parsed = JSON.parse(m[1]!);
    for (const item of Array.isArray(parsed) ? parsed : [parsed]) out.push(item as Json);
  }
  return out;
}

function validateOffer(o: unknown, where: string, p: string[]) {
  if (!isObj(o) || o['@type'] !== 'Offer') return p.push(`${where}: not an Offer`);
  if (!/^\d+\.\d{2,4}$/.test(String(o['price']))) p.push(`${where}: price "${String(o['price'])}" is not a decimal string`);
  if (!/^[A-Z]{3}$/.test(String(o['priceCurrency']))) p.push(`${where}: bad priceCurrency`);
  if (o['availability'] !== 'https://schema.org/InStock') p.push(`${where}: availability`);
  if (!str(o['url']) || !String(o['url']).startsWith('http')) p.push(`${where}: url must be absolute`);
  const spec = o['priceSpecification'];
  if (!isObj(spec) || spec['@type'] !== 'UnitPriceSpecification') p.push(`${where}: priceSpecification`);
  else {
    if (spec['price'] !== o['price'] || spec['priceCurrency'] !== o['priceCurrency']) p.push(`${where}: priceSpecification disagrees with offer`);
    const d = spec['billingDuration'];
    if (!isObj(d) || d['unitCode'] !== 'MON' || ![1, 3, 6, 12].includes(Number(d['value']))) p.push(`${where}: billingDuration`);
  }
}

export function validateLd(node: Json): string[] {
  const p: string[] = [];
  if (node['@context'] !== 'https://schema.org') p.push('missing @context');
  switch (node['@type']) {
    case 'Organization':
      if (!str(node['name']) || !str(node['url'])) p.push('Organization needs name and url');
      break;
    case 'WebSite':
      if (!str(node['url']) || !str(node['name'])) p.push('WebSite needs url and name');
      break;
    case 'BreadcrumbList': {
      const items = node['itemListElement'];
      if (!Array.isArray(items) || items.length < 2) return [...p, 'BreadcrumbList needs >= 2 items'];
      items.forEach((it, i) => {
        if (!isObj(it) || it['@type'] !== 'ListItem') p.push(`crumb ${i}: not a ListItem`);
        else {
          if (it['position'] !== i + 1) p.push(`crumb ${i}: position ${String(it['position'])}`);
          if (!str(it['name'])) p.push(`crumb ${i}: name`);
          if (!/^https?:\/\/[^?#]+$/.test(String(it['item']))) p.push(`crumb ${i}: item must be an absolute URL without query`);
        }
      });
      break;
    }
    case 'ItemList': {
      const items = node['itemListElement'];
      if (!Array.isArray(items) || items.length === 0) return [...p, 'ItemList is empty'];
      if (node['numberOfItems'] !== items.length) p.push('ItemList numberOfItems mismatch');
      const urls = new Set<string>();
      items.forEach((it, i) => {
        if (!isObj(it) || it['position'] !== i + 1 || !str(it['url']) || !str(it['name'])) p.push(`list item ${i} invalid`);
        else {
          if (urls.has(String(it['url']))) p.push(`duplicate list url ${String(it['url'])}`);
          urls.add(String(it['url']));
        }
      });
      break;
    }
    case 'Product': {
      for (const k of ['name', 'description', 'sku', 'url', 'category']) if (!str(node[k])) p.push(`Product.${k} missing`);
      const brand = node['brand'];
      if (!isObj(brand) || brand['name'] !== 'Gcore') p.push('Product.brand');
      const offers = node['offers'];
      if (!Array.isArray(offers) || offers.length === 0) p.push('Product.offers missing');
      else offers.forEach((o, i) => validateOffer(o, `offer ${i}`, p));
      const props = node['additionalProperty'];
      if (!Array.isArray(props) || props.some((x) => !isObj(x) || x['@type'] !== 'PropertyValue' || !str(x['name']) || x['value'] === undefined)) p.push('Product.additionalProperty invalid');
      break;
    }
    case 'FAQPage': {
      const items = node['mainEntity'];
      if (!Array.isArray(items) || items.length === 0) return [...p, 'FAQPage needs questions'];
      items.forEach((q, i) => {
        const a = isObj(q) ? q['acceptedAnswer'] : undefined;
        if (!isObj(q) || q['@type'] !== 'Question' || !str(q['name'])) p.push(`question ${i} invalid`);
        else if (!isObj(a) || a['@type'] !== 'Answer' || !str(a['text'])) p.push(`question ${i} has no answer text`);
      });
      break;
    }
    case 'DefinedTermSet': {
      const terms = node['hasDefinedTerm'];
      if (!str(node['@id']) || !str(node['name']) || !str(node['url'])) p.push('DefinedTermSet needs @id, name and url');
      if (!Array.isArray(terms) || terms.length === 0) return [...p, 'DefinedTermSet has no terms'];
      terms.forEach((t, i) => {
        if (!isObj(t) || t['@type'] !== 'DefinedTerm' || !str(t['name']) || !str(t['description'])) p.push(`term ${i} invalid`);
        else if (t['inDefinedTermSet'] !== node['@id']) p.push(`term ${i} points at another set`);
      });
      break;
    }
    default:
      p.push(`unexpected @type ${String(node['@type'])}`);
  }
  return p;
}
