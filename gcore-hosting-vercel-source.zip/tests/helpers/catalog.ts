import { parseCalcFeed } from '@/lib/billmanager/calc-feed';
import { parsePricelistExport } from '@/lib/billmanager/pricelist';
import { buildCatalog } from '@/lib/catalog/build';
import type { Catalog } from '@/lib/catalog/model';
import type { S2State } from '@/lib/catalog/normalize';
import { MemoryStore } from '@/lib/catalog/store';
import { resetCatalogMemo } from '@/lib/catalog/read';
import { MemoryLimits } from '@/lib/security/limits';
import { fixture, HIDDEN_ID, S2_RECORDED_IDS } from './upstream';

export const FIXTURE_NOW = '2026-11-01T12:00:00.000Z';

/** The real recorded feeds + BILLmanager responses, run through the production normalizer. */
export function fixtureCatalog(version = 1): Catalog {
  const s2 = new Map<string, S2State>();
  for (const id of S2_RECORDED_IDS) {
    const r = parsePricelistExport(fixture(`s2-${id}.json`));
    if (!r.ok) throw new Error('fixture must parse');
    s2.set(id, { status: 'ok', plan: r.plans[0]!, at: FIXTURE_NOW });
  }
  s2.set(HIDDEN_ID, { status: 'not-public', at: FIXTURE_NOW });
  const feeds = (['vps', 'dedicated'] as const).map((kind) => {
    const f = parseCalcFeed(kind, fixture(kind === 'vps' ? 'calc-vps.json' : 'calc-dedicated.json'), FIXTURE_NOW);
    return { kind, rows: f.rows, fetchedAt: FIXTURE_NOW };
  });
  return buildCatalog({ feeds, s2, billmanagerBaseUrl: 'https://hosting.gcore.com', version, now: FIXTURE_NOW });
}

/** Install a fresh in-memory store (optionally seeded) and fresh limits as the process-wide singletons. */
export async function installTestStore(seed?: Catalog): Promise<MemoryStore> {
  const store = new MemoryStore();
  if (seed) await store.publish(seed, { version: seed.version, lastCheckedAt: new Date().toISOString(), lastPublishedAt: FIXTURE_NOW });
  const g = globalThis as unknown as { __catalogStore?: unknown; __limits?: unknown };
  g.__catalogStore = store;
  g.__limits = new MemoryLimits();
  resetCatalogMemo();
  return store;
}
