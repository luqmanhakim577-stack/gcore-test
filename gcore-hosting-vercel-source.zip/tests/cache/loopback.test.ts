import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { handleRevalidate, type InternalDeps } from '@/lib/api/internal-handlers';
import { loopbackApply } from '@/lib/cache/loopback';
import { resetEnvCache } from '@/lib/env';
import { MemoryLimits } from '@/lib/security/limits';

const SECRET = 'loop-back-'.repeat(4);

let announced: string[];
let local: string[];
let deps: InternalDeps;

/** A fetch that delivers the request to the real internal handler, as the replica's own server would. */
const toHandler: typeof fetch = async (input, init) => handleRevalidate(new Request(input as URL, init), deps);

beforeEach(() => {
  process.env.REVALIDATE_HMAC_SECRET = SECRET;
  resetEnvCache();
  (globalThis as unknown as { __limits: MemoryLimits }).__limits = new MemoryLimits();
  announced = [];
  local = [];
  deps = {
    revalidate: async (tags) => void announced.push(...tags),
    revalidateLocal: (tags) => void local.push(...tags),
  };
});
afterEach(() => {
  delete process.env.REVALIDATE_HMAC_SECRET;
  delete process.env.PORT;
  delete process.env.INTERNAL_BASE_URL;
  resetEnvCache();
});

describe('loopback revalidation', () => {
  it('is accepted by the internal endpoint and applies to this replica only', async () => {
    await loopbackApply({ fetchImpl: toHandler })(['plan:1', 'site']);
    expect(local).toEqual(['plan:1', 'site']);
    expect(announced).toEqual([]); // not echoed back to the fleet
  });

  it('sends the signed request to this replica own address', async () => {
    process.env.PORT = '4321';
    let url = '';
    await loopbackApply({ fetchImpl: async (i, init) => { url = String(i); return toHandler(i, init); } })(['catalog']);
    expect(url).toBe('http://127.0.0.1:4321/api/internal/revalidate');
    process.env.INTERNAL_BASE_URL = 'http://web.internal:8080';
    await loopbackApply({ fetchImpl: async (i, init) => { url = String(i); return toHandler(i, init); } })(['catalog']);
    expect(url).toBe('http://web.internal:8080/api/internal/revalidate');
  });

  it('fails clearly (so the tags are retried) without a secret, or when the server refuses', async () => {
    delete process.env.REVALIDATE_HMAC_SECRET;
    resetEnvCache();
    await expect(loopbackApply({ fetchImpl: toHandler })(['catalog'])).rejects.toThrow(/REVALIDATE_HMAC_SECRET/);

    process.env.REVALIDATE_HMAC_SECRET = SECRET; // the server has a secret; the caller signs with another one
    resetEnvCache();
    await expect(loopbackApply({ secret: 'z'.repeat(40), fetchImpl: toHandler })(['catalog'])).rejects.toThrow(/401/); // wrong secret
    expect(local).toEqual([]);
  });
});
