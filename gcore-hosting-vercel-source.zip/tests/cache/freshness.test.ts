/**
 * One freshness story, end to end: the catalog is re-synced every SYNC_INTERVAL_MINUTES, and nothing downstream
 * may keep serving a page or a response for longer than that without a reason. Next requires `revalidate` to be
 * a literal in each route file, so the constant cannot be imported there: this test keeps the literals honest.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { PUBLIC_CACHE } from '@/lib/api/http';
import { SYNC_INTERVAL_MINUTES } from '@/lib/site';

const INTERVAL_SECONDS = SYNC_INTERVAL_MINUTES * 60;
const src = path.join(process.cwd(), 'src');

function sources(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = path.join(dir, n);
    return statSync(p).isDirectory() ? sources(p) : /\.(ts|tsx)$/.test(n) ? [p] : [];
  });
}

describe('freshness windows', () => {
  it('every route-level `revalidate` equals the sync interval', () => {
    const found: Array<[string, number]> = [];
    for (const f of sources(path.join(src, 'app'))) {
      const m = /export const revalidate = (\d+)/.exec(readFileSync(f, 'utf8'));
      if (m) found.push([path.relative(src, f), Number(m[1])]);
    }
    expect(found.length).toBeGreaterThan(10); // the scan really found the routes
    expect(found.filter(([, v]) => v !== INTERVAL_SECONDS)).toEqual([]);
  });

  it('the page-data safety net equals the sync interval', () => {
    const m = /const SAFETY_NET_SECONDS = (\d+)/.exec(readFileSync(path.join(src, 'lib', 'catalog', 'page-data.ts'), 'utf8'));
    expect(Number(m?.[1])).toBe(INTERVAL_SECONDS);
  });

  it('shared caches may not serve the public API stale for long while refreshing', () => {
    const maxAge = Number(/s-maxage=(\d+)/.exec(PUBLIC_CACHE)![1]);
    const swr = Number(/stale-while-revalidate=(\d+)/.exec(PUBLIC_CACHE)![1]);
    expect(maxAge).toBeLessThanOrEqual(INTERVAL_SECONDS);
    expect(swr).toBeLessThanOrEqual(60);
    expect(PUBLIC_CACHE).toMatch(/stale-if-error=\d+/); // an old price is better than an error
  });
});
