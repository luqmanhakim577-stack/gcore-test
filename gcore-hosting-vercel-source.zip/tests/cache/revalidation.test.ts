import { describe, expect, it } from 'vitest';
import { MAX_TAGS_PER_ANNOUNCEMENT, Revalidator } from '@/lib/cache/revalidator';
import {
  MemoryRevalidationLog,
  RedisRevalidationLog,
  type RevalidationLog,
} from '@/lib/cache/revalidation-log';
import { SITE_TAG, isValidTag } from '@/lib/cache/tags';
import { FakeRedis } from '../../scripts/lib/fake-redis';

const logs: Array<[string, () => { log: RevalidationLog; redis?: FakeRedis }]> = [
  ['memory log', () => ({ log: new MemoryRevalidationLog() })],
  [
    'redis stream log',
    () => {
      const redis = new FakeRedis();
      return { log: new RedisRevalidationLog(redis.asRedis()), redis };
    },
  ],
];

describe.each(logs)('%s contract', (_name, make) => {
  it('is empty at first, then returns entries after a position, oldest first', async () => {
    const { log } = make();
    expect(await log.head()).toBe('0-0');
    expect(await log.readAfter('0-0', 10)).toEqual([]);

    await log.append({ origin: 'a', tags: ['catalog'], version: 7 });
    await log.append({ origin: 'b', tags: ['kind:vps', 'plan:1'] });
    const all = await log.readAfter('0-0', 10);
    expect(all.map((e) => [e.origin, e.tags, e.version])).toEqual([
      ['a', ['catalog'], 7],
      ['b', ['kind:vps', 'plan:1'], undefined],
    ]);

    const after = await log.readAfter(all[0]!.id, 10);
    expect(after.map((e) => e.origin)).toEqual(['b']);
    expect(await log.head()).toBe(all[1]!.id);
    expect(await log.readAfter(all[1]!.id, 10)).toEqual([]);
  });

  it('honours the batch limit', async () => {
    const { log } = make();
    for (let i = 0; i < 5; i++) await log.append({ origin: 'a', tags: [`plan:${i}`] });
    expect(await log.readAfter('0-0', 2)).toHaveLength(2);
  });
});

describe('redis stream log', () => {
  it('uses atomic XADD with a bounded length and expires an abandoned stream', async () => {
    const redis = new FakeRedis();
    const log = new RedisRevalidationLog(redis.asRedis());
    await log.append({ origin: 'a', tags: ['catalog'] });
    expect(redis.commands.some((c) => c.startsWith('xadd gcore:revalidation MAXLEN ~ 1000 *'))).toBe(true);
    expect(redis.commands.some((c) => c.startsWith('pexpire gcore:revalidation'))).toBe(true);
  });

  it('skips a malformed entry instead of applying or crashing on it', async () => {
    const redis = new FakeRedis();
    const log = new RedisRevalidationLog(redis.asRedis());
    await redis.xadd('gcore:revalidation', '*', 'o', 'x', 't', '{not json');
    await redis.xadd('gcore:revalidation', '*', 'o', 'x', 't', '"a string, not a list"');
    await redis.xadd('gcore:revalidation', '*', 'o', 'x', 't', '[1,2]');
    await log.append({ origin: 'a', tags: ['catalog'] });
    expect((await log.readAfter('0-0', 10)).map((e) => e.tags)).toEqual([['catalog']]);
  });
});

describe('tags', () => {
  it('accepts the project tag shapes and nothing else', () => {
    for (const ok of ['site', 'catalog', 'plan:170193', 'location:new-york', 'kind:vps', 'group:dedicated:xeon-e5-2680']) expect(isValidTag(ok), ok).toBe(true);
    for (const bad of ['', 'all', 'plan:../x', 'plan:', 'kind:other', 'group:vps:', 'catalog\n', 'plan:1;drop', 42, null, undefined]) expect(isValidTag(bad), String(bad)).toBe(false);
  });
});

/** A small fleet sharing one log; each replica records what it applied to its own cache. */
function replica(log: RevalidationLog, id: string, over: Partial<ConstructorParameters<typeof Revalidator>[0]> = {}) {
  const applied: string[][] = [];
  const rev = new Revalidator({ log, replicaId: id, applyLocal: (tags) => void applied.push(tags), ...over });
  return { rev, applied, flat: () => applied.flat() };
}

describe('Revalidator', () => {
  it('applies on the announcing replica at once and on the others when they poll', async () => {
    const log = new MemoryRevalidationLog();
    const a = replica(log, 'a');
    const b = replica(log, 'b');
    const c = replica(log, 'c');
    await b.rev.poll(); // replicas record the log position when they start
    await c.rev.poll();

    const res = await a.rev.announce(['plan:1', 'kind:vps', 'plan:1'], 5);
    expect(res).toEqual({ propagated: true });
    expect(a.flat()).toEqual(['plan:1', 'kind:vps']); // immediately, deduplicated

    expect(await b.rev.poll()).toBe(2);
    expect(await c.rev.poll()).toBe(2);
    expect(b.flat().sort()).toEqual(['kind:vps', 'plan:1']);

    // nothing is replayed twice, and the announcer does not re-apply its own announcement
    expect(await b.rev.poll()).toBe(0);
    expect(await a.rev.poll()).toBe(0);
    expect(a.applied).toHaveLength(1);
  });

  it('merges several announcements into one application per poll', async () => {
    const log = new MemoryRevalidationLog();
    const a = replica(log, 'a');
    const b = replica(log, 'b');
    await b.rev.poll();
    await a.rev.announce(['plan:1', 'catalog']);
    await a.rev.announce(['plan:2', 'catalog']);
    await b.rev.poll();
    expect(b.applied).toHaveLength(1);
    expect([...b.applied[0]!].sort()).toEqual(['catalog', 'plan:1', 'plan:2']);
  });

  it('a replica that starts later does not replay history (boot reconciliation covers that)', async () => {
    const log = new MemoryRevalidationLog();
    const a = replica(log, 'a');
    await a.rev.announce(['plan:1']);
    const late = replica(log, 'late');
    expect(await late.rev.poll()).toBe(0);
    expect(late.applied).toEqual([]);
  });

  it('never applies a tag from the log that is not a valid tag', async () => {
    const log = new MemoryRevalidationLog();
    const b = replica(log, 'b');
    await b.rev.poll();
    await log.append({ origin: 'attacker', tags: ['plan:../../etc', 'kind:vps', '__proto__', 'x'.repeat(500)] });
    await b.rev.poll();
    expect(b.flat()).toEqual(['kind:vps']);
  });

  it('drops invalid tags when announcing and announces nothing when none are valid', async () => {
    const log = new MemoryRevalidationLog();
    const a = replica(log, 'a');
    await a.rev.announce(['nonsense', 'plan:../x']);
    expect(a.applied).toEqual([]);
    expect(await log.head()).toBe('0-0');
  });

  it('collapses a very large change set into the site tag', async () => {
    const log = new MemoryRevalidationLog();
    const a = replica(log, 'a');
    const many = Array.from({ length: MAX_TAGS_PER_ANNOUNCEMENT + 1 }, (_, i) => `plan:${i}`);
    await a.rev.announce(many);
    expect(a.applied).toEqual([[SITE_TAG]]);
    expect((await log.readAfter('0-0', 5))[0]?.tags).toEqual([SITE_TAG]);
  });

  it('reads past one batch when many announcements piled up', async () => {
    const log = new MemoryRevalidationLog();
    const a = replica(log, 'a');
    const b = replica(log, 'b');
    await b.rev.poll();
    for (let i = 0; i < 450; i++) await log.append({ origin: 'a', tags: [`plan:${i}`] });
    await a.rev.poll();
    expect(await b.rev.poll()).toBe(450);
  });

  describe('failures', () => {
    it('keeps the tags and retries when this replica cannot apply them yet, without losing the announcement', async () => {
      const log = new MemoryRevalidationLog();
      let ready = false;
      const seen: string[][] = [];
      const a = new Revalidator({
        log,
        replicaId: 'a',
        applyLocal: (tags) => {
          if (!ready) throw new Error('ECONNREFUSED (server not listening yet)');
          seen.push(tags);
        },
      });
      const res = await a.announce(['plan:1']);
      expect(res).toEqual({ propagated: true }); // the others still hear about it
      expect(seen).toEqual([]);

      await a.tick();
      expect(seen).toEqual([]); // still not ready: kept
      ready = true;
      await a.tick();
      expect(seen).toEqual([['plan:1']]);
      await a.tick();
      expect(seen).toHaveLength(1); // not applied again
    });

    it('reports (does not throw) when the log is unreachable, and the local replica is still revalidated', async () => {
      const redis = new FakeRedis();
      const a = replica(new RedisRevalidationLog(redis.asRedis()), 'a');
      redis.down = true;
      await expect(a.rev.announce(['kind:vps'])).resolves.toEqual({ propagated: false });
      expect(a.flat()).toEqual(['kind:vps']);
    });

    it('survives a poll while Redis is down and catches up afterwards', async () => {
      const redis = new FakeRedis();
      const log = new RedisRevalidationLog(redis.asRedis());
      const a = replica(log, 'a');
      const b = replica(log, 'b');
      await b.rev.poll();
      await a.rev.announce(['plan:9']);

      redis.down = true;
      await expect(b.rev.poll()).resolves.toBe(0);
      redis.down = false;
      expect(await b.rev.poll()).toBe(1);
      expect(b.flat()).toEqual(['plan:9']);
    });
  });

  describe('boot reconciliation', () => {
    const boot = (buildId: string, live: string | null | Error) => ({
      buildId,
      liveId: async () => {
        if (live instanceof Error) throw live;
        return live;
      },
    });

    it('does nothing when the image was built from the live snapshot', async () => {
      const r = replica(new MemoryRevalidationLog(), 'a', { boot: boot('3@t', '3@t') });
      await r.rev.tick();
      expect(r.applied).toEqual([]);
    });

    it('revalidates everything once when the live snapshot is a different one', async () => {
      const r = replica(new MemoryRevalidationLog(), 'a', { boot: boot('3@t', '9@later') });
      await r.rev.tick();
      await r.rev.tick();
      expect(r.applied).toEqual([[SITE_TAG]]);
    });

    it('does nothing while the store has no snapshot', async () => {
      const r = replica(new MemoryRevalidationLog(), 'a', { boot: boot('none', null) });
      await r.rev.tick();
      expect(r.applied).toEqual([]);
    });

    it('is retried until the store answers', async () => {
      let live: string | Error = new Error('redis down');
      const log = new MemoryRevalidationLog();
      const r = replica(log, 'a', { boot: { buildId: '1@a', liveId: async () => { if (live instanceof Error) throw live; return live; } } });
      await r.rev.tick();
      expect(r.applied).toEqual([]);
      live = '2@b';
      await r.rev.tick();
      expect(r.applied).toEqual([[SITE_TAG]]);
    });

    it('replays announcements made after the replica took its position, not before', async () => {
      const log = new MemoryRevalidationLog();
      const other = replica(log, 'other');
      await other.rev.announce(['plan:old']); // before the new replica exists
      const r = replica(log, 'new', { boot: boot('1@a', '1@a') });
      await r.rev.tick();
      await other.rev.announce(['plan:new']);
      await r.rev.tick();
      expect(r.flat()).toEqual(['plan:new']);
    });
  });
});
