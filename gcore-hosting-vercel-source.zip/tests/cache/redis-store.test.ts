import { describe, expect, it } from 'vitest';
import { RedisStore } from '@/lib/catalog/store';
import { RedisLimits } from '@/lib/security/limits';
import { fixtureCatalog, FIXTURE_NOW } from '../helpers/catalog';
import { FakeRedis } from '../../scripts/lib/fake-redis';

const meta = (version: number) => ({ version, lastCheckedAt: FIXTURE_NOW, lastPublishedAt: FIXTURE_NOW });
const DAY = 24 * 3600_000;

describe('RedisStore (against a fake Redis)', () => {
  it('publishes and reads back the live snapshot and its metadata', async () => {
    const redis = new FakeRedis();
    const store = new RedisStore(redis.asRedis());
    expect(await store.getLive()).toBeNull();
    const c = fixtureCatalog(1);
    await store.publish(c, meta(1));
    expect((await store.getLive())?.plans.length).toBe(c.plans.length);
    expect((await store.getMeta())?.version).toBe(1);
  });

  it('keeps serving the live snapshot however long syncs fail (no expiry on the live version)', async () => {
    let t = Date.parse(FIXTURE_NOW);
    const redis = new FakeRedis(() => t);
    const store = new RedisStore(redis.asRedis());
    await store.publish(fixtureCatalog(1), meta(1));
    expect(await redis.ttl('gcore:catalog:v:1')).toBe(-1);
    t += 90 * DAY; // upstream unreachable for three months
    expect((await store.getLive())?.version).toBe(1);
  });

  it('lets a superseded snapshot expire shortly after the pointer moves', async () => {
    let t = Date.parse(FIXTURE_NOW);
    const redis = new FakeRedis(() => t);
    const store = new RedisStore(redis.asRedis());
    await store.publish(fixtureCatalog(1), meta(1));
    await store.publish(fixtureCatalog(2), meta(2));
    expect(await redis.ttl('gcore:catalog:v:2')).toBe(-1);
    const ttl = await redis.ttl('gcore:catalog:v:1');
    expect(ttl).toBeGreaterThan(0);
    expect(ttl).toBeLessThanOrEqual(3600);
    t += 2 * 3600_000;
    expect(await redis.get('gcore:catalog:v:1')).toBeNull();
    expect((await store.getLive())?.version).toBe(2);
  });

  it('writes the snapshot before moving the pointer, so a reader never sees a pointer to nothing', async () => {
    const redis = new FakeRedis();
    await new RedisStore(redis.asRedis()).publish(fixtureCatalog(4), meta(4));
    const writes = redis.commands.filter((c) => c.startsWith('set '));
    expect(writes.map((c) => c.split(' ')[1])).toEqual(['gcore:catalog:v:4', 'gcore:catalog:live', 'gcore:catalog:meta']);
  });

  describe('sync lock', () => {
    it('is exclusive, expires, and is released only by its owner', async () => {
      let t = 0;
      const redis = new FakeRedis(() => t);
      const a = new RedisStore(redis.asRedis());
      const token = await a.acquireLock(10_000);
      expect(token).toBeTruthy();
      expect(await a.acquireLock(10_000)).toBeNull(); // single flight

      await a.releaseLock('someone-elses-token');
      expect(await a.acquireLock(10_000)).toBeNull(); // wrong token: still held

      await a.releaseLock(token!);
      const second = await a.acquireLock(10_000);
      expect(second).toBeTruthy();

      t += 11_000; // holder crashed: the lock expires by itself
      expect(await a.acquireLock(10_000)).toBeTruthy();
    });
  });
});

describe('RedisLimits (against a fake Redis)', () => {
  it('counts hits in a window and resets after it', async () => {
    let t = 0;
    const redis = new FakeRedis(() => t);
    const limits = new RedisLimits(redis.asRedis());
    expect((await limits.hit('k', 60)).count).toBe(1);
    expect((await limits.hit('k', 60)).count).toBe(2);
    const third = await limits.hit('k', 60);
    expect(third.count).toBe(3);
    expect(third.resetIn).toBeLessThanOrEqual(60);
    t += 61_000;
    expect((await limits.hit('k', 60)).count).toBe(1);
  });

  it('once() is true the first time inside the TTL and false after, true again when it expires', async () => {
    let t = 0;
    const limits = new RedisLimits(new FakeRedis(() => t).asRedis());
    expect(await limits.once('nonce-1', 600)).toBe(true);
    expect(await limits.once('nonce-1', 600)).toBe(false);
    expect(await limits.once('nonce-2', 600)).toBe(true);
    t += 601_000;
    expect(await limits.once('nonce-1', 600)).toBe(true);
  });
});
