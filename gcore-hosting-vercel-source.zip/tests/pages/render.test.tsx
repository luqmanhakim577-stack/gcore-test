import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import {
  HomePage,
  HubPage,
  KindLocationPage,
  LocationDetailPage,
  LocationsIndexPage,
  PlanPage,
  hubMetadata,
  kindLocationMetadata,
  planMetadata,
} from '@/components/pages';
import { PERIODS } from '@/lib/catalog/money';
import {
  hubView,
  homeView,
  locationDetailView,
  locationPageView,
  locationsIndexView,
  planPageView,
  planPath,
} from '@/lib/catalog/views';
import { formatMoney } from '@/lib/format';
import { fixtureCatalog } from '../helpers/catalog';

const catalog = fixtureCatalog();
const html = (el: React.ReactElement) => renderToStaticMarkup(el);
const esc = (s: string) => s.replace(/&/g, '&amp;');
const count = (s: string, needle: string) => s.split(needle).length - 1;

describe('server-rendered HTML contains every commercial fact (no JavaScript involved)', () => {
  const view = locationPageView(catalog, 'vps', 'ashburn')!;
  const out = html(<KindLocationPage v={view} />);

  it('has every plan name, every billing period price, and every order link', () => {
    expect(view.plans.length).toBeGreaterThan(1);
    for (const plan of view.plans) {
      expect(out).toContain(`${planPath(plan)}"`);
      for (const p of PERIODS) {
        expect(out, `${plan.id} ${p} price`).toContain(formatMoney(plan.prices[p]));
        expect(out, `${plan.id} ${p} order link`).toContain(`href="${esc(plan.order.byPeriod[p]!)}"`);
        expect(out).toContain(`data-period="${p}"`);
      }
    }
  });

  it('has real specs, units and the billing-period selector as plain form controls', () => {
    expect(out).toContain('12 vCPU'.replace(' vCPU', '')); // vCPU count cell
    expect(out).toContain('24 GB');
    expect(out).toContain('500 GB SSD');
    expect(out).toContain('200 Mbit/s');
    expect(out).toContain('Unmetered');
    for (const p of PERIODS) expect(out).toContain(`id="period-${p}"`);
    expect(out).toContain('checked=""');
    expect(count(out, 'checked=""')).toBe(1);
  });

  it('is semantic: one h1, a captioned table with header cells, breadcrumbs, no script tags', () => {
    expect(count(out, '<h1')).toBe(1);
    expect(out).toContain('<caption');
    expect(out).toContain('scope="col"');
    expect(out).toContain('aria-label="Breadcrumb"');
    // the only scripts are inert JSON-LD data blocks; no executable script in server-rendered page content
    expect(out.replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/g, '')).not.toContain('<script');
    expect(out).not.toMatch(/onclick=|javascript:/i);
  });

  it('links onward: other locations and the kind hub', () => {
    expect(out).toContain('href="/vps"');
    expect(out).toContain('href="/vps/istanbul"');
  });
});

describe('plan page', () => {
  const v = planPageView(catalog, 'vps', '170193')!;
  const out = html(<PlanPage v={v} />);

  it('lists all four billing periods with price, per-month equivalent, saving and order link', () => {
    for (const p of PERIODS) {
      expect(out).toContain(formatMoney(v.plan.prices[p]));
      expect(out).toContain(`href="${esc(v.plan.order.byPeriod[p]!)}"`);
    }
    expect(out).toContain('€47.99'); // 575.90 / 12
    expect(out).toContain('20%'); // annual saving, derived from BILLmanager's own prices
    expect(out).toContain('1 month');
    expect(out).toContain('12 months');
  });

  it('shows specs and every order link points at the BILLmanager host', () => {
    expect(out).toContain('500 GB SSD');
    const hrefs = [...out.matchAll(/href="(https:[^"]+)"/g)].map((m) => m[1]!);
    // 4 in the price table + 1 in the configurator + 4 for the sibling plan shown in "other VPS in Ashburn"
    expect(hrefs).toHaveLength(9);
    for (const p of PERIODS) expect(hrefs).toContain(esc(v.plan.order.byPeriod[p]!));
    for (const h of hrefs) expect(new URL(h.replace(/&amp;/g, '&')).origin).toBe('https://hosting.gcore.com');
  });

  it('metadata: unique title with price, canonical = plan path, indexable', () => {
    const m = planMetadata(v);
    expect(m.title).toBe('VPS KVM-HIGHCPU-SSD-4 in Ashburn: from €59.99/month');
    expect(m.alternates?.canonical).toBe('/vps/ashburn/kvm-highcpu-ssd-4-170193');
    expect(m.robots).toBeUndefined();
    expect(String(m.description)).toContain('12 vCPU, 24 GB RAM, 500 GB SSD');
  });
});

describe('a plan whose pricing cannot be trusted', () => {
  const v = planPageView(catalog, 'dedicated', '176811')!;
  const out = html(<PlanPage v={v} />);

  it('shows no price and no order button, only an honest notice', () => {
    expect(out).not.toContain('€693.00');
    expect(out).not.toContain('€3,087.00');
    expect(out).not.toContain('hosting.gcore.com');
    expect(out).not.toContain('>Order');
    expect(out).toContain('currently unavailable');
  });

  it('is noindex', () => {
    expect(planMetadata(v).robots).toEqual({ index: false, follow: true });
    expect(String(planMetadata(v).title)).not.toMatch(/€/);
  });
});

describe('hubs, locations and home', () => {
  it('hub lists locations with their from price', () => {
    const v = hubView(catalog, 'dedicated');
    const out = html(<HubPage v={v} />);
    for (const l of v.locations) {
      expect(out).toContain(`/dedicated-servers/${l.location.slug}`);
      expect(out).toContain(formatMoney(l.from));
    }
    expect(count(out, '<h1')).toBe(1);
    expect(hubMetadata(v).alternates?.canonical).toBe('/dedicated-servers');
  });

  it('location metadata is unique per kind and place', () => {
    const a = kindLocationMetadata(locationPageView(catalog, 'vps', 'ashburn')!);
    const b = kindLocationMetadata(locationPageView(catalog, 'dedicated', 'ashburn')!);
    expect(a.title).not.toEqual(b.title);
    expect(a.alternates?.canonical).toBe('/vps/ashburn');
    expect(b.alternates?.canonical).toBe('/dedicated-servers/ashburn');
  });

  it('home, locations index and location detail render prices and links', () => {
    const home = html(<HomePage v={homeView(catalog)} />);
    expect(home).toContain('href="/vps"');
    expect(home).toContain('href="/dedicated-servers"');
    expect(home).toMatch(/from <strong[^>]*>€/);
    const idx = html(<LocationsIndexPage v={locationsIndexView(catalog)} />);
    expect(idx).toContain('/locations/ashburn');
    const det = html(<LocationDetailPage v={locationDetailView(catalog, 'ashburn')!} />);
    expect(det).toContain('href="/vps/ashburn"');
    expect(det).toContain('href="/dedicated-servers/ashburn"');
  });

  it('never prints a USD price (USD plans are not orderable, D1)', () => {
    for (const el of [<HomePage key="h" v={homeView(catalog)} />, <HubPage key="v" v={hubView(catalog, 'vps')} />]) {
      expect(html(el)).not.toContain('$');
    }
  });

  it('mentions no capability the data does not state (DDoS, NVMe, SLA, uptime)', () => {
    const pages = [
      html(<HomePage v={homeView(catalog)} />),
      html(<HubPage v={hubView(catalog, 'vps')} />),
      html(<KindLocationPage v={locationPageView(catalog, 'vps', 'ashburn')!} />),
      html(<PlanPage v={planPageView(catalog, 'vps', '170193')!} />),
    ].join('\n');
    expect(pages).not.toMatch(/ddos|nvme|sla\b|uptime|99\.\d+%/i);
  });
});
