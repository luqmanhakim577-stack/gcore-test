import { describe, expect, it } from 'vitest';
import { isTrustworthy } from '@/lib/catalog/model';
import { diffCatalogs, tagsForDiff } from '@/lib/catalog/diff';
import {
  DISPLAY_CURRENCY,
  hubView,
  listedPlans,
  locationDetailView,
  locationPageView,
  parsePlanParam,
  planKey,
  planPageView,
  planPath,
  staticParams,
} from '@/lib/catalog/views';
import { formatDisks, formatMoney, formatPort, formatRam, formatTraffic, specSummary, withheldSpecs } from '@/lib/format';
import { fixtureCatalog } from '../helpers/catalog';

const catalog = fixtureCatalog();

describe('listing rules (only BILLmanager-confirmed plans in the display currency)', () => {
  it('lists exactly the verified EUR plans, never USD, unknown or flagged ones', () => {
    const ids = [...listedPlans(catalog, 'vps'), ...listedPlans(catalog, 'dedicated')].map((p) => p.id).sort();
    expect(ids).toEqual(['125840', '145809', '170158', '170193', '173283']);
    expect(DISPLAY_CURRENCY).toBe('EUR');
  });

  it('excludes the plan with the price anomaly from lists and from "from" prices', () => {
    expect(listedPlans(catalog, 'dedicated').map((p) => p.id)).not.toContain('176811');
    const brazil = hubView(catalog, 'dedicated').locations.find((l) => l.location.id === 'sao-paulo');
    expect(brazil).toBeUndefined(); // its only recorded plan is the anomalous one
  });

  it('sorts by monthly price ascending and computes "from" from listed plans only', () => {
    const hub = hubView(catalog, 'vps');
    const prices = listedPlans(catalog, 'vps').map((p) => Number(p.prices.monthly.amount));
    expect(prices).toEqual([...prices].sort((a, b) => a - b));
    expect(hub.from).toEqual(listedPlans(catalog, 'vps')[0]!.prices.monthly);
    expect(hub.planCount).toBe(3);
  });
});

describe('page views', () => {
  it('location page: plans, from price, other locations', () => {
    const v = locationPageView(catalog, 'vps', 'ashburn')!;
    expect(v.plans.map((p) => p.id)).toEqual(['170158', '170193'].sort((a, b) => Number(catalog.plans.find((p) => p.id === a)!.prices.monthly.amount) - Number(catalog.plans.find((p) => p.id === b)!.prices.monthly.amount)));
    expect(v.from.amount).toBe('34.99');
    expect(v.otherLocations.map((o) => o.location.id)).toContain('istanbul');
  });

  it('unknown or empty locations are null (-> 404)', () => {
    expect(locationPageView(catalog, 'vps', 'atlantis')).toBeNull();
    expect(locationPageView(catalog, 'vps', 'luxembourg')).toBeNull(); // dedicated only
    expect(locationDetailView(catalog, 'atlantis')).toBeNull();
  });

  it('plan page: verified plan is orderable; anomalous plan renders but is not orderable', () => {
    const ok = planPageView(catalog, 'vps', '170193')!;
    expect(ok.orderable).toBe(true);
    expect(ok.siblingsHere.map((p) => p.id)).toEqual(['170158']);
    const bad = planPageView(catalog, 'dedicated', '176811')!;
    expect(bad.orderable).toBe(false);
    expect(isTrustworthy(bad.plan)).toBe(false);
  });

  it('plan pages are bound to their kind, and USD twins have no page', () => {
    expect(planKey(catalog, 'dedicated', '170193')).toBeNull(); // a VPS id under the dedicated route
    expect(planKey(catalog, 'vps', '123762')).toBeNull();
    const usdVps = catalog.plans.find((p) => p.kind === 'vps' && p.currency === 'USD')!;
    expect(planKey(catalog, 'vps', usdVps.id)).toBeNull();
  });

  it('the same plan in other locations is found by slug', () => {
    const v = planPageView(catalog, 'vps', '173283')!; // KVM-SSD-1 in Istanbul
    expect(v.elsewhere.every((e) => e.plan.slug === v.plan.slug && e.location.id !== v.location.id)).toBe(true);
  });
});

describe('URLs', () => {
  it('plan path = kind / location / slug-id, and parses back', () => {
    const p = catalog.plans.find((x) => x.id === '170193')!;
    expect(planPath(p)).toBe('/vps/ashburn/kvm-highcpu-ssd-4-170193');
    expect(parsePlanParam('kvm-highcpu-ssd-4-170193')).toEqual({ slug: 'kvm-highcpu-ssd-4', id: '170193' });
    const d = catalog.plans.find((x) => x.id === '145809')!;
    expect(planPath(d)).toMatch(/^\/dedicated-servers\/ashburn\/.+-145809$/);
  });
  it('rejects malformed plan params', () => {
    for (const bad of ['', '170193', 'UPPER-1', 'a-b-', '../x-1', 'x-123456789012345']) expect(parsePlanParam(bad), bad).toBeNull();
  });
  it('static params cover exactly the listed plans and locations', () => {
    const sp = staticParams(catalog);
    expect(sp.plans).toHaveLength(5);
    expect(sp.plans.every((p) => /-\d+$/.test(p.plan))).toBe(true);
    expect(sp.locations.length).toBeGreaterThan(0);
  });
});

describe('formatting', () => {
  it('money', () => {
    expect(formatMoney({ amount: '59.99', currency: 'EUR' })).toBe('€59.99');
    expect(formatMoney({ amount: '575.90', currency: 'EUR' })).toBe('€575.90');
    expect(formatMoney({ amount: '30.00', currency: 'USD' })).toBe('$30.00');
  });
  it('specs', () => {
    expect(formatRam(24576)).toBe('24 GB');
    expect(formatRam(512)).toBe('512 MB');
    expect(formatPort(200)).toBe('200 Mbit/s');
    expect(formatPort(10000)).toBe('10 Gbit/s');
    expect(formatTraffic({ kind: 'unlimited' })).toBe('Unmetered');
    expect(formatTraffic({ kind: 'metered', includedGB: 30000 })).toBe('30 TB included');
    expect(formatDisks([{ count: 2, sizeGB: 960, type: 'SSD', typeSource: 'billmanager' }, { count: 2, sizeGB: 4000, type: 'SATA', typeSource: 'billmanager' }])).toBe('2 × 960 GB SSD + 2 × 4 TB SATA');
  });
  it('summary of a real plan', () => {
    const p = catalog.plans.find((x) => x.id === '170193')!;
    expect(specSummary(p)).toBe('12 vCPU, 24 GB RAM, 500 GB SSD');
  });
  it('withholds a spec BILLmanager contradicts (Mumbai KVM-SSD-5: 8 vs 6 vCPU)', () => {
    const p = structuredClone(catalog.plans.find((x) => x.id === '170193')!);
    p.flags.push({ severity: 'warn', code: 'spec-mismatch', message: 'vCPU: calc feed 8 vs BILLmanager description 6' });
    expect([...withheldSpecs(p)]).toEqual(['vcpu']);
    expect(specSummary(p)).toBe('24 GB RAM, 500 GB SSD');
  });
});

describe('cache tags cover every page that shows a plan', () => {
  it('a change to one plan tags the plan, its location, its kind and its sibling group', () => {
    const next = structuredClone(catalog);
    const p = next.plans.find((x) => x.id === '170193')!;
    p.prices.monthly = { amount: '61.99', currency: 'EUR' };
    p.source.hash = 'changed';
    const tags = tagsForDiff(diffCatalogs(catalog, next));
    expect(tags).toEqual(
      expect.arrayContaining(['catalog', 'plan:170193', 'location:ashburn', 'kind:vps', 'group:vps:kvm-highcpu-ssd-4']),
    );
    expect(tags.filter((t) => t.startsWith('plan:'))).toEqual(['plan:170193']);
    expect(tags).not.toContain('kind:dedicated');
  });
});
