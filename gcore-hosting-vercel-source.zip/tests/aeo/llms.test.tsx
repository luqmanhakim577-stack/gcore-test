import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import { OWNER_FACTS, type OwnerFact } from '@/content/facts';
import { GLOSSARY, LEARN } from '@/content/learn';
import { ArticlePage, GlossaryPage, LearnIndexPage } from '@/components/learn';
import { catalogFacts } from '@/lib/aeo/catalog-facts';
import { llmsFullTxt, llmsTxt } from '@/lib/aeo/llms';
import { learnBlock } from '@/lib/aeo/learn-data';
import { isTrustworthy } from '@/lib/catalog/model';
import { PERIODS } from '@/lib/catalog/money';
import { listedPlans, planPath } from '@/lib/catalog/views';
import { formatMoney } from '@/lib/format';
import { sitemapEntries } from '@/lib/seo/sitemap';
import { absoluteUrl } from '@/lib/seo/config';
import { extractLd, validateLd } from '../helpers/ld';
import { fixtureCatalog } from '../helpers/catalog';

const catalog = fixtureCatalog();
const facts = catalogFacts(catalog);
const llms = llmsTxt(catalog, facts, OWNER_FACTS);
const full = llmsFullTxt(catalog, facts, OWNER_FACTS);
const listed = [...listedPlans(catalog, 'vps'), ...listedPlans(catalog, 'dedicated')];

const owner: OwnerFact = {
  id: 'ddos-frankfurt',
  topic: 'ddos',
  claim: 'Layer 3 and 4 filtering is active on the Frankfurt network.',
  scope: { type: 'location', locationId: 'frankfurt' },
  evidence: 'PROVIDER_STATED',
  source: 'Upstream datasheet v3',
  verifiedOn: '2026-10-30',
  limitations: 'Layer 7 is not covered.',
};

describe('llms.txt', () => {
  it('follows the llms.txt shape: one H1, a blockquote summary, H2 sections of links', () => {
    const lines = llms.split('\n');
    expect(lines[0]).toBe('# Gcore Hosting');
    expect(lines.filter((l) => l.startsWith('# ')).length).toBe(1);
    expect(lines.find((l) => l.startsWith('> '))).toBeDefined();
    expect(lines.filter((l) => l.startsWith('## ')).map((l) => l.slice(3))).toEqual([
      'Catalog',
      'VPS by location'.replace('VPS', 'VPS'),
      'Dedicated servers by location',
      'Data access',
      'Guides (general industry explanations, not statements about Gcore infrastructure)',
      'Optional',
    ]);
    for (const l of lines.filter((x) => x.startsWith('- ['))) expect(l).toMatch(/^- \[[^\]]+\]\(https:\/\/gcore\.hosting\/[^)\s]*\)/);
  });

  it('every internal page it links to exists in the sitemap (or is a known file/API route)', () => {
    const known = new Set([...sitemapEntries(catalog).map((e) => absoluteUrl(e.path)), ...['/api/v1/openapi.json', '/api/v1/plans', '/api/v1/locations', '/llms-full.txt', '/sitemap.xml'].map(absoluteUrl)]);
    const urls = [...llms.matchAll(/\]\((https:\/\/gcore\.hosting[^)\s]*)\)/g)].map((m) => m[1]!);
    expect(urls.length).toBeGreaterThan(10);
    expect(urls.filter((u) => !known.has(u))).toEqual([]);
  });

  it('states the reading rules and what is not published, and never a USD price or a dollar sign', () => {
    expect(llms).toMatch(/whole billing period/);
    expect(llms).toMatch(/missing is unknown or withheld/);
    expect(llms).toMatch(/not a throughput guarantee/);
    expect(llms).toMatch(/does not currently state the following about Gcore's own infrastructure/);
    expect(llms).toMatch(/DDoS protection scope/);
    expect(llms).not.toMatch(/\$\d/);
  });

  it('summary counts equal the listed plans', () => {
    expect(llms).toContain(`${facts.kinds.vps.plans} VPS plans and ${facts.kinds.dedicated.plans} dedicated server plans`);
    expect(facts.kinds.vps.plans).toBe(listedPlans(catalog, 'vps').length);
    expect(facts.kinds.dedicated.plans).toBe(listedPlans(catalog, 'dedicated').length);
  });
});

describe('llms-full.txt', () => {
  it('lists every listed plan with every billing-period price exactly as the snapshot has it, and its page URL', () => {
    expect(listed.length).toBeGreaterThan(3);
    for (const plan of listed) {
      const line = full.split('\n').find((l) => l.includes(`(id ${plan.id})`));
      expect(line, `plan ${plan.id}`).toBeDefined();
      for (const p of PERIODS) expect(line!, `${plan.id} ${p}`).toContain(formatMoney(plan.prices[p]));
      expect(line!).toContain(absoluteUrl(planPath(plan)));
    }
  });

  it('never lists a plan the site withholds, an unconfirmed plan or a USD plan', () => {
    const shown = new Set(listed.map((p) => p.id));
    const leaked = catalog.plans.filter((p) => !shown.has(p.id) && full.includes(`(id ${p.id})`));
    expect(leaked.map((p) => p.id)).toEqual([]);
    for (const p of catalog.plans.filter((x) => !isTrustworthy(x))) expect(full).not.toContain(`(id ${p.id})`);
    expect(full).not.toMatch(/\bUSD\b|\$\d/);
  });

  it('carries no order URLs and no internal fields', () => {
    expect(full).not.toContain('hosting.gcore.com');
    for (const s of ['osPrice', 'flags', 's1Hash', 'specRaw', 'billmgr?func']) expect(full).not.toContain(s);
  });

  it('includes the full guides, with their live catalog blocks, and the whole glossary', () => {
    for (const a of LEARN) {
      expect(full).toContain(`### ${a.title}`);
      for (const qa of a.qa) expect(full).toContain(`A: ${qa.a}`);
    }
    for (const t of GLOSSARY) expect(full).toContain(`- ${t.term}: ${t.definition}`);
    expect(full).toContain('#### In our catalog now');
  });

  it('says plainly that no infrastructure facts are published, and renders them with scope once they exist', () => {
    expect(full).toMatch(/Confirmed facts about Gcore infrastructure and terms\n- None published\./);
    const withFact = llmsFullTxt(catalog, facts, [owner]);
    expect(withFact).toContain('Layer 3 and 4 filtering is active on the Frankfurt network. Applies to: location frankfurt only.');
    expect(withFact).toContain('stated by a supplier or data center, not independently verified');
    expect(withFact).toContain('Upstream datasheet v3');
    expect(withFact).not.toMatch(/does not currently state the following[^\n]*DDoS protection scope/); // a published topic is no longer listed as missing
  });
});

describe('catalog facts quoted by the guides', () => {
  it('count only the plans the site lists, and respect withheld specs', () => {
    const c = structuredClone(catalog);
    const plan = c.plans.find((p) => p.id === '170193')!; // listed VPS
    const before = catalogFacts(c).kinds.vps;
    plan.flags.push({ code: 'spec-mismatch', severity: 'warn', message: 'RAM MiB: calc feed 2048 vs BILLmanager description 1024' });
    plan.flags.push({ code: 'spec-mismatch', severity: 'warn', message: 'disk GB: calc feed 80 vs BILLmanager description 40' });
    const after = catalogFacts(c).kinds.vps;
    expect(after.plans).toBe(before.plans);
    expect(after.noDiskInfo).toBe(before.noDiskInfo + 1); // its withheld disk is no longer counted
  });

  it('annual saving counts add up and the percentages are within 0 to 100', () => {
    for (const k of [facts.kinds.vps, facts.kinds.dedicated]) {
      expect(k.annualSaving.cheaper + k.annualSaving.notCheaper).toBe(k.plans);
      if (k.annualSaving.minPercent !== undefined) {
        expect(k.annualSaving.minPercent).toBeGreaterThan(0);
        expect(k.annualSaving.maxPercent!).toBeLessThan(100);
        expect(k.annualSaving.minPercent).toBeLessThanOrEqual(k.annualSaving.maxPercent!);
      }
    }
  });

  it('the DDoS guide says nothing is stated until a DDoS fact exists, then quotes the fact with its scope', () => {
    expect(learnBlock('ddos-protection-explained', facts, [])!.lines.join(' ')).toMatch(/does not currently state a DDoS protection scope/);
    const b = learnBlock('ddos-protection-explained', facts, [owner])!;
    expect(b.heading).toBe('What Gcore has confirmed');
    expect(b.lines.join(' ')).toMatch(/Applies to: location frankfurt only/);
    expect(b.lines.join(' ')).toMatch(/Limits: Layer 7 is not covered/);
  });

  it('no guide block ever says NVMe for a plan the data does not call NVMe', () => {
    const text = learnBlock('ssd-vs-nvme', facts, [])!.lines.join(' ');
    const nvmePlans = listed.filter((p) => p.specs.disks?.some((d) => d.type === 'NVMe')).length;
    expect(/NVMe on/.test(text)).toBe(nvmePlans > 0);
  });
});

describe('guide pages (server-rendered)', () => {
  it('each article has one h1, visible Q&A, the live block, valid FAQPage JSON-LD that mirrors the visible questions', () => {
    for (const a of LEARN) {
      const html = renderToStaticMarkup(<ArticlePage article={a} facts={facts} />);
      expect((html.match(/<h1[ >]/g) ?? []).length).toBe(1);
      const ld = extractLd(html);
      const faq = ld.find((n) => n['@type'] === 'FAQPage')!;
      expect(faq, a.slug).toBeDefined();
      for (const n of ld) expect(validateLd(n), `${a.slug} ${String(n['@type'])}`).toEqual([]);
      const names = (faq['mainEntity'] as Array<{ name: string }>).map((q) => q.name);
      expect(names).toEqual(a.qa.map((q) => q.q));
      for (const q of a.qa) {
        // visible, not hidden or collapsed: a heading followed by its answer, outside any <details>
        const question = q.q.replace(/&/g, '&amp;');
        expect(html).toMatch(new RegExp(`<h3 class="[^"]*">${question.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}</h3><p[^>]*>`));
        expect(html).not.toMatch(/class="[^"]*\b(hidden|sr-only)\b[^"]*">[^<]*<h3/);
      }
      expect(html).toContain('not a statement about the network'); // the general-explanation notice
      expect(html).not.toMatch(/<details/);
    }
  });

  it('the glossary renders every term visibly and validates as a DefinedTermSet', () => {
    const html = renderToStaticMarkup(<GlossaryPage />);
    const set = extractLd(html).find((n) => n['@type'] === 'DefinedTermSet')!;
    expect(validateLd(set)).toEqual([]);
    expect((set['hasDefinedTerm'] as unknown[]).length).toBe(GLOSSARY.length);
    for (const t of GLOSSARY) expect(html).toContain(t.term.replace(/&/g, '&amp;'));
  });

  it('the index links to every guide and the glossary', () => {
    const html = renderToStaticMarkup(<LearnIndexPage />);
    for (const a of LEARN) expect(html).toContain(`href="/learn/${a.slug}"`);
    expect(html).toContain('href="/learn/glossary"');
  });
});
