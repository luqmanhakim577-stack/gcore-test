import { beforeEach, describe, expect, it } from 'vitest';
import { handleLocations, handlePlan, handlePlans } from '@/lib/api/catalog-handlers';
import { PUBLIC_API_LIMIT } from '@/lib/api/http';
import { PERIODS } from '@/lib/catalog/money';
import { fixtureCatalog, installTestStore } from '../helpers/catalog';

const catalog = fixtureCatalog();
const get = (path: string, headers: Record<string, string> = {}) =>
  new Request(`http://localhost${path}`, { headers: { 'x-forwarded-for': '203.0.113.7', ...headers } });
const body = async (r: Response) => (await r.json()) as { data: any; meta: any };

beforeEach(async () => {
  await installTestStore(catalog);
});

describe('GET /api/v1/plans', () => {
  it('returns only BILLmanager-verified plans by default, with their real prices', async () => {
    const r = await handlePlans(get('/api/v1/plans'));
    expect(r.status).toBe(200);
    const { data, meta } = await body(r);
    expect(data.map((p: any) => p.id).sort()).toEqual(['125840', '145809', '170158', '170193', '173283']); // 176811 excluded: price anomaly
    expect(data.every((p: any) => p.verified)).toBe(true);
    expect(meta).toMatchObject({ total: 5, snapshotVersion: 1 });
    const p = data.find((x: any) => x.id === '170193');
    expect(p.prices.monthly).toEqual({ amount: '59.99', currency: 'EUR' });
    expect(p.prices.annually).toEqual({ amount: '575.90', currency: 'EUR' });
    expect(p.location).toMatchObject({ id: 'ashburn', country: 'USA', city: 'Ashburn' });
  });

  it('verified plans carry an order URL per billing period on the BILLmanager host; nothing else does', async () => {
    const { data } = await body(await handlePlans(get('/api/v1/plans?include=unverified&limit=500')));
    expect(data).toHaveLength(500);
    const verified = data.filter((p: any) => p.verified);
    expect(verified.length).toBeGreaterThan(0);
    for (const p of verified) {
      expect(Object.keys(p.orderUrls).sort()).toEqual([...PERIODS].sort());
      for (const u of Object.values<string>(p.orderUrls)) expect(new URL(u).origin).toBe('https://hosting.gcore.com');
    }
    for (const p of data.filter((x: any) => !x.verified)) expect(p.orderUrls).toEqual({});
  });

  it('include=unverified exposes everything, honestly labelled', async () => {
    const r = await body(await handlePlans(get('/api/v1/plans?include=unverified&limit=1')));
    expect(r.meta.total).toBe(672);
    const unknown = (await body(await handlePlans(get('/api/v1/plans?include=unverified&currency=USD&limit=1')))).data[0];
    expect(unknown.verified).toBe(false);
    expect(unknown.availability).toBe('unknown');
  });

  it('filters and paginates', async () => {
    const dedicated = await body(await handlePlans(get('/api/v1/plans?kind=dedicated&location=ashburn&include=unverified&currency=EUR')));
    expect(dedicated.data.length).toBeGreaterThan(0);
    expect(dedicated.data.every((p: any) => p.kind === 'dedicated' && p.location.id === 'ashburn' && p.currency === 'EUR')).toBe(true);

    const p1 = await body(await handlePlans(get('/api/v1/plans?include=unverified&limit=10&offset=0')));
    const p2 = await body(await handlePlans(get('/api/v1/plans?include=unverified&limit=10&offset=10')));
    expect(p1.data).toHaveLength(10);
    expect(p1.data.map((p: any) => p.id).filter((id: string) => p2.data.some((q: any) => q.id === id))).toEqual([]);
  });

  it('rejects invalid parameters with 400 and never echoes them', async () => {
    for (const q of ['kind=gpu', 'limit=0', 'limit=9999', 'offset=-1', 'currency=GBP', 'location=../etc/passwd', 'location=<script>', 'include=all']) {
      const r = await handlePlans(get(`/api/v1/plans?${q}`));
      expect(r.status, q).toBe(400);
      expect(await r.text()).not.toContain('passwd');
    }
  });

  it('never leaks internal fields', async () => {
    const text = await (await handlePlans(get('/api/v1/plans?include=unverified&limit=500'))).text();
    for (const secret of ['osPrice', 'flags', 's1Hash', 'specRaw', 'period-price-anomaly', 'no-s2']) {
      expect(text, secret).not.toContain(secret);
    }
  });

  it('supports conditional requests with an ETag bound to the snapshot version', async () => {
    const first = await handlePlans(get('/api/v1/plans'));
    const etag = first.headers.get('etag')!;
    expect(etag).toMatch(/^W\/"v1-/);
    expect(first.headers.get('cache-control')).toContain('s-maxage=300');
    const second = await handlePlans(get('/api/v1/plans', { 'if-none-match': etag }));
    expect(second.status).toBe(304);
    const other = await handlePlans(get('/api/v1/plans?kind=vps', { 'if-none-match': etag }));
    expect(other.status).toBe(200); // different query, different ETag
  });

  it('returns 503 with Retry-After before the first sync', async () => {
    await installTestStore();
    const r = await handlePlans(get('/api/v1/plans'));
    expect(r.status).toBe(503);
    expect(r.headers.get('retry-after')).toBe('60');
  });

  it('rate limits per client and sets Retry-After', async () => {
    let last!: Response;
    for (let i = 0; i < PUBLIC_API_LIMIT.limit + 1; i++) last = await handlePlans(get('/api/v1/plans?limit=1'));
    expect(last.status).toBe(429);
    expect(Number(last.headers.get('retry-after'))).toBeGreaterThan(0);
    const other = await handlePlans(get('/api/v1/plans?limit=1', { 'x-forwarded-for': '198.51.100.5' }));
    expect(other.status).toBe(200);
  });
});

describe('GET /api/v1/plans/{id}', () => {
  it('returns the plan, including unverified ones, labelled as such', async () => {
    const ok = await body(await handlePlan(get('/api/v1/plans/170193'), '170193'));
    expect(ok.data).toMatchObject({ id: '170193', verified: true, currency: 'EUR' });
    const hidden = await body(await handlePlan(get('/api/v1/plans/123762'), '123762'));
    expect(hidden.data).toMatchObject({ id: '123762', verified: false, orderUrls: {} });
  });
  it('404 for unknown ids and 400 for malformed ids', async () => {
    expect((await handlePlan(get('/x'), '999999999')).status).toBe(404);
    for (const id of ['abc', '1;DROP TABLE', '../1', '12345678901234']) expect((await handlePlan(get('/x'), id)).status, id).toBe(400);
  });
});

describe('GET /api/v1/locations', () => {
  it('lists locations with the products available there', async () => {
    const { data, meta } = await body(await handleLocations(get('/api/v1/locations')));
    expect(meta.total).toBe(data.length);
    expect(data.find((l: any) => l.id === 'luxembourg')).toMatchObject({ country: 'Luxembourg', products: ['dedicated'] });
    expect(data.find((l: any) => l.id === 'frankfurt').products).toEqual(['vps']);
  });
});
