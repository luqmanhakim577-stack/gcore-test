import SwaggerParser from '@apidevtools/swagger-parser';
import { beforeEach, describe, expect, it } from 'vitest';
import { handleLocations, handlePlan, handlePlans } from '@/lib/api/catalog-handlers';
import { buildOpenApi } from '@/lib/api/openapi';
import { locationsResponseSchema, plansQuery, planResponseSchema, plansResponseSchema, problemSchema } from '@/lib/api/schemas';
import { GET as openapiRoute } from '@/app/api/v1/openapi.json/route';
import { fixtureCatalog, installTestStore } from '../helpers/catalog';

const catalog = fixtureCatalog();
const get = (path: string) => new Request(`http://localhost${path}`, { headers: { 'x-forwarded-for': '203.0.113.9' } });

beforeEach(async () => {
  await installTestStore(catalog);
});

describe('OpenAPI document', () => {
  it('is a valid OpenAPI 3.1 document with every $ref resolvable', async () => {
    const spec = JSON.parse(JSON.stringify(buildOpenApi()));
    await expect(SwaggerParser.validate(spec)).resolves.toBeTruthy();
    expect(spec.openapi).toBe('3.1.0');
  });

  it('documents exactly the public endpoints and none of the internal ones', () => {
    const spec = buildOpenApi();
    expect(Object.keys(spec.paths).sort()).toEqual(['/api/v1/locations', '/api/v1/plans', '/api/v1/plans/{id}']);
    expect(JSON.stringify(spec)).not.toMatch(/internal|x-signature|x-nonce|hmac/i);
  });

  it('query parameters are generated from the same schema the handler enforces', () => {
    const params = buildOpenApi().paths['/api/v1/plans'].get.parameters;
    expect(params.map((p) => p.name).sort()).toEqual(Object.keys(plansQuery.shape).sort());
    const kind = params.find((p) => p.name === 'kind')!;
    expect(kind.schema).toMatchObject({ enum: ['vps', 'dedicated'] });
    const limit = params.find((p) => p.name === 'limit')!;
    expect(limit.schema).toMatchObject({ minimum: 1, maximum: 500, default: 100 });
    expect(params.every((p) => p.required === false)).toBe(true);
  });

  it('describes the semantics a machine reader must not get wrong', () => {
    const text = buildOpenApi().info.description;
    expect(text).toMatch(/BILLmanager/);
    expect(text).toMatch(/whole billing period/);
    expect(text).toMatch(/Absent means unknown/);
    expect(text).toMatch(/not a throughput guarantee/);
    expect(text).toMatch(/not the final payable amount/i);
  });

  it('the route serves it as JSON, cacheable, with the configured origin', async () => {
    const r = openapiRoute();
    expect(r.headers.get('content-type')).toContain('application/json');
    expect(r.headers.get('cache-control')).toContain('s-maxage');
    const spec = await r.json();
    expect(spec.servers[0].url).toMatch(/^https?:\/\//);
  });
});

describe('real responses conform to the documented schemas (strictly)', () => {
  it('GET /api/v1/plans, with and without unverified plans', async () => {
    for (const q of ['', '?include=unverified&limit=500', '?kind=dedicated&include=unverified&currency=EUR']) {
      const body = await (await handlePlans(get(`/api/v1/plans${q}`))).json();
      const parsed = plansResponseSchema.strict().safeParse(body);
      expect(parsed.success, JSON.stringify(parsed.error?.issues.slice(0, 3))).toBe(true);
    }
  });

  it('GET /api/v1/plans/{id}', async () => {
    const body = await (await handlePlan(get('/api/v1/plans/170193'), '170193')).json();
    expect(planResponseSchema.safeParse(body).success).toBe(true);
  });

  it('GET /api/v1/locations', async () => {
    const body = await (await handleLocations(get('/api/v1/locations'))).json();
    expect(locationsResponseSchema.safeParse(body).success).toBe(true);
  });

  it('errors are problem documents', async () => {
    for (const r of [await handlePlans(get('/api/v1/plans?kind=gpu')), await handlePlan(get('/x'), '999999999')]) {
      expect(problemSchema.safeParse(await r.json()).success).toBe(true);
    }
  });
});

describe('withheld specs are withheld in the API too', () => {
  it('a spec the page refuses to state is absent from the API plan', async () => {
    const withheld = catalog.plans.filter((p) => p.flags.some((f) => f.code === 'spec-mismatch' && f.message.startsWith('vCPU:')));
    // The recorded fixtures may not include such a plan; synthesise the flag on a real one so the rule is always exercised.
    const base = catalog.plans.find((p) => p.id === '170193')!;
    const plan = withheld[0] ?? { ...base, flags: [...base.flags, { code: 'spec-mismatch', severity: 'warn' as const, message: 'vCPU: calc feed 8 vs BILLmanager description 6' }] };
    expect(plan.specs.vcpu).toBeDefined();
    const { toPublicPlan, locationMap } = await import('@/lib/catalog/public');
    const pub = toPublicPlan(plan, locationMap(catalog));
    expect(pub.specs.vcpu).toBeUndefined();
    expect(pub.specs.ramMiB).toBe(plan.specs.ramMiB); // only the contradicted field is dropped
  });
});
