import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { handleHealth, handleRevalidate, handleSync, type InternalDeps } from '@/lib/api/internal-handlers';
import { resetEnvCache } from '@/lib/env';
import { MemoryLimits } from '@/lib/security/limits';
import { signRequest } from '@/lib/security/hmac';
import type { MemoryStore } from '@/lib/catalog/store';
import type { SyncConfig } from '@/lib/catalog/sync';
import { installTestStore } from '../helpers/catalog';
import { fakeUpstream, type FakeUpstream } from '../helpers/upstream';

const SECRET = 's3cr3t-'.repeat(8);
const SYNC = '/api/internal/sync';
const REVAL = '/api/internal/revalidate';

let up: FakeUpstream;
let store: MemoryStore;
let revalidated: string[];
let revalidatedLocal: string[];
let announcedVersions: Array<number | undefined>;
let deps: InternalDeps;

const syncConfig = (): SyncConfig => ({
  calcBaseUrl: 'https://hosting-calc-prod.i.gc.onl',
  billmanagerBaseUrl: 'https://hosting.gcore.com',
  s2Currencies: ['EUR'],
  s2BatchSize: 5,
  s2Concurrency: 2,
  s2MaxAgeMs: 6 * 3600_000,
  maxDropRatio: 0.2,
  s2BackoffMs: 0,
  fetchImpl: up.fetch,
});

function req(path: string, bodyText = '', over: { headers?: Record<string, string>; sign?: boolean; nonce?: string; now?: number } = {}) {
  const signed = over.sign === false ? {} : signRequest(SECRET, 'POST', path, bodyText, { nonce: over.nonce, now: over.now });
  return new Request(`http://localhost${path}`, {
    method: 'POST',
    body: bodyText || undefined,
    headers: { 'x-forwarded-for': '203.0.113.50', ...signed, ...over.headers },
  });
}

beforeEach(async () => {
  process.env.REVALIDATE_HMAC_SECRET = SECRET;
  resetEnvCache();
  up = fakeUpstream();
  store = await installTestStore();
  revalidated = [];
  revalidatedLocal = [];
  announcedVersions = [];
  deps = {
    revalidate: async (tags, version) => {
      revalidated.push(...tags);
      announcedVersions.push(version);
    },
    revalidateLocal: (tags) => void revalidatedLocal.push(...tags),
    store,
    syncConfig,
  };
});
afterEach(() => {
  delete process.env.REVALIDATE_HMAC_SECRET;
  resetEnvCache();
  vi.restoreAllMocks();
});

describe('internal endpoint authentication', () => {
  it('is disabled (503) when no secret is configured', async () => {
    delete process.env.REVALIDATE_HMAC_SECRET;
    resetEnvCache();
    const r = await handleSync(req(SYNC, '', { sign: false }), deps);
    expect(r.status).toBe(503);
  });

  it('rejects unsigned, wrongly signed and stale requests with an identical 401', async () => {
    const unsigned = await handleSync(req(SYNC, '', { sign: false }), deps);
    const wrong = await handleSync(req(SYNC, '', { headers: { 'x-signature': 'a'.repeat(64) } }), deps);
    const stale = await handleSync(req(SYNC, '', { now: Date.now() - 3600_000 }), deps);
    for (const r of [unsigned, wrong, stale]) expect(r.status).toBe(401);
    const bodies = await Promise.all([unsigned, wrong, stale].map((r) => r.text()));
    expect(new Set(bodies).size).toBe(1); // no oracle about which check failed
    expect(up.calls.calc).toBe(0); // nothing ran
    expect(revalidated).toEqual([]);
  });

  it('rejects a replayed request (same nonce) even with a valid signature', async () => {
    const first = await handleRevalidate(req(REVAL, '{"tags":["catalog"]}', { nonce: 'fixed-nonce' }), deps);
    const replay = await handleRevalidate(req(REVAL, '{"tags":["catalog"]}', { nonce: 'fixed-nonce' }), deps);
    expect(first.status).toBe(200);
    expect(replay.status).toBe(401);
    expect(revalidated).toEqual(['catalog']);
  });

  it('fails closed when replay protection is unavailable', async () => {
    const broken = { hit: async () => ({ count: 1, resetIn: 1 }), once: async () => { throw new Error('redis down'); } };
    const r = await handleSync(req(SYNC), { ...deps, limits: broken });
    expect(r.status).toBe(503);
    expect(up.calls.calc).toBe(0);
  });

  it('rejects oversized bodies before verifying', async () => {
    const r = await handleRevalidate(req(REVAL, 'x'.repeat(20_000)), deps);
    expect(r.status).toBe(413);
  });

  it('rate limits internal calls', async () => {
    (globalThis as unknown as { __limits: MemoryLimits }).__limits = new MemoryLimits();
    let last!: Response;
    for (let i = 0; i < 25; i++) last = await handleRevalidate(req(REVAL, '{"tags":["catalog"]}'), deps);
    expect(last.status).toBe(429);
  });
});

describe('POST /api/internal/revalidate', () => {
  it('revalidates validated tags', async () => {
    const r = await handleRevalidate(req(REVAL, '{"tags":["plan:170193","location:ashburn","kind:vps","catalog"]}'), deps);
    expect(r.status).toBe(200);
    expect(revalidated).toEqual(['plan:170193', 'location:ashburn', 'kind:vps', 'catalog']);
  });
  it('rejects malformed tags, unknown keys, unknown scopes and bad JSON', async () => {
    for (const b of ['{"tags":["plan:../x"]}', '{"tags":["anything"]}', '{"tags":[]}', '{"tags":["catalog"],"extra":1}', '{"tags":["catalog"],"scope":"everyone"}', '{nope']) {
      const r = await handleRevalidate(req(REVAL, b), deps);
      expect(r.status, b).toBe(400);
    }
    expect(revalidated).toEqual([]);
    expect(revalidatedLocal).toEqual([]);
  });
  it('announces to the fleet by default and to this replica only with scope "local"', async () => {
    const fleet = await handleRevalidate(req(REVAL, '{"tags":["site"]}'), deps);
    expect(await fleet.json()).toMatchObject({ status: 'revalidated', scope: 'fleet' });
    expect(revalidated).toEqual(['site']);
    expect(revalidatedLocal).toEqual([]);

    revalidated.length = 0;
    const local = await handleRevalidate(req(REVAL, '{"tags":["kind:vps"],"scope":"local"}'), deps);
    expect(await local.json()).toMatchObject({ scope: 'local' });
    expect(revalidatedLocal).toEqual(['kind:vps']);
    expect(revalidated).toEqual([]); // not announced again: that would echo between replicas
  });
});

describe('POST /api/internal/sync', () => {
  it('first sync publishes and revalidates; an unchanged second sync revalidates nothing', async () => {
    const r1 = await handleSync(req(SYNC), deps);
    expect(r1.status).toBe(200);
    expect(await r1.json()).toMatchObject({ status: 'published', version: 1, added: 672 });
    expect(revalidated).toContain('catalog');
    expect(revalidated).toContain('kind:vps');
    expect(revalidated).toContain('location:ashburn');
    expect(announcedVersions).toEqual([1]); // the announcement carries the snapshot version

    revalidated.length = 0;
    const r2 = await handleSync(req(SYNC), deps);
    expect(await r2.json()).toMatchObject({ status: 'unchanged' });
    expect(revalidated).toEqual([]);
  });

  it('a single tariff change revalidates only that plan, its location and kind', async () => {
    await handleSync(req(SYNC), deps);
    revalidated.length = 0;
    const row = (up.state.calcVps as Array<{ id: string; server_price: Record<string, number> }>).find((r) => r.id === '170193')!;
    row.server_price['monthly'] = 99.99; // calc feed drifts from BILLmanager -> mismatch flag changes the plan
    const r = await handleSync(req(SYNC), deps);
    expect(await r.json()).toMatchObject({ status: 'published', changed: 1, added: 0, removed: 0 });
    expect(revalidated.filter((t) => t.startsWith('plan:'))).toEqual(['plan:170193']);
    expect(revalidated).toEqual(expect.arrayContaining(['catalog', 'location:ashburn', 'kind:vps']));
    expect(revalidated).not.toContain('kind:dedicated');
  });

  it('accepts {"force":true} and rejects unknown fields', async () => {
    expect((await handleSync(req(SYNC, '{"force":true}'), deps)).status).toBe(200);
    expect((await handleSync(req(SYNC, '{"evil":"rm -rf"}'), deps)).status).toBe(400);
    expect((await handleSync(req(SYNC, '{"force":"yes"}'), deps)).status).toBe(400);
  });

  it('does not leak upstream error details when a sync fails', async () => {
    up.state.calcStatus = 500;
    const r = await handleSync(req(SYNC), deps);
    expect(r.status).toBe(502);
    const text = await r.text();
    expect(text).toBe('{"status":"failed"}');
    expect(text).not.toMatch(/calc|hosting|i\.gc\.onl/);
  });
});

describe('GET /api/health', () => {
  it('is 503/empty before the first sync and reveals nothing sensitive afterwards', async () => {
    const empty = await handleHealth();
    expect(empty.status).toBe(503);
    await handleSync(req(SYNC), deps);
    const ok = await handleHealth();
    const text = await ok.text();
    expect(ok.status).toBe(200);
    expect(JSON.parse(text)).toMatchObject({ status: 'ok', snapshotVersion: 1, lastSyncFailed: false });
    expect(text).not.toMatch(/KVM|price|hosting\.gcore/);
    expect(ok.headers.get('cache-control')).toBe('no-store');
  });
});
