// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { renderToStaticMarkup } from 'react-dom/server';
import { afterEach, describe, expect, it } from 'vitest';
import { Configurator } from '@/components/configurator';
import { PlanPage } from '@/components/pages';
import { buildConfigModel } from '@/lib/catalog/configurator';
import { PERIODS, type PeriodKey } from '@/lib/catalog/periods';
import { planPageView } from '@/lib/catalog/views';
import { fixtureCatalog } from '../helpers/catalog';

const catalog = fixtureCatalog();
afterEach(cleanup);
/** The text a reader or crawler sees, without markup. */
const plain = (html: string) => html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');

function setup(id: string, addonParams: boolean) {
  const plan = catalog.plans.find((p) => p.id === id)!;
  render(
    <Configurator
      planName="Test plan"
      currency="EUR"
      basePrices={Object.fromEntries(PERIODS.map((p) => [p, plan.prices[p].amount])) as Record<PeriodKey, string>}
      links={plan.order.byPeriod}
      model={buildConfigModel(plan)!}
      addonParams={addonParams}
    />,
  );
  return plan;
}
const total = () => screen.getByTestId('total').textContent;
const orderHref = () => screen.getByTestId('order').getAttribute('href')!;
const redirectOf = (href: string) => new URL(href).searchParams.get('redirect')!;

describe('Configurator (dedicated plan 125840, 266.00 EUR per month)', () => {
  it('starts as the plain plan: monthly, nothing extra, total equals the plan price', () => {
    const plan = setup('125840', false);
    expect(total()).toBe('€266.00');
    expect(orderHref()).toBe(plan.order.byPeriod.monthly);
    expect(screen.queryByTestId('manual-note')).toBeNull();
  });

  it('extra addresses change the estimated total using BILLmanager period prices', () => {
    setup('125840', false);
    fireEvent.change(screen.getByLabelText('Public IPv4-address'), { target: { value: '3' } });
    expect(total()).toBe('€270.00'); // 266 + 2 x 2.00
    fireEvent.change(screen.getByLabelText('IPv6-addresses'), { target: { value: '5' } });
    expect(total()).toBe('€270.64'); // + 4 x 0.16
    fireEvent.click(screen.getByLabelText('12 months'));
    expect(total()).toBe('€3,247.68'); // 3192.00 + 2 x 24.00 + 4 x 1.92
  });

  it('a traffic tier adds its surcharge for the selected period', () => {
    setup('125840', false);
    fireEvent.click(screen.getByLabelText(/60TB traffic included/));
    expect(total()).toBe('€326.00');
    fireEvent.click(screen.getByLabelText('3 months'));
    expect(total()).toBe('€978.00'); // 798 + 180
    fireEvent.click(screen.getByLabelText(/30TB traffic included/)); // back to the included tier
    expect(total()).toBe('€798.00');
  });

  it('params off: the order link stays BILLmanager\'s own link and the page says which options to add there', () => {
    const plan = setup('125840', false);
    fireEvent.change(screen.getByLabelText('Public IPv4-address'), { target: { value: '3' } });
    expect(orderHref()).toBe(plan.order.byPeriod.monthly);
    expect(screen.getByTestId('manual-note').textContent).toContain('Public IPv4-address (2 × 2.00)');
  });

  it('params on: the link carries the selection and follows the billing period', () => {
    const plan = setup('125840', true);
    fireEvent.change(screen.getByLabelText('Public IPv4-address'), { target: { value: '3' } });
    fireEvent.click(screen.getByLabelText(/60TB traffic included/));
    fireEvent.click(screen.getByLabelText('6 months'));
    const base = plan.order.byPeriod.semiannually!;
    expect(redirectOf(orderHref())).toBe(`${redirectOf(base)}&addon_125843=3&addon_125842=125847`);
    expect(redirectOf(orderHref())).toContain('period=6');
    expect(screen.queryByTestId('manual-note')).toBeNull();
  });

  it('only offers quantities the plan allows (1 included, up to 15)', () => {
    setup('125840', false);
    const select = screen.getByLabelText('Public IPv4-address') as HTMLSelectElement;
    const values = within(select).getAllByRole('option').map((o) => (o as HTMLOptionElement).value);
    expect(values).toEqual(Array.from({ length: 15 }, (_, i) => String(i + 1)));
    expect(within(select).getAllByRole('option')[0]!.textContent).toBe('1 (included)');
  });
});

describe('Configurator (VPS plan 170193)', () => {
  it('prices extra IPv4 at the VPS rate and says resources are fixed', () => {
    setup('170193', false);
    expect(total()).toBe('€59.99');
    fireEvent.change(screen.getByLabelText('Public IPv4-address'), { target: { value: '2' } });
    expect(total()).toBe('€62.39'); // 59.99 + 2.40
    expect(screen.getByText(/cannot be changed separately/)).toBeTruthy();
    expect(screen.queryByText(/Traffic option/)).toBeNull();
  });
});

describe('server-rendered default state (no JavaScript)', () => {
  const html = renderToStaticMarkup(<PlanPage v={planPageView(catalog, 'dedicated', '125840')!} />);

  it('contains the configurator, its default total and the option prices in plain HTML', () => {
    expect(plain(html)).toContain('Configure and order'); // the heading is two-tone: its words span two elements
    expect(html).toContain('Estimated total');
    expect(html).toContain('€266.00');
    expect(html).toContain('60TB traffic included');
    expect(html).toContain('Option prices by billing period');
    for (const price of ['€2.00', '€6.00', '€12.00', '€24.00', '€0.16', '€1.92', '€60.00', '€720.00', '€115.00', '€1,380.00']) {
      expect(html, price).toContain(price);
    }
    expect(html).toContain('needs JavaScript');
  });

  it('never mentions options we do not model (OS, licences, burst-billed traffic)', () => {
    for (const word of ['Windows', 'Mssql', 'Operating system', 'Burst', 'burst']) expect(html).not.toContain(word);
  });

  it('a withheld plan has no configurator at all', () => {
    const bad = renderToStaticMarkup(<PlanPage v={planPageView(catalog, 'dedicated', '176811')!} />);
    expect(plain(bad)).not.toContain('Configure and order');
    expect(bad).not.toContain('Estimated total');
  });
});
