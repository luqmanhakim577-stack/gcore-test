import { describe, expect, it } from 'vitest';
import { EVIDENCE, factSchema, OWNER_FACTS, unpublishedTopics, type OwnerFact } from '@/content/facts';
import { GLOSSARY, LEARN } from '@/content/learn';
import { SYNC_INTERVAL_MINUTES } from '@/lib/site';

/** Every string the editorial layer can show, in one place. */
const articleStrings = LEARN.flatMap((a) => [
  a.title,
  a.description,
  a.summary,
  ...a.sections.flatMap((s) => [s.heading, ...s.body, ...(s.list ?? [])]),
  ...a.qa.flatMap((x) => [x.q, x.a]),
]);
const allText = [...articleStrings, ...GLOSSARY.flatMap((t) => [t.term, t.definition])];

describe('editorial content: claims discipline', () => {
  it('contains none of the absolute marketing claims that a hosting review must reject', () => {
    const banned =
      /100\s?%\s*uptime|world'?s fastest|enterprise[- ]grade|unlimited performance|complete (ddos )?protection|fully redundant|zero latency|guaranteed (uptime|bandwidth|speed)|military[- ]grade|unbreakable|always online/i;
    // The guides may name a claim in order to deny it ("unmetered is not unlimited performance"); asserting one is what is banned.
    const sentences = allText.flatMap((s) => s.split(/(?<=\.)\s+/));
    const asserted = sentences.filter((s) => banned.test(s) && !/\b(not|no|never|without|cannot)\b/i.test(s));
    expect(asserted).toEqual([]);
    expect(banned.test('We offer 100% uptime')).toBe(true); // the guard itself works
  });

  it('never speaks for the company about its network, data centers, hardware or protection', () => {
    const firstPerson = /\b(our (network|data ?cent(er|re)s?|servers?|infrastructure|hardware|backbone|upstreams?|sla)|we (own|operate|guarantee|protect|provide|offer|run|use|peer|announce))\b/i;
    expect(allText.filter((s) => firstPerson.test(s))).toEqual([]);
  });

  it('does not name a third-party provider, data center operator or certification as fact', () => {
    const named = /\b(equinix|digital realty|telehouse|cogent|lumen|level ?3|hurricane electric|iso ?27001|soc ?2|pci[- ]dss|tier (iii|iv|3|4)|cloudflare|akamai)\b/i;
    expect(allText.filter((s) => named.test(s))).toEqual([]);
  });

  it('keeps the metered/unmetered distinction the hosting-industry review requires', () => {
    const t = LEARN.find((a) => a.slug === 'port-speed-vs-traffic')!;
    const text = JSON.stringify(t);
    expect(text).toMatch(/not a promise of throughput/);
    expect(text).toMatch(/A plan with a stated allowance is metered, never unmetered/);
    expect(text).toMatch(/Unmetered is not unlimited performance/);
    expect(text).toMatch(/fair-use or acceptable-use/);
    const raid = JSON.stringify(LEARN.find((a) => a.slug === 'ssd-vs-nvme'));
    expect(raid).toMatch(/Is RAID a backup\?[^}]*No\. RAID protects against a drive failing/);
    expect(JSON.stringify(LEARN.find((a) => a.slug === 'ddos-protection-explained'))).toMatch(/not (the same as )?a (contractual )?(service-level )?guarantee|No service stops every attack/);
  });

  it('the quoted sync interval is the real scheduler interval', () => {
    const quoted = allText.filter((s) => /every \d+ minutes/.test(s));
    expect(quoted.length).toBeGreaterThan(0);
    for (const s of quoted) expect(s).toContain(`every ${SYNC_INTERVAL_MINUTES} minutes`);
  });

  it('the traffic arithmetic in the port-speed guide is right', () => {
    const decimalTB = (1e9 * 86_400 * 30) / 8 / 1e12; // 1 Gbit/s for 30 days, in one direction
    expect(decimalTB).toBe(324);
    expect(JSON.stringify(LEARN.find((a) => a.slug === 'port-speed-vs-traffic'))).toContain('324 TB');
    expect((10 / 324) * 100).toBeGreaterThan(3); // "a bit over 3 percent"
    expect((10 / 324) * 100).toBeLessThan(3.2);
  });
});

describe('editorial content: structure', () => {
  it('slugs are unique and URL-safe, related links resolve, dates are valid, Q&A is present', () => {
    const slugs = LEARN.map((a) => a.slug);
    expect(new Set(slugs).size).toBe(slugs.length);
    for (const a of LEARN) {
      expect(a.slug).toMatch(/^[a-z0-9-]+$/);
      expect(a.slug).not.toBe('glossary');
      expect(Number.isNaN(Date.parse(a.updated))).toBe(false);
      expect(a.summary.length).toBeGreaterThan(80);
      expect(a.description.length).toBeGreaterThan(60);
      expect(a.description.length).toBeLessThanOrEqual(300);
      expect(a.qa.length).toBeGreaterThanOrEqual(3);
      expect(a.sections.length).toBeGreaterThanOrEqual(2);
      for (const r of a.related) expect(slugs, `${a.slug} -> ${r}`).toContain(r);
      expect(a.related).not.toContain(a.slug);
    }
  });

  it('titles and descriptions are unique across articles', () => {
    expect(new Set(LEARN.map((a) => a.title)).size).toBe(LEARN.length);
    expect(new Set(LEARN.map((a) => a.description)).size).toBe(LEARN.length);
  });

  it('glossary terms are unique and every definition is a real sentence', () => {
    const names = GLOSSARY.map((t) => t.term.toLowerCase());
    expect(new Set(names).size).toBe(names.length);
    expect(names).toEqual([...names].sort((a, b) => a.localeCompare(b))); // alphabetical, stable for readers
    for (const t of GLOSSARY) expect(t.definition.length).toBeGreaterThan(40);
  });
});

describe('owner facts registry', () => {
  const good: OwnerFact = {
    id: 'ddos-frankfurt',
    topic: 'ddos',
    claim: 'Network-level filtering of layer 3 and 4 attacks is active on the Frankfurt network.',
    scope: { type: 'location', locationId: 'frankfurt' },
    evidence: 'PROVIDER_STATED',
    source: 'Upstream provider datasheet v3, section 2',
    verifiedOn: '2026-10-30',
    limitations: 'Layer 7 attacks are not covered.',
  };

  it('every published fact is valid, sourced and dated (the registry is empty until the owner supplies some)', () => {
    for (const f of OWNER_FACTS) expect(factSchema.safeParse(f).success, f.id).toBe(true);
    expect(new Set(OWNER_FACTS.map((f) => f.id)).size).toBe(OWNER_FACTS.length);
  });

  it('rejects a claim with no source, no date, an unknown evidence level or no scope', () => {
    expect(factSchema.safeParse(good).success).toBe(true);
    expect(factSchema.safeParse({ ...good, source: '' }).success).toBe(false);
    expect(factSchema.safeParse({ ...good, verifiedOn: 'yesterday' }).success).toBe(false);
    expect(factSchema.safeParse({ ...good, evidence: 'UNKNOWN' }).success).toBe(false);
    expect(factSchema.safeParse({ ...good, scope: undefined }).success).toBe(false);
    expect(EVIDENCE).not.toContain('UNKNOWN'); // unknown things are not published at all
  });

  it('reports which topics the site still does not state', () => {
    expect(unpublishedTopics([])).toEqual(['ddos', 'sla', 'cpu', 'network', 'datacenter', 'support']);
    expect(unpublishedTopics([good])).not.toContain('ddos');
  });
});
