/**
 * SEO checks on the real build output: structured data, hreflang, Open Graph, sitemap, robots.
 * Run after a build:  npm run test:ssr
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import type { Catalog } from '@/lib/catalog/model';
import { PERIODS } from '@/lib/catalog/money';
import { listedPlans, locationSummaries, planPath } from '@/lib/catalog/views';
import { sitemapEntries } from '@/lib/seo/sitemap';
import { extractLd, validateLd } from '../helpers/ld';

const root = path.join(process.cwd(), '.next', 'server', 'app');
const snapshot = path.join(process.cwd(), '.cache', 'catalog.json');
const ready = existsSync(root) && existsSync(snapshot);
const catalog: Catalog | null = ready ? (JSON.parse(readFileSync(snapshot, 'utf8')).catalog as Catalog) : null;
const ORIGIN = 'https://gcore.hosting';

const readPage = (urlPath: string) => readFileSync(path.join(root, urlPath === '/' ? 'index.html' : `${urlPath}.html`), 'utf8');
const attr = (h: string, re: RegExp) => re.exec(h)?.[1];
function allHtml(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = path.join(dir, n);
    if (statSync(p).isDirectory()) return n === 'api' ? [] : allHtml(p);
    return n.endsWith('.html') ? [p] : [];
  });
}
const urlOf = (f: string) => '/' + path.relative(root, f).replace(/\\/g, '/').replace(/\.html$/, '').replace(/^index$/, '');

describe.skipIf(!ready)('structured data in the pre-rendered HTML', () => {
  const pages = ready ? allHtml(root).filter((f) => !/_not-found|_global-error/.test(f)) : [];

  it('every page carries valid Organization and WebSite markup', () => {
    for (const f of pages) {
      const lds = extractLd(readFileSync(f, 'utf8'));
      const types = lds.map((l) => l['@type']);
      expect(types, urlOf(f)).toContain('Organization');
      expect(types, urlOf(f)).toContain('WebSite');
    }
  });

  it('every JSON-LD block on every page validates', () => {
    const problems: string[] = [];
    for (const f of pages) for (const ld of extractLd(readFileSync(f, 'utf8'))) for (const p of validateLd(ld)) problems.push(`${urlOf(f)}: ${String(ld['@type'])}: ${p}`);
    expect(problems).toEqual([]);
  });

  it('each plan page has a Product whose four Offers equal the snapshot prices, and a breadcrumb ending at itself', () => {
    const c = catalog!;
    const problems: string[] = [];
    for (const kind of ['vps', 'dedicated'] as const) {
      for (const plan of listedPlans(c, kind)) {
        const lds = extractLd(readPage(planPath(plan)));
        const product = lds.find((l) => l['@type'] === 'Product') as { offers: Array<{ price: string; priceCurrency: string }>; sku: string; url: string } | undefined;
        if (!product) { problems.push(`${plan.id}: no Product`); continue; }
        if (product.sku !== plan.id) problems.push(`${plan.id}: sku`);
        if (product.url !== `${ORIGIN}${planPath(plan)}`) problems.push(`${plan.id}: url ${product.url}`);
        PERIODS.forEach((p, i) => {
          const o = product.offers[i];
          if (!o || o.price !== plan.prices[p].amount || o.priceCurrency !== plan.prices[p].currency) problems.push(`${plan.id}: offer ${p} ${o?.price} != ${plan.prices[p].amount}`);
        });
        const bc = lds.find((l) => l['@type'] === 'BreadcrumbList') as { itemListElement: Array<{ item: string }> } | undefined;
        if (bc?.itemListElement.at(-1)?.item !== `${ORIGIN}${planPath(plan)}`) problems.push(`${plan.id}: breadcrumb tail`);
      }
    }
    expect(problems).toEqual([]);
  });

  it('location pages list every plan in an ItemList that matches the visible links', () => {
    const c = catalog!;
    const problems: string[] = [];
    for (const kind of ['vps', 'dedicated'] as const) {
      for (const s of locationSummaries(c, kind)) {
        const base = kind === 'vps' ? '/vps' : '/dedicated-servers';
        const html = readPage(`${base}/${s.location.slug}`);
        const list = extractLd(html).find((l) => l['@type'] === 'ItemList') as { itemListElement: Array<{ url: string }> } | undefined;
        const expected = listedPlans(c, kind, s.location.id).map((p) => `${ORIGIN}${planPath(p)}`);
        if (JSON.stringify(list?.itemListElement.map((i) => i.url)) !== JSON.stringify(expected)) problems.push(`${base}/${s.location.slug}`);
      }
    }
    expect(problems).toEqual([]);
  });

  it('withheld plans have no Product/Offer anywhere', () => {
    const all = pages.map((f) => readFileSync(f, 'utf8')).join('\n');
    const withheld = catalog!.plans.filter((p) => p.currency === 'EUR' && p.flags.some((f) => f.severity === 'error'));
    expect(withheld.length).toBeGreaterThan(0);
    for (const p of withheld) expect(all).not.toContain(`"sku":"${p.id}"`);
  });
});

describe.skipIf(!ready)('head tags: canonical, hreflang, Open Graph, indexability', () => {
  const pages = ready ? allHtml(root).filter((f) => !/_not-found|_global-error/.test(f)) : [];

  it('every page has self-referencing hreflang (en and x-default) equal to its canonical, and OG tags', () => {
    const problems: string[] = [];
    for (const f of pages) {
      const h = readFileSync(f, 'utf8');
      const url = urlOf(f);
      const canonical = attr(h, /<link rel="canonical" href="([^"]*)"/);
      const en = attr(h, /<link rel="alternate" hrefLang="en" href="([^"]*)"/i);
      const xd = attr(h, /<link rel="alternate" hrefLang="x-default" href="([^"]*)"/i);
      if (!canonical) problems.push(`${url}: canonical`);
      if (en !== canonical) problems.push(`${url}: hreflang en ${en} != ${canonical}`);
      if (xd !== canonical) problems.push(`${url}: hreflang x-default ${xd}`);
      if (attr(h, /<meta property="og:url" content="([^"]*)"/) !== canonical) problems.push(`${url}: og:url`);
      if (!attr(h, /<meta property="og:title" content="([^"]+)"/)) problems.push(`${url}: og:title`);
      if (!attr(h, /<meta name="twitter:card" content="([^"]+)"/)) problems.push(`${url}: twitter:card`);
    }
    expect(problems).toEqual([]);
  });

  it('every pre-rendered page is indexable (noindex pages are never pre-rendered or listed)', () => {
    const noindex = pages.filter((f) => /<meta name="robots" content="[^"]*noindex/.test(readFileSync(f, 'utf8')));
    expect(noindex.map(urlOf)).toEqual([]);
  });

  it('titles and descriptions are a sensible length for search snippets', () => {
    const long: string[] = [];
    for (const f of pages) {
      const h = readFileSync(f, 'utf8');
      const title = attr(h, /<title>(.*?)<\/title>/)!;
      const desc = attr(h, /<meta name="description" content="([^"]*)"/)!;
      if (title.length > 120 || desc.length > 300 || desc.length < 50) long.push(`${urlOf(f)}: title ${title.length}, description ${desc.length}`);
    }
    expect(long).toEqual([]);
  });
});

describe.skipIf(!ready)('sitemap.xml and robots.txt (build artifacts)', () => {
  const sitemapFile = path.join(root, 'sitemap.xml.body');
  const robotsFile = path.join(root, 'robots.txt.body');

  it('were generated', () => {
    expect(existsSync(sitemapFile)).toBe(true);
    expect(existsSync(robotsFile)).toBe(true);
  });

  it('the sitemap lists exactly the indexable pages, each of which was pre-rendered', () => {
    const xml = readFileSync(sitemapFile, 'utf8');
    const locs = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1]!);
    expect(new Set(locs).size).toBe(locs.length);
    const expected = sitemapEntries(catalog!).map((e) => (e.path === '/' ? ORIGIN : `${ORIGIN}${e.path}`));
    expect(locs.sort()).toEqual(expected.sort());
    for (const loc of locs) {
      const p = loc === ORIGIN ? '/' : loc.slice(ORIGIN.length);
      expect(existsSync(path.join(root, p === '/' ? 'index.html' : `${p}.html`)), `${p} in sitemap but not pre-rendered`).toBe(true);
    }
    expect(xml).toContain('hreflang="en"');
    for (const m of xml.matchAll(/<lastmod>([^<]+)<\/lastmod>/g)) expect(Number.isNaN(Date.parse(m[1]!))).toBe(false);
  });

  it('robots.txt allows crawling, blocks only internal endpoints, and names the sitemap', () => {
    const txt = readFileSync(robotsFile, 'utf8');
    expect(txt).toContain('User-Agent: *');
    expect(txt).toContain('Allow: /');
    expect(txt).toContain('Disallow: /api/internal/');
    expect(txt).toContain(`Sitemap: ${ORIGIN}/sitemap.xml`);
    expect(txt).toContain('User-Agent: GPTBot');
    expect(txt).toContain('User-Agent: ClaudeBot');
    expect(txt).not.toMatch(/Disallow: \/\s*$/m);
  });
});
