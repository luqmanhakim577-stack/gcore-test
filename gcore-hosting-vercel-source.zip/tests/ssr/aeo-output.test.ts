/**
 * AEO/GEO checks on the real build output: llms.txt, llms-full.txt, the OpenAPI document and the guide pages.
 * Run after a build:  npm run test:ssr
 */
import SwaggerParser from '@apidevtools/swagger-parser';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { GLOSSARY, LEARN } from '@/content/learn';
import type { Catalog } from '@/lib/catalog/model';
import { PERIODS } from '@/lib/catalog/money';
import { listedPlans, locationSummaries, planPath } from '@/lib/catalog/views';
import { formatMoney, withheldSpecs } from '@/lib/format';
import { extractLd, validateLd } from '../helpers/ld';

const root = path.join(process.cwd(), '.next', 'server', 'app');
const snapshot = path.join(process.cwd(), '.cache', 'catalog.json');
const ready = existsSync(root) && existsSync(snapshot) && existsSync(path.join(root, 'llms.txt.body'));
const catalog: Catalog | null = ready ? (JSON.parse(readFileSync(snapshot, 'utf8')).catalog as Catalog) : null;
const ORIGIN = 'https://gcore.hosting';

const body = (name: string) => readFileSync(path.join(root, `${name}.body`), 'utf8');
const meta = (name: string) => JSON.parse(readFileSync(path.join(root, `${name}.meta`), 'utf8')) as { headers: Record<string, string> };
const page = (urlPath: string) => readFileSync(path.join(root, `${urlPath}.html`), 'utf8');
const pageExists = (urlPath: string) => existsSync(path.join(root, urlPath === '/' ? 'index.html' : `${urlPath}.html`));
const text = (h: string) => h.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&#x27;/g, "'").replace(/\s+/g, ' ');

describe.skipIf(!ready)('llms.txt and llms-full.txt (build output)', () => {
  const c = () => catalog!;
  const listed = () => [...listedPlans(c(), 'vps'), ...listedPlans(c(), 'dedicated')];

  it('are served as UTF-8 plain text, cached, and revalidated by the catalog tag', () => {
    for (const f of ['llms.txt', 'llms-full.txt']) {
      const m = meta(f);
      expect(m.headers['content-type']).toBe('text/plain; charset=utf-8');
      expect(m.headers['x-next-cache-tags']).toContain('catalog');
      expect(m.headers['cache-control']).toContain('s-maxage');
    }
  });

  it('llms.txt links only to pages that were actually pre-rendered (or to known files)', () => {
    const t = body('llms.txt');
    const urls = [...t.matchAll(/\]\((https:\/\/gcore\.hosting[^)\s]*)\)/g)].map((m) => m[1]!.slice(ORIGIN.length) || '/');
    expect(urls.length).toBeGreaterThan(30);
    const files = new Set(['/api/v1/openapi.json', '/api/v1/plans', '/api/v1/locations', '/llms-full.txt', '/sitemap.xml']);
    expect(urls.filter((u) => !files.has(u) && !pageExists(u))).toEqual([]);
  });

  it('llms-full.txt has every listed plan, with the same prices and the same page URL as the plan page', () => {
    const t = body('llms-full.txt');
    const lines = t.split('\n');
    const problems: string[] = [];
    for (const plan of listed()) {
      const line = lines.find((l) => l.includes(`(id ${plan.id})`));
      if (!line) { problems.push(`${plan.id}: missing`); continue; }
      for (const p of PERIODS) if (!line.includes(formatMoney(plan.prices[p]))) problems.push(`${plan.id}: ${p} price`);
      if (!line.endsWith(`${ORIGIN}${planPath(plan)}`)) problems.push(`${plan.id}: url`);
      if (!pageExists(planPath(plan))) problems.push(`${plan.id}: page missing`);
    }
    expect(listed().length).toBeGreaterThan(300); // coverage floor: an empty catalog must not pass
    expect(problems).toEqual([]);
    expect(lines.filter((l) => /\(id \d+\)/.test(l)).length).toBe(listed().length); // and nothing extra
  });

  it('withheld plans, USD prices and order URLs never appear', () => {
    const t = body('llms-full.txt') + body('llms.txt');
    for (const p of c().plans.filter((x) => x.flags.some((f) => f.severity === 'error'))) expect(t).not.toContain(`(id ${p.id})`);
    expect(t).not.toMatch(/\bUSD\b|\$\d/);
    expect(t).not.toContain('hosting.gcore.com');
  });

  it('a withheld spec is withheld here too (no vCPU on a plan whose vCPU the page refuses to state)', () => {
    const lines = body('llms-full.txt').split('\n');
    const hidden = listed().filter((p) => withheldSpecs(p).has('vcpu'));
    for (const p of hidden) expect(lines.find((l) => l.includes(`(id ${p.id})`)), `plan ${p.id}`).not.toMatch(/vCPU \d/);
  });

  it('counts in the summary equal the catalog', () => {
    const t = body('llms.txt');
    expect(t).toContain(`${listedPlans(c(), 'vps').length} VPS plans and ${listedPlans(c(), 'dedicated').length} dedicated server plans`);
    const locs = new Set([...locationSummaries(c(), 'vps'), ...locationSummaries(c(), 'dedicated')].map((s) => s.location.id)).size;
    expect(t).toContain(`in ${locs} locations`);
  });

  it('size stays reasonable for a single fetch', () => {
    expect(Buffer.byteLength(body('llms.txt'))).toBeLessThan(40_000);
    expect(Buffer.byteLength(body('llms-full.txt'))).toBeLessThan(400_000);
  });
});

describe.skipIf(!ready)('OpenAPI document (build output)', () => {
  it('is valid OpenAPI 3.1, names the production origin and lists exactly the public endpoints', async () => {
    const spec = JSON.parse(body('api/v1/openapi.json'));
    await expect(SwaggerParser.validate(JSON.parse(JSON.stringify(spec)))).resolves.toBeTruthy();
    expect(spec.openapi).toBe('3.1.0');
    expect(spec.servers[0].url).toBe(ORIGIN);
    expect(Object.keys(spec.paths).sort()).toEqual(['/api/v1/locations', '/api/v1/plans', '/api/v1/plans/{id}']);
  });
});

describe.skipIf(!ready)('guide pages (build output)', () => {
  it('every guide, the index and the glossary were pre-rendered with title, description and self canonical', () => {
    for (const url of ['/learn', '/learn/glossary', ...LEARN.map((a) => `/learn/${a.slug}`)]) {
      expect(pageExists(url), url).toBe(true);
      const h = page(url);
      expect(/<title>(.+?)<\/title>/.exec(h)?.[1], url).toBeTruthy();
      expect(/<link rel="canonical" href="([^"]+)"/.exec(h)?.[1], url).toBe(`${ORIGIN}${url}`);
    }
  });

  it('each guide shows its visible Q&A and the live catalog block, and its FAQPage lists exactly the visible questions', () => {
    for (const a of LEARN) {
      const h = page(`/learn/${a.slug}`);
      const t = text(h);
      const faq = extractLd(h).find((n) => n['@type'] === 'FAQPage')!;
      expect((faq['mainEntity'] as Array<{ name: string }>).map((q) => q.name)).toEqual(a.qa.map((q) => q.q));
      for (const q of a.qa) {
        expect(t, a.slug).toContain(q.q);
        expect(t, a.slug).toContain(q.a);
      }
      for (const n of extractLd(h)) expect(validateLd(n), `${a.slug} ${String(n['@type'])}`).toEqual([]);
      if (a.slug !== 'ddos-protection-explained') expect(t, a.slug).toMatch(/Billing data as of 20\d\d-\d\d-\d\d|Every listed plan has a price/);
    }
  });

  it('the ssd/nvme and traffic guides quote numbers that match the snapshot', () => {
    const c = catalog!;
    const vps = listedPlans(c, 'vps').length;
    const ded = listedPlans(c, 'dedicated').length;
    const billing = text(page('/learn/billing-periods-and-prices'));
    expect(billing).toMatch(new RegExp(`of ${vps} plans`));
    expect(billing).toMatch(new RegExp(`of ${ded} plans`));
    const ssd = text(page('/learn/ssd-vs-nvme'));
    const nvmeDedicated = listedPlans(c, 'dedicated').filter((p) => p.specs.disks?.some((d) => d.type === 'NVMe')).length;
    if (nvmeDedicated > 0) expect(ssd).toContain(`NVMe on ${nvmeDedicated} plan`);
    else expect(ssd).not.toContain('NVMe on');
  });

  it('the DDoS guide states no protection scope while the owner has supplied none', () => {
    const t = text(page('/learn/ddos-protection-explained'));
    expect(t).toContain('does not currently state a DDoS protection scope');
  });

  it('the glossary page shows every term', () => {
    const t = text(page('/learn/glossary'));
    for (const g of GLOSSARY) expect(t).toContain(g.term);
  });

  it('guides and glossary are in the sitemap, and the footer links to the machine-readable files', () => {
    const sm = body('sitemap.xml');
    for (const url of ['/learn', '/learn/glossary', ...LEARN.map((a) => `/learn/${a.slug}`)]) expect(sm).toContain(`<loc>${ORIGIN}${url}</loc>`);
    const home = page('index');
    for (const href of ['/api/v1/openapi.json', '/llms.txt', '/llms-full.txt', '/learn']) expect(home).toContain(`href="${href}"`);
  });
});
