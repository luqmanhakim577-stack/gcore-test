/**
 * Performance budgets for what `next build` produced. They guard the things that decide Core Web Vitals before
 * any measurement happens: how much script a page must download, how heavy the HTML is, whether anything blocks
 * rendering. Numbers come from the first measured build (about 107 KB of gzip JS per route, which is React and
 * Next's runtime; page code itself is under 1 KB) plus roughly 10% headroom. Raising a budget should be a
 * decision, not an accident. Run after a build:  npm run test:ssr
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { gzipSync } from 'node:zlib';
import { describe, expect, it } from 'vitest';

const next = path.join(process.cwd(), '.next');
const ready = existsSync(path.join(next, 'app-build-manifest.json'));

const BUDGET = {
  jsGzipKB: 118,
  cssGzipKB: 8,
  htmlGzipKB: 24,
  htmlRawKB: 320,
  scriptsPerPage: 12,
};

const gz = (b: Buffer) => gzipSync(b, { level: 9 }).length;
const kb = (n: number) => n / 1024;

function htmlFiles(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = path.join(dir, n);
    if (statSync(p).isDirectory()) return n === 'api' ? [] : htmlFiles(p);
    return n.endsWith('.html') ? [p] : [];
  });
}

describe.skipIf(!ready)('performance budgets', () => {
  it(`client JavaScript per page route is at most ${BUDGET.jsGzipKB} KB gzip`, () => {
    const pages = (JSON.parse(readFileSync(path.join(next, 'app-build-manifest.json'), 'utf8')) as { pages: Record<string, string[]> }).pages;
    const cache = new Map<string, number>();
    const size = (f: string) => {
      if (!cache.has(f)) cache.set(f, gz(readFileSync(path.join(next, f))));
      return cache.get(f)!;
    };
    const routes = Object.entries(pages).filter(([r]) => r.endsWith('/page'));
    expect(routes.length).toBeGreaterThan(8);
    const over = routes
      .map(([r, files]) => [r, kb(files.filter((f) => f.endsWith('.js')).reduce((n, f) => n + size(f), 0))] as const)
      .filter(([, k]) => k > BUDGET.jsGzipKB)
      .map(([r, k]) => `${r}: ${k.toFixed(1)} KB`);
    expect(over).toEqual([]);
  });

  it(`stylesheets total at most ${BUDGET.cssGzipKB} KB gzip, and render blocking is one stylesheet`, () => {
    const dir = path.join(next, 'static', 'css');
    const total = readdirSync(dir).reduce((n, f) => n + gz(readFileSync(path.join(dir, f))), 0);
    expect(kb(total)).toBeLessThanOrEqual(BUDGET.cssGzipKB);
    const sample = readFileSync(htmlFiles(path.join(next, 'server', 'app'))[0]!, 'utf8');
    expect((sample.match(/<link[^>]*rel="stylesheet"/g) ?? []).length).toBe(1);
  });

  it(`every page's HTML is at most ${BUDGET.htmlGzipKB} KB gzip (${BUDGET.htmlRawKB} KB raw)`, () => {
    const files = htmlFiles(path.join(next, 'server', 'app'));
    expect(files.length).toBeGreaterThan(300);
    const over: string[] = [];
    for (const f of files) {
      const b = readFileSync(f);
      if (kb(gz(b)) > BUDGET.htmlGzipKB || kb(b.length) > BUDGET.htmlRawKB) over.push(`${path.relative(next, f)}: ${kb(b.length).toFixed(0)} KB raw, ${kb(gz(b)).toFixed(1)} KB gzip`);
    }
    expect(over).toEqual([]);
  });

  it('no script blocks rendering and no page pulls in an unreasonable number of them', () => {
    const problems: string[] = [];
    for (const f of htmlFiles(path.join(next, 'server', 'app'))) {
      const html = readFileSync(f, 'utf8');
      const scripts = [...html.matchAll(/<script\b([^>]*\ssrc="[^"]*"[^>]*)>/g)].map((m) => m[1]!);
      for (const attrs of scripts) {
        // a nomodule script is skipped by every browser that matters, so it cannot block
        if (!/\b(async|defer)\b/.test(attrs) && !/\bnoModule\b|\bnomodule\b/.test(attrs)) problems.push(`${path.relative(next, f)}: blocking <script ${attrs.slice(0, 80)}>`);
      }
      if (scripts.length > BUDGET.scriptsPerPage) problems.push(`${path.relative(next, f)}: ${scripts.length} script files`);
    }
    expect(problems).toEqual([]);
  });

  it('the brand font is self-hosted, preloaded on every page and never blocks or re-wraps text', () => {
    const css = readdirSync(path.join(next, 'static', 'css')).map((f) => readFileSync(path.join(next, 'static', 'css', f), 'utf8')).join('');
    const face = /@font-face\s*\{[^}]*font-family:\s*["']?Montserrat["']?;[^}]*\}/.exec(css)?.[0];
    expect(face, 'Montserrat @font-face').toBeDefined();
    expect(face).toMatch(/font-display:\s*optional/);
    const url = /url\(["']?([^"')]+)["']?\)/.exec(face!)![1]!;
    expect(url).toMatch(/^\/fonts\/[^/]+-v\d[\d.]*\.woff2$/); // versioned name, so the immutable cache header is safe
    expect(existsSync(path.join(process.cwd(), 'public', url)), `${url} exists in public/`).toBe(true);
    expect(existsSync(path.join(process.cwd(), 'public', 'fonts', 'OFL.txt')), 'licence shipped with the font').toBe(true);
    const missing = htmlFiles(path.join(next, 'server', 'app')).filter((f) => !readFileSync(f, 'utf8').includes(`<link rel="preload" href="${url}" as="font"`));
    expect(missing.map((f) => path.relative(next, f))).toEqual([]);
  });

  it('images declare their size and web fonts do not hide text, so nothing shifts layout (none are used today)', () => {
    const problems: string[] = [];
    for (const f of htmlFiles(path.join(next, 'server', 'app'))) {
      const html = readFileSync(f, 'utf8');
      for (const m of html.matchAll(/<img\b([^>]*)>/g)) {
        if (!/\swidth="\d+"/.test(m[1]!) || !/\sheight="\d+"/.test(m[1]!)) problems.push(`${path.relative(next, f)}: <img> without width and height`);
      }
    }
    const css = readdirSync(path.join(next, 'static', 'css')).map((f) => readFileSync(path.join(next, 'static', 'css', f), 'utf8')).join('');
    for (const m of css.matchAll(/@font-face\s*\{[^}]*\}/g)) {
      // Only a face that downloads a file can hold text back; the size-adjusted local() fallback next/font adds cannot.
      if (/url\(/.test(m[0]) && !/font-display\s*:\s*(swap|optional|fallback)/.test(m[0])) problems.push('@font-face without font-display');
    }
    expect(problems).toEqual([]);
  });
});
