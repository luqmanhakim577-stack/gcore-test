/**
 * The Content-Security-Policy is a static one (see next.config.ts for why), so its value rests on what the
 * pages actually contain. These tests scan every pre-rendered page and fail when a page starts to depend on
 * something the policy is meant to forbid. Run after a build:  npm run test:ssr
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { baseSecurityHeaders } from '../../next.config';

const root = path.join(process.cwd(), '.next', 'server', 'app');
const ready = existsSync(root);

function allHtml(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = path.join(dir, n);
    if (statSync(p).isDirectory()) return n === 'api' ? [] : allHtml(p);
    return n.endsWith('.html') ? [p] : [];
  });
}

const SITE = 'https://gcore.hosting';
/** The only external site pages may link to (order links and the billing panel). */
const EXTERNAL_LINK_HOSTS = new Set(['https://hosting.gcore.com']);

describe.skipIf(!ready)('CSP compatibility of pre-rendered pages', () => {
  const files = ready ? allHtml(root) : [];
  const urlOf = (f: string) => '/' + path.relative(root, f).replace(/\\/g, '/').replace(/\.html$/, '');
  const pages = () => files.map((f) => ({ url: urlOf(f), html: readFileSync(f, 'utf8') }));

  it('scans a meaningful number of pages', () => {
    expect(files.length).toBeGreaterThan(300);
  });

  it('loads nothing from another origin: scripts, styles, images, fonts, frames, forms', () => {
    const problems: string[] = [];
    for (const { url, html } of pages()) {
      const loads = [
        ...[...html.matchAll(/<script[^>]*\ssrc="([^"]*)"/g)].map((m) => m[1]!),
        ...[...html.matchAll(/<img[^>]*\ssrc="([^"]*)"/g)].map((m) => m[1]!),
        ...[...html.matchAll(/<(?:source|video|audio|track|iframe|embed|object)[^>]*\s(?:src|data)="([^"]*)"/g)].map((m) => m[1]!),
        ...[...html.matchAll(/<link[^>]*\srel="(?:stylesheet|preload|prefetch|modulepreload|icon|manifest)"[^>]*\shref="([^"]*)"/g)].map((m) => m[1]!),
        ...[...html.matchAll(/<link[^>]*\shref="([^"]*)"[^>]*\srel="(?:stylesheet|preload|prefetch|modulepreload|icon|manifest)"/g)].map((m) => m[1]!),
        ...[...html.matchAll(/<form[^>]*\saction="([^"]*)"/g)].map((m) => m[1]!),
        ...[...html.matchAll(/url\(\s*['"]?(https?:[^)'"]*)/g)].map((m) => m[1]!),
      ];
      for (const ref of loads) {
        if (/^https?:\/\//i.test(ref) && !ref.startsWith(SITE)) problems.push(`${url}: ${ref}`);
        if (/^\/\//.test(ref)) problems.push(`${url}: protocol-relative ${ref}`);
      }
    }
    expect(problems).toEqual([]);
  });

  it('links out only to the billing panel', () => {
    const external = new Set<string>();
    for (const { html } of pages()) for (const m of html.matchAll(/<a[^>]*\shref="(https?:\/\/[^"/]+)/g)) if (m[1] !== SITE) external.add(m[1]!);
    expect([...external].filter((h) => !EXTERNAL_LINK_HOSTS.has(h))).toEqual([]);
  });

  it('has no inline event handlers, javascript: URLs, <base>, frames, plugins, forms or meta refresh', () => {
    const problems: string[] = [];
    for (const { url, html } of pages()) {
      const body = html.replace(/<script[\s\S]*?<\/script>/g, '');
      if (/\son[a-z]+\s*=\s*["']/i.test(body)) problems.push(`${url}: inline event handler`);
      if (/(?:href|src|action)\s*=\s*["']\s*javascript:/i.test(body)) problems.push(`${url}: javascript: URL`);
      const tag = /<(base|iframe|frame|object|embed|applet|form)[\s>]/i.exec(body)?.[1];
      if (tag) problems.push(`${url}: <${tag}>`);
      if (/<meta[^>]+http-equiv\s*=\s*["']?refresh/i.test(body)) problems.push(`${url}: meta refresh`);
    }
    expect(problems).toEqual([]);
  });

  it('inline scripts are only Next\'s own flight payload and JSON-LD data', () => {
    const problems: string[] = [];
    const flight = /^\s*(?:\(self\.__next_f=self\.__next_f\|\|\[\]\)|self\.__next_f)\.push\(\[/;
    for (const { url, html } of pages()) {
      for (const m of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)) {
        if (/\ssrc=/.test(m[1]!)) continue;
        const body = m[2]!;
        if (/type="application\/ld\+json"/.test(m[1]!)) continue; // data, never executed
        if (!flight.test(body)) problems.push(`${url}: unexpected inline script "${body.slice(0, 60)}"`);
      }
    }
    expect(problems).toEqual([]);
  });

  it('JSON-LD cannot break out of its script element', () => {
    const problems: string[] = [];
    for (const { url, html } of pages()) {
      for (const m of html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)) {
        const body = m[1]!;
        if (/[<>]/.test(body)) problems.push(`${url}: raw angle bracket in JSON-LD`);
        if (body.includes(String.fromCharCode(0x2028)) || body.includes(String.fromCharCode(0x2029))) problems.push(`${url}: line separator in JSON-LD`);
        expect(() => JSON.parse(body), `${url}: JSON-LD must parse`).not.toThrow();
      }
    }
    expect(problems).toEqual([]);
  });

  it('the built routes manifest carries the same CSP as the config', () => {
    const manifest = JSON.parse(readFileSync(path.join(process.cwd(), '.next', 'routes-manifest.json'), 'utf8')) as {
      headers: Array<{ source: string; headers: Array<{ key: string; value: string }> }>;
    };
    const all = manifest.headers.find((h) => h.source === '/:path*');
    expect(all?.headers.find((h) => h.key === 'Content-Security-Policy')?.value).toBe(
      baseSecurityHeaders.find((h) => h.key === 'Content-Security-Policy')!.value,
    );
  });
});
