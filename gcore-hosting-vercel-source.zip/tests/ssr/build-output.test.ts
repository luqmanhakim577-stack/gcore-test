/**
 * Verifies the HTML that `next build` actually pre-rendered: what a crawler or a browser with
 * JavaScript disabled receives. Run after a build:  npm run test:ssr
 * The expected values come from the same snapshot the build used (.cache/catalog.json).
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { buildConfigModel } from '@/lib/catalog/configurator';
import { PERIODS } from '@/lib/catalog/periods';
import type { Catalog } from '@/lib/catalog/model';
import { listedPlans, locationSummaries, planPath } from '@/lib/catalog/views';
import { formatMoney } from '@/lib/format';

const root = path.join(process.cwd(), '.next', 'server', 'app');
const snapshot = path.join(process.cwd(), '.cache', 'catalog.json');
const ready = existsSync(root) && existsSync(snapshot);

const catalog: Catalog | null = ready ? (JSON.parse(readFileSync(snapshot, 'utf8')).catalog as Catalog) : null;
const c = () => catalog!;
const read = (urlPath: string) => {
  const file = path.join(root, urlPath === '/' ? 'index.html' : `${urlPath}.html`);
  expect(existsSync(file), `${urlPath} was not pre-rendered`).toBe(true);
  return readFileSync(file, 'utf8');
};
const stripScripts = (h: string) => h.replace(/<script[\s\S]*?<\/script>/g, '');
const text = (h: string) => stripScripts(h).replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');
const tag = (h: string, re: RegExp) => re.exec(h)?.[1];
const esc = (s: string) => s.replace(/&/g, '&amp;');

function allHtml(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = path.join(dir, n);
    if (statSync(p).isDirectory()) return n === 'api' ? [] : allHtml(p);
    return n.endsWith('.html') ? [p] : [];
  });
}

describe.skipIf(!ready)('pre-rendered HTML (no JavaScript)', () => {
  const files = ready ? allHtml(root).filter((f) => !/_not-found|_global-error/.test(f)) : [];
  const urlOf = (f: string) => '/' + path.relative(root, f).replace(/\\/g, '/').replace(/\.html$/, '').replace(/^index$/, '');

  it('pre-rendered every listed plan, location and hub page', () => {
    const c = catalog!;
    const plans = [...listedPlans(c, 'vps'), ...listedPlans(c, 'dedicated')];
    const locs = [...locationSummaries(c, 'vps'), ...locationSummaries(c, 'dedicated')];
    expect(files.length).toBeGreaterThanOrEqual(plans.length + locs.length + 4);
  });

  it('every page has the SEO basics: lang, viewport, one h1, unique title/description, self canonical', () => {
    const titles = new Map<string, string>();
    const descs = new Map<string, string>();
    const problems: string[] = [];
    for (const f of files) {
      const h = readFileSync(f, 'utf8');
      const url = urlOf(f);
      const title = tag(h, /<title>(.*?)<\/title>/);
      const desc = tag(h, /<meta name="description" content="([^"]*)"/);
      const canonical = tag(h, /<link rel="canonical" href="([^"]*)"/);
      if (!/<html[^>]*lang="en"/.test(h)) problems.push(`${url}: no lang`);
      if (!/<meta name="viewport"/.test(h)) problems.push(`${url}: no viewport`);
      if ((h.match(/<h1[ >]/g) ?? []).length !== 1) problems.push(`${url}: h1 count`);
      if (!title) problems.push(`${url}: no title`);
      else if (titles.has(title)) problems.push(`${url}: duplicate title with ${titles.get(title)}`);
      else titles.set(title, url);
      if (!desc) problems.push(`${url}: no description`);
      else if (descs.has(desc)) problems.push(`${url}: duplicate description with ${descs.get(desc)}`);
      else descs.set(desc, url);
      // the origin with or without "/" is the same URL
      if (canonical !== `https://gcore.hosting${url === '/' ? '' : url}`) problems.push(`${url}: canonical ${canonical}`);
    }
    expect(problems).toEqual([]);
  });

  it('every plan page shows all four billing-period prices and order links exactly as in the snapshot', () => {
    const c = catalog!;
    const problems: string[] = [];
    for (const kind of ['vps', 'dedicated'] as const) {
      for (const plan of listedPlans(c, kind)) {
        const h = read(planPath(plan));
        const t = text(h);
        for (const p of PERIODS) {
          if (!t.includes(formatMoney(plan.prices[p]))) problems.push(`${plan.id} missing ${p} price ${formatMoney(plan.prices[p])}`);
          if (!h.includes(`href="${esc(plan.order.byPeriod[p]!)}"`)) problems.push(`${plan.id} missing ${p} order link`);
        }
      }
    }
    expect(problems).toEqual([]);
  });

  it('every location page lists all of its plans with every period price', () => {
    const c = catalog!;
    const problems: string[] = [];
    for (const kind of ['vps', 'dedicated'] as const) {
      for (const s of locationSummaries(c, kind)) {
        const base = kind === 'vps' ? '/vps' : '/dedicated-servers';
        const h = read(`${base}/${s.location.slug}`);
        const t = text(h);
        for (const plan of listedPlans(c, kind, s.location.id)) {
          if (!h.includes(`href="${planPath(plan)}"`)) problems.push(`${base}/${s.location.slug} missing link to ${plan.id}`);
          for (const p of PERIODS) if (!t.includes(formatMoney(plan.prices[p]))) problems.push(`${plan.id} ${p} price missing on location page`);
        }
      }
    }
    expect(problems).toEqual([]);
  });

  it('withholds plans whose data is flagged untrustworthy: no page, no link, no order URL; and never a USD price', () => {
    const c = catalog!;
    const bad = c.plans.filter((p) => p.currency === 'EUR' && p.flags.some((f) => f.severity === 'error'));
    expect(bad.length).toBeGreaterThan(0); // the live data has some; this test is meaningless otherwise
    const raw = files.map((f) => readFileSync(f, 'utf8')).join('\n');
    for (const p of bad) {
      expect(raw, `link to withheld plan ${p.id}`).not.toContain(planPath(p));
      expect(raw, `order URL of withheld plan ${p.id}`).not.toContain(`pricelist%3D${p.id}%26`);
      expect(existsSync(path.join(root, `${planPath(p)}.html`)), `withheld plan ${p.id} was pre-rendered`).toBe(false);
    }
    expect(text(raw)).not.toMatch(/\$\d/);
  });

  it('configurator: every configurable plan page shows its default total equal to the plan price, and every option price', () => {
    const c = catalog!;
    const problems: string[] = [];
    let configurable = 0;
    for (const kind of ['vps', 'dedicated'] as const) {
      for (const plan of listedPlans(c, kind)) {
        const model = buildConfigModel(plan);
        const t = text(read(planPath(plan)));
        if (!model) continue;
        configurable++;
        if (!t.includes('Configure and order') || !t.includes(`Estimated total`)) { problems.push(`${plan.id}: configurator missing`); continue; }
        if (!t.includes(`Estimated total, per month ${formatMoney(plan.prices.monthly)}`)) problems.push(`${plan.id}: default total != plan price`);
        for (const q of model.quantities) for (const p of PERIODS) if (!t.includes(formatMoney({ amount: q.unitPrices[p], currency: 'EUR' }))) problems.push(`${plan.id}: ${q.label} ${p} price`);
        // the default tier is the one the plan price already includes; it is shown as "Included", not as a priced row
        for (const ch of (model.traffic?.choices ?? []).filter((x) => x.id !== model.traffic!.defaultId)) for (const p of PERIODS) if (!t.includes(formatMoney({ amount: ch.prices[p], currency: 'EUR' }))) problems.push(`${plan.id}: traffic ${ch.id} ${p} price`);
      }
    }
    // Coverage floors: a snapshot lacking add-on fields must fail here, not pass vacuously.
    const models = [...listedPlans(c, 'vps'), ...listedPlans(c, 'dedicated')].map((p) => buildConfigModel(p));
    expect(configurable).toBeGreaterThan(100);
    expect(models.filter((m) => m?.traffic).length, 'dedicated plans with a traffic tier control').toBeGreaterThan(50);
    expect(models.filter((m) => m?.quantities.length).length, 'plans with extra-address controls').toBeGreaterThan(100);
    expect(models.filter((m) => m?.fixedResources).length, 'VPS plans with fixed-resources note').toBeGreaterThan(50);
    expect(problems).toEqual([]);
  });

  it('configurator models are well-formed for every live plan (no zero-priced extras, no burst/OS/licence options)', () => {
    const problems: string[] = [];
    for (const plan of c().plans.filter((p) => p.source.s2Status === 'ok')) {
      const m = buildConfigModel(plan);
      if (!m) continue;
      for (const q of m.quantities) {
        if (q.max <= q.included || q.step < 1) problems.push(`${plan.id} ${q.label}: bad range`);
        for (const p of PERIODS) if (!(Number(q.unitPrices[p]) > 0)) problems.push(`${plan.id} ${q.label} ${p}: not priced`);
      }
      if (m.traffic) {
        const def = m.traffic.choices.find((x) => x.id === m.traffic!.defaultId);
        if (!def || PERIODS.some((p) => Number(def.prices[p]) !== 0)) problems.push(`${plan.id}: default traffic tier is not the included one`);
        if (m.traffic.choices.some((x) => /burst|unlimited traffic/i.test(x.label))) problems.push(`${plan.id}: burst option offered`);
      }
      if (/windows|mssql|operating/i.test(JSON.stringify(m))) problems.push(`${plan.id}: licence/OS option offered`);
    }
    expect(problems).toEqual([]);
  });

  it('pages stay light: HTML under 400 KB, no inline event handlers', () => {
    for (const f of files) {
      const h = readFileSync(f, 'utf8');
      expect(Buffer.byteLength(h), urlOf(f)).toBeLessThan(400_000);
      expect(h).not.toMatch(/\sonclick=|\sonload=/);
    }
  });
});
