import { describe, expect, it } from 'vitest';
import { fetchPricelists } from '@/lib/billmanager/pricelist-client';
import { fakeUpstream, HIDDEN_ID } from '../helpers/upstream';

const cfgFor = (f: typeof fetch, extra: object = {}) => ({
  baseUrl: 'https://hosting.gcore.com',
  batchSize: 5,
  concurrency: 2,
  backoffMs: 0,
  fetchImpl: f,
  ...extra,
});

describe('pricelist.export client', () => {
  it('fetches visible plans in a batch', async () => {
    const up = fakeUpstream();
    const r = await fetchPricelists(['170193', '170158'], cfgFor(up.fetch));
    expect([...r.plans.keys()].sort()).toEqual(['170158', '170193']);
    expect(up.calls.billmgr).toHaveLength(1);
  });

  it('removes a hidden id from a batch and retries the rest', async () => {
    const up = fakeUpstream();
    const r = await fetchPricelists(['170193', HIDDEN_ID, '170158'], cfgFor(up.fetch));
    expect([...r.plans.keys()].sort()).toEqual(['170158', '170193']);
    expect([...r.notPublic]).toEqual([HIDDEN_ID]);
    expect(r.failed.size).toBe(0);
    expect(up.calls.billmgr).toHaveLength(2); // failed batch, then retry without the hidden id
    expect(up.calls.billmgr[1]!.ids).toEqual(['170193', '170158']);
  });

  it('chunks by batch size and honours concurrency without losing ids', async () => {
    const up = fakeUpstream();
    const ids = ['170193', '173283', '170158', '145809', '125840', '176811'];
    const r = await fetchPricelists(ids, cfgFor(up.fetch, { batchSize: 2 }));
    expect(r.plans.size).toBe(6);
    expect(up.calls.billmgr).toHaveLength(3);
  });

  it('treats an unknown id as not public, not as an outage', async () => {
    const up = fakeUpstream();
    const r = await fetchPricelists(['999999999'], cfgFor(up.fetch));
    expect(r.notPublic.has('999999999')).toBe(true);
    expect(r.failed.size).toBe(0);
  });

  it('retries 5xx, then isolates the failure and reports ids as failed (not notPublic)', async () => {
    const up = fakeUpstream();
    up.state.billmgrStatus = 504;
    const events: string[] = [];
    const r = await fetchPricelists(['170193', '170158', '173283'], cfgFor(up.fetch, { retries: 1, onEvent: (e: { type: string }) => events.push(e.type) }));
    expect(r.plans.size).toBe(0);
    expect(r.notPublic.size).toBe(0);
    expect([...r.failed].sort()).toEqual(['170158', '170193', '173283']);
    expect(events).toContain('split');
  });

  it('stops hammering a dead BILLmanager: the circuit opens after a few exhausted requests', async () => {
    const up = fakeUpstream();
    up.state.billmgrStatus = 503;
    const ids = Array.from({ length: 200 }, (_, i) => String(900000 + i));
    const events: string[] = [];
    const r = await fetchPricelists(ids, cfgFor(up.fetch, { retries: 1, onEvent: (e: { type: string }) => events.push(e.type) }));
    expect(r.failed.size).toBe(200);
    expect(r.plans.size).toBe(0);
    expect(up.calls.billmgr.length).toBeLessThan(25); // not 40 batches x retries x splits
    expect(events).toContain('circuit-open');
  });

  it('recovers when a large batch times out but halves succeed', async () => {
    const up = fakeUpstream();
    const real = up.fetch;
    let first = true;
    const flaky = (async (...args: Parameters<typeof fetch>) => {
      const ids = new URL(String(args[0])).searchParams.get('pricelist')!.split(',');
      if (ids.length > 1 && first) {
        first = false;
        return new Response('Gateway Time-out', { status: 504 });
      }
      return real(...args);
    }) as typeof fetch;
    const r = await fetchPricelists(['170193', '170158', '173283', '145809'], cfgFor(flaky, { retries: 0 }));
    expect(r.plans.size).toBe(4);
    expect(r.failed.size).toBe(0);
  });

  it('only ever contacts the configured BILLmanager host with the documented function', async () => {
    const up = fakeUpstream();
    const seen: URL[] = [];
    const spy = (async (...args: Parameters<typeof fetch>) => {
      seen.push(new URL(String(args[0])));
      return up.fetch(...args);
    }) as typeof fetch;
    await fetchPricelists(['170193'], cfgFor(spy));
    expect(seen).toHaveLength(1);
    expect(seen[0]!.origin).toBe('https://hosting.gcore.com');
    expect(seen[0]!.pathname).toBe('/billmgr');
    expect(seen[0]!.searchParams.get('func')).toBe('pricelist.export');
    expect(seen[0]!.searchParams.get('out')).toBe('json');
    expect(seen[0]!.searchParams.has('authinfo')).toBe(false); // never sends credentials
  });
});
