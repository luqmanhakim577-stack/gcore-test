import { describe, expect, it } from 'vitest';
import { guardOrderLink, parsePricelistExport } from '@/lib/billmanager/pricelist';
import { fixture, HIDDEN_ID } from '../helpers/upstream';

const BM = 'https://hosting.gcore.com';

describe('pricelist.export parsing (recorded real responses)', () => {
  it('parses a VPS plan: identity, currency, availability, four billing periods', () => {
    const r = parsePricelistExport(fixture('s2-170193.json'));
    if (!r.ok) throw new Error('expected ok');
    const p = r.plans[0]!;
    expect(p.id).toBe('170193');
    expect(p.name).toBe('KVM-HIGHCPU-SSD-4-ANX');
    expect(p.itemtype).toBe('vps');
    expect(p.active).toBe(true);
    expect(p.hidden).toBe(false);
    expect(p.currency).toBe('EUR');
    expect(Object.keys(p.periods).sort()).toEqual(['annually', 'monthly', 'quarterly', 'semiannually']);
    expect(p.periods.monthly).toMatchObject({ cost: '59.99', length: 1 });
    expect(p.periods.quarterly).toMatchObject({ cost: '170.97', length: 3 });
    expect(p.periods.semiannually).toMatchObject({ cost: '323.95', length: 6 });
    expect(p.periods.annually).toMatchObject({ cost: '575.90', length: 12 });
    expect(p.descriptionText).toContain('vCPU: 12x');
  });

  it('parses add-ons with their per-period prices', () => {
    const r = parsePricelistExport(fixture('s2-170193.json'));
    if (!r.ok) throw new Error('expected ok');
    const ipv4 = r.plans[0]!.addons.find((a) => a.id === '170197');
    expect(ipv4?.name).toBe('Public IPv4-address');
    expect(ipv4?.prices).toEqual({ monthly: '2.40', quarterly: '7.20', semiannually: '14.40', annually: '28.80' });
    expect(ipv4?.max).toBe(10);
  });

  it('identifies a dedicated plan and its metered-traffic add-ons', () => {
    const r = parsePricelistExport(fixture('s2-145809.json'));
    if (!r.ok) throw new Error('expected ok');
    const p = r.plans[0]!;
    expect(p.itemtype).toBe('dedicated');
    expect(p.addons.some((a) => /traffic/i.test(a.name))).toBe(true);
  });

  it('reports a plan hidden from anonymous users as invalid-pricelist, naming the id', () => {
    const r = parsePricelistExport(fixture(`s2-hidden-${HIDDEN_ID}.json`));
    expect(r).toEqual({ ok: false, error: 'invalid-pricelist', offendingId: HIDDEN_ID });
  });

  it('a mixed batch fails as a whole and names the first offending id', () => {
    const r = parsePricelistExport(fixture('s2-mixed-batch-error.json'));
    expect(r).toEqual({ ok: false, error: 'invalid-pricelist', offendingId: HIDDEN_ID });
  });

  it('does not crash on garbage', () => {
    expect(parsePricelistExport('<html>').ok).toBe(false);
    expect(parsePricelistExport('{"nope":1}').ok).toBe(false);
  });
});

describe('every recorded period carries an order link for exactly that period', () => {
  const months: Record<string, number> = { monthly: 1, quarterly: 3, semiannually: 6, annually: 12 };
  for (const id of ['170193', '173283', '170158', '145809', '125840', '176811']) {
    it(`plan ${id}`, () => {
      const r = parsePricelistExport(fixture(`s2-${id}.json`));
      if (!r.ok) throw new Error('expected ok');
      const p = r.plans[0]!;
      for (const [key, period] of Object.entries(p.periods)) {
        const link = guardOrderLink(period!.orderLink, BM);
        expect(link, `${id}/${key}`).toBeDefined();
        const redirect = new URL(link!).searchParams.get('redirect')!;
        const inner = new URLSearchParams(redirect);
        expect(inner.get('pricelist')).toBe(id);
        expect(inner.get('period')).toBe(String(months[key]));
        expect(Number(inner.get('period'))).not.toBeNaN();
      }
    });
  }
});

describe('order link guard (no open redirects from upstream data)', () => {
  const ok = `${BM}/billmgr?func=register&redirect=startpage%3Dvds%26pricelist%3D1`;
  it('accepts the BILLmanager register link', () => expect(guardOrderLink(ok, BM)).toBeDefined());
  it('rejects other hosts, schemes, paths and functions', () => {
    expect(guardOrderLink('https://evil.example/billmgr?func=register', BM)).toBeUndefined();
    expect(guardOrderLink('http://hosting.gcore.com/billmgr?func=register', BM)).toBeUndefined();
    expect(guardOrderLink('https://hosting.gcore.com.evil.example/billmgr?func=register', BM)).toBeUndefined();
    expect(guardOrderLink('https://hosting.gcore.com@evil.example/billmgr?func=register', BM)).toBeUndefined();
    expect(guardOrderLink(`${BM}/other?func=register`, BM)).toBeUndefined();
    expect(guardOrderLink(`${BM}/billmgr?func=logon`, BM)).toBeUndefined();
    expect(guardOrderLink('javascript:alert(1)', BM)).toBeUndefined();
    expect(guardOrderLink('not a url', BM)).toBeUndefined();
    expect(guardOrderLink(undefined, BM)).toBeUndefined();
  });
});
