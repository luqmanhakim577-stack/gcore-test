import { describe, expect, it } from 'vitest';
import { FeedShapeError, parseCalcFeed } from '@/lib/billmanager/calc-feed';
import { fixture } from '../helpers/upstream';

describe('calc feed (S1) against recorded real data', () => {
  const vps = parseCalcFeed('vps', fixture('calc-vps.json'));
  const ded = parseCalcFeed('dedicated', fixture('calc-dedicated.json'));

  it('parses every row of both feeds', () => {
    expect(vps.invalid).toEqual([]);
    expect(ded.invalid).toEqual([]);
    expect(vps.rows.length).toBeGreaterThan(300);
    expect(ded.rows.length).toBeGreaterThan(250);
  });

  it('ids are unique (they are BILLmanager pricelist ids)', () => {
    const all = [...vps.rows, ...ded.rows].map((r) => r.id);
    expect(new Set(all).size).toBe(all.length);
  });

  it('only EUR and USD occur', () => {
    const cur = new Set([...vps.rows, ...ded.rows].map((r) => r.server_price.currency));
    expect([...cur].sort()).toEqual(['EUR', 'USD']);
  });
});

describe('calc feed validation', () => {
  const good = JSON.parse(fixture('calc-vps.json')) as Array<Record<string, unknown>>;

  it('rejects non-JSON', () => {
    expect(() => parseCalcFeed('vps', '<html>502</html>')).toThrow(FeedShapeError);
  });
  it('rejects non-array and empty arrays', () => {
    expect(() => parseCalcFeed('vps', '{"a":1}')).toThrow(/not an array/);
    expect(() => parseCalcFeed('vps', '[]')).toThrow(/empty/);
  });
  it('rejects duplicate ids', () => {
    expect(() => parseCalcFeed('vps', JSON.stringify([good[0], good[0]]))).toThrow(/duplicate id/);
  });
  it('tolerates a few bad rows but rejects a feed that mostly fails validation', () => {
    const oneBad = [...good.slice(0, 200), { id: 'x' }];
    const r = parseCalcFeed('vps', JSON.stringify(oneBad));
    expect(r.invalid).toHaveLength(1);
    expect(r.rows).toHaveLength(200);

    const mostlyBad = good.slice(0, 50).map((r) => ({ ...r, server_price: undefined }));
    expect(() => parseCalcFeed('vps', JSON.stringify(mostlyBad))).toThrow(FeedShapeError);
  });
  it('rejects an unknown currency', () => {
    const row = structuredClone(good[0]) as { server_price: { currency: string } };
    row.server_price.currency = 'GBP';
    expect(() => parseCalcFeed('vps', JSON.stringify([row]))).toThrow(FeedShapeError);
  });
});
