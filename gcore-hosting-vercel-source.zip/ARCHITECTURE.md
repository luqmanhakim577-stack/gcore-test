# gcore.hosting rebuild — architecture and implementation plan (for approval)

Status: **proposal, nothing implemented**. Date: 2026-11-01.
All facts in section 2 were measured against the live endpoints on 2026-11-01; nothing is assumed from docs alone.

---

## Update 2026-11-01 (after implementing Phases 0-2): what the full live run showed

The proposal below was approved with all defaults (D1-D10). Running the real sync over all plans changed or sharpened several statements; where this section and the text below disagree, **this section wins**.

1. **All 337 EUR plans are public in BILLmanager** (360 VPS + 312 dedicated rows in the feed = 337 EUR + 335 USD). All 335 USD plans are unconfirmed (not requested; D1 default). Orderable today: 337 EUR plans (one is excluded from "verified", see 3).
2. **The calc feed drifts from BILLmanager for 6 EUR plans** (5 dedicated, 1 VPS), sometimes by a lot:
   `126334` (Johannesburg) feed 374.00 vs BILLmanager 149.99 monthly; `129931` (Singapore) 189.00 vs 109.90; `129847` (Singapore) 296.00 vs 149.99; `130843`, `156915` (Sao Paulo) 129.99 vs 119.99 and 149.99 vs 129.99; VPS `176572` (Tokyo) quarterly 44.97 vs 42.72. This is exactly why BILLmanager wins on conflict: the site shows BILLmanager's price and flags the plan. **Whoever owns the calc feed should be told**, because other consumers of that feed show the wrong price.
3. **Plan `176811` (Sao Paulo dedicated)** still has quarterly > 3 x monthly in BILLmanager itself. It is published with its flag, excluded from `verified`, from "from X" aggregates and from Offer markup.
4. **VPS `173591` (Mumbai, `KVM-SSD-5-WW`)**: calc feed says 8 vCPU, BILLmanager's description says 6 (the same tier has 6 vCPU in Ashburn). Flagged `spec-mismatch`; the page must not show a vCPU count for it until resolved.
5. The earlier "3 VPS plans with no period discount": `176572` is a calc-feed error (BILLmanager has the discount); `170274` and `176665` (both USD) remain unconfirmed.
6. **Locations:** 21 distinct locations. BILLmanager uses different codes for VPS and dedicated in Sao Paulo (`SP3` vs `ASP5`), so they may be different facilities; the model keeps a code per product kind and the site must not claim they are the same site.
7. **Sync cost:** a full cold sync takes about 50 s (about 70 `pricelist.export` requests, concurrency 2). Incremental syncs reuse BILLmanager detail while the calc-feed row is unchanged and the detail is under 6 h old.
8. **BILLmanager batches fail as a whole** when they contain one plan the anonymous user cannot see, naming the first offender; the client removes it and retries. A circuit breaker stops retries after 4 exhausted requests so a down panel is not hammered.

9. **Add-on semantics (Phase 5, verified against 337 live EUR plans and BILLmanager docs):** `addonlimit` = "Tariff plan includes". VPS disk/RAM/vCPU add-ons are "Do not bill" and equal the plan's own specs on all 180 VPS plans, an independent confirmation of the feed (now a permanent check, flag `addon-spec-mismatch`). Units differ per plan (GiB vs MiB): Almaty VPS report `102400` for a 100 GB disk, so the unit must always be read. Extra IPv4 is priced per address above the 1 included. Dedicated traffic is a single-choice list, one tier included, others surcharged. For `173591` (Mumbai KVM-SSD-5) the feed (8 vCPU) and BILLmanager's "CPU number" add-on (8) agree and only the description text says 6, so the description is probably stale; the spec stays withheld until the owner confirms.
10. **Order prefill is unverifiable without an account** and is switched off (README, "Configurator").

11. **Phase 7 changed three decisions below** (this block wins over sections 3, 6 and 9):
    - **CSP is static, not nonce-based.** Next can only apply a nonce while rendering a request, so a nonce policy turns every page dynamic: no static generation, no ISR, no CDN caching (Next documents the trade-off). This site renders no user content and has no accounts or state-changing forms, so pages stay static under a policy that still forbids plugins, `<base>`, framing, every third-party origin and cross-origin connections. `script-src` keeps `'unsafe-inline'` for the inline payload Next writes into each static page; `tests/ssr/security-output.test.ts` scans all pre-rendered pages for anything that would need more (external loads, inline handlers, unexpected inline scripts, JSON-LD that could leave its element). Next's experimental SRI mode is the way to remove `'unsafe-inline'` later; it is experimental and was not adopted.
    - **Replicas coordinate through a Redis stream, not a Redis `cacheHandler`.** Each replica's Next cache is local, so `revalidateTag` on one replica did nothing for the others. A sync (or an operator) announces its tags by appending to `gcore:revalidation`; every replica replays what it has not seen and revalidates itself. A replica built from an older snapshot than the live one revalidates everything once at boot (`site` tag, carried by every cached loader; the build's snapshot id is embedded by `next.config.ts` from `.cache/build-info.json`). Trade-off against a shared cache handler: every replica renders its own pages (cheap, they read the same snapshot), and no dependence on Next's cache-entry serialization. Verified with two real servers (`npm run check:replicas`).
    - **`revalidateTag` throws outside a request** ("static generation store missing"), which the in-process scheduler hit: in Phases 2-6 a scheduled sync published the snapshot but never refreshed the page cache, so pages caught up only through the hourly safety net. Background code now applies tags through the replica's own signed `POST /api/internal/revalidate` (scope `local`), retrying until its server accepts them.
    - **Freshness is one number.** Pages, the page-data cache and the sitemap revalidate every `SYNC_INTERVAL_MINUTES` (10); shared caches may reuse API responses for 5 minutes and HTML for 10, with only a minute of stale-while-revalidate (Next's default was a year). `tests/cache/freshness.test.ts` keeps the literals in the route files equal to the constant.

Implemented so far: `src/lib/billmanager` (calc feed, pricelist.export, spec parsers), `src/lib/catalog` (model, normalize, reconcile, sync, diff, store), `src/lib/security`, `src/lib/cache` (replica coordination), `src/lib/api` and the `/api` routes. See README.md for the state table and docs/LAUNCH.md for what is verified and what is not.

---

## 1. Requirements analysis (condensed)

| Area | Decision-relevant reading of the brief |
|---|---|
| Source of truth | BILLmanager 6 (`hosting.gcore.com`). No commercial value or BILLmanager-managed spec is hardcoded anywhere. |
| SSR | Prices, periods, specs, availability are in the first HTML byte stream. No client-only price rendering. |
| Scale | ~156 VPS plan×location pairs and ~156 dedicated pairs (×2 currencies in the calc feed), 15 VPS and ~17 dedicated locations. Small enough to pre-render everything. |
| SEO/AEO | Indexable: category, location, plan pages. Non-indexable: filter/sort/period/currency combinations. |
| Security | BILLmanager credentials (if any are needed) stay server-side. Browser only ever talks to our own origin. |

## 2. What the live systems actually look like (inspection results)

### 2.1 Two sources, not one

| | **S1: calc feed** `hosting-calc-prod.i.gc.onl/{vps,dedicated_servers}/?format=json` | **S2: BILLmanager `pricelist.export`** `hosting.gcore.com/billmgr?func=pricelist.export&out=json&pricelist=<id>` |
|---|---|---|
| Auth | none | none for public plans (documented as the website-integration function) |
| Shape | flat array, 360 VPS rows / 312 dedicated rows, ~180 KB each | one deep object per plan, ~63–100 KB each, values wrapped as `{"$": "…"}` |
| Gives | name, cpu, ram, disk, country, DC, 4 period prices, os_price, traffic, port speed | the above **plus** `orderlink` (plan and per-period), add-ons with prices, HTML description, itemtype, datacenter id, currency, plan `active` flag |
| Content-Type | `text/html` (body is JSON; must not trust the header) | `application/json` |
| Cost | one request | ~1.3 s per 6 plans; bulk call with no `pricelist` param **504s at 30 s**, so bulk is not usable |

The `id` in S1 **is** the BILLmanager pricelist id (verified: S1 and S2 prices matched for 6/6 sampled VPS ids and 3/3 sampled dedicated ids, to the cent).

**Consequence:** S1 is the cheap, complete *index*; S2 is the *authoritative detail*. The integration uses both and reconciles them (section 5).

### 2.2 Data-quality findings you need to know about (affect design, and some need an owner decision)

1. **USD plans are not publicly exportable.** Every sampled USD plan (3/3 VPS, 7/7 dedicated) returns `invalid value` from `pricelist.export`; every sampled EUR plan works. S1 lists USD and EUR twins with different ids. So today only EUR prices have a verifiable, anonymously-fetchable order link. See Decision D1.
2. **VPS `discount` is `0` on all 360 rows, but the period prices already embed discounts** (quarterly 5%, semi-annual 10%, annual 20% off monthly×N, on 357 of 360 rows). The field is unusable; discounts must be derived from the period prices themselves.
3. **Dedicated `discount` is the reverse:** declared 2 / 6 / 10 % on all 312 rows, but period prices equal monthly×N exactly (BILLmanager agrees with S1). Either the discount is applied at checkout or the field is stale. We must not advertise those percentages until confirmed. Decision D2.
4. **Outliers that look like BILLmanager configuration errors** (BILLmanager itself returns the same numbers, so this is not a feed bug):
   - dedicated `176811` (Brazil): monthly 693 EUR, quarterly 3087 (more than 3×monthly), semi-annual 6174, annual 12348.
   - 3 VPS rows with no period discount at all (`170274`, `176572`, `176665`).
5. **Pairing gaps:** 6 dedicated plans exist in only one currency (e.g. Amsterdam `E3-1270v6-16Gb-…-DRA4` USD only).
6. **Unit chaos in specs:** `GB` / `Gb` / `MB` (`1024 MB`), disk `20 Gb`, dedicated `128Gb`, `2x960SSD`, `2x2000SSD + 2x4000SATA`, traffic `∞` / `10000GB` / `30 TB`. Needs a strict parser with a "cannot parse → flagged, not guessed" path.
7. **`os_price` meaning is unconfirmed.** It is `null` on the 6 smallest plans per location and 25–30 EUR/USD on larger ones; in BILLmanager it lines up with an "Operating systems" add-on (`ostemplpay`) and, on dedicated, `Windows_lic` / `Mssql_lic` add-ons. It is probably a paid-OS-license surcharge, but I will not label it until confirmed. Decision D3.
8. **Storage type conflict:** the VPS plan descriptions in BILLmanager say "SSD" (`KVM-SSD-*`, "Disk: 500GB SSD"), while the current marketing page says "NVMe SSDs". The API does not say NVMe for VPS. We will only say what BILLmanager says per plan (SSD). Decision D4.
9. **Location naming is inconsistent:** a dedicated location called plain `DC 2` (country "Luxembourg", name suffix `ED`) and `Amsterdam, DC 2`. We need a slug/entity map for 17 dedicated + 15 VPS locations; names will come from the feed, our map only adds slugs and copy.
10. **No CPU class, no storage class for VPS, no DDoS/network facts in the feed.** "Shared vs dedicated CPU", NVMe, DDoS scope, BGP etc. cannot be derived from S1/S2. Those can only appear as editorial content that is explicitly sourced and reviewed (section 8), never inferred from plan names.
11. **Dedicated traffic is metered by add-on** in BILLmanager: tiered included traffic (e.g. 30 TB / 60 TB / 150 TB at 1 Gbps), overage price per GB, and an "X Gbps unlimited traffic, burst price per Mb/s" option. The feed's single `traffic` string hides this; the configurator should read the add-ons.

### 2.3 Current site (gcore.hosting)

Single landing page that is the `gcore.com` ghost-landing: canonical points to `gcore.com/ghost-landing`, no JSON-LD, no hreflang, `robots.txt` is `Allow: /`, sitemap index points at gcore.com sitemaps. **There is no existing URL structure to preserve** beyond `/`, `/legal`. Marketing claims on it (99.99% uptime, 200 Tbps filtering, 45+ locations) are **not** present in the BILLmanager data and will not be republished without a source (see D4/D5).

### 2.4 BILLmanager 6 functions required

| Function | Purpose | Auth | Use |
|---|---|---|---|
| `pricelist.export` (`pricelist`, `onlyavailable`, `itemtype`, `out=json`) | plan detail, periods, add-ons, order links | public | **primary detail source** |
| `register&redirect=startpage…startform…pricelist…period…project…addon_N` | order deep link (documented format; BILLmanager also returns ready-made links in `orderlink` and in `price.period[].orderlink`) | public | **order buttons**; we use returned links verbatim, and only *append* `addon_N` for configurator selections |
| `pricelist` (list) | list plan ids | admin | not needed if S1 is the index |
| `auth` / `authinfo` / `session.newkey` | API login | secret | **not used** unless D1 requires a read-only staff account for USD plans |

Docs note that exact function/parameter names depend on the panel configuration, which is why every one of the above was verified live instead of copied from docs.

---

## 3. Technology architecture

```
                 ┌──────────────────────────┐
 S1 calc feed ──▶│                          │   write versioned snapshot
 S2 pricelist ──▶│  Catalog sync (worker)   │──────────────┐
   .export       │  fetch→normalize→validate│              ▼
                 └─────────▲────────────────┘      ┌───────────────┐
        cron (every 10 min) │  webhook (manual)     │ Redis         │
                            │                       │ catalog:v{n}  │
                 POST /api/internal/revalidate      │ catalog:live  │
                 (HMAC)                             └───────▲───────┘
                                                            │ read only
 Browser ◀── HTML (ISR, tag-revalidated) ◀── Next.js 15 App Router (Node runtime)
              └─ /api/v1/* public JSON (read-only, rate limited)
```

- **Next.js 15 App Router, TypeScript strict, Tailwind v4**, Node runtime (not Edge: Redis + large JSON). React Server Components render every price. Client JS only for the configurator/period toggle, which is progressive enhancement.
- **Hosting target:** Node container (Docker) behind the company's CDN/reverse proxy. I'm assuming self-hosted/containerised, not Vercel-only; Redis requires a network-reachable instance. (Decision D6.)
- **Package choices:** `zod` (all external input), `ioredis`, `decimal.js` (money), `schema-dts` (typed JSON-LD), `vitest` + `@testing-library`, `playwright` (SSR/mobile/CWV), `msw` for **tests only**, `pino` logging. Next-ISR shared across replicas via a custom `cacheHandler` backed by Redis.
- **Rendering matrix**

| Route | Strategy |
|---|---|
| `/`, `/vps`, `/dedicated-servers`, `/locations`, `/locations/[slug]`, `/vps/[location]`, `/dedicated-servers/[location]`, plan pages | **SSG + ISR** (`revalidate` as a safety net, plus tag revalidation) |
| `/compare`, `/configure/*` | SSR shell, client-side enhancement over server-provided data |
| `/api/v1/*`, `llms*.txt`, `sitemap.xml` | route handlers, cached, tag-invalidated |
| `/api/internal/*` | HMAC-protected, never linked |

## 4. Internal data model (normalized)

```ts
type Money = { amount: string /* decimal string, never float */; currency: 'EUR' | 'USD' };
type PeriodKey = 'monthly' | 'quarterly' | 'semiannually' | 'annually';

interface Plan {
  id: string;                 // BILLmanager pricelist id (stable)
  kind: 'vps' | 'dedicated';
  name: string;               // as in BILLmanager
  family: string;             // derived: 'KVM-SSD' | 'KVM-HIGHCPU-SSD' | …  (parsed, not invented)
  locationId: string;         // → Location
  currency: 'EUR' | 'USD';
  specs: {                    // all optional; each carries provenance
    vcpu?: number; ramMiB?: number;
    disks?: { count: number; sizeGB: number; type: 'SSD'|'SATA'|'SAS'|'NVMe' }[];
    cpuModel?: string; cpuSockets?: number; gpu?: string; raid?: boolean;
    portMbps?: number; traffic: { kind: 'unlimited' | 'metered'; includedGB?: number };
  };
  specRaw: Record<string,string>;   // original strings, always kept
  prices: Record<PeriodKey, Money>; // exactly BILLmanager's period price
  perMonthEquiv: Record<PeriodKey, Money>; // computed for display only
  osSurcharge?: Prices;             // labelled only after D3
  addons: Addon[];                  // from S2: id, name, kind, min/max/step, per-period price
  order: { base: string; byPeriod: Record<PeriodKey,string>; addonParam: (id:string,v:number)=>string };
  availability: 'orderable' | 'unavailable' | 'unknown'; // S2 `active`/visibility; never guessed
  quality: { flags: string[] };     // 'period-price-anomaly', 'spec-unparsed', 'no-s2', …
  source: { s1At: string; s2At?: string; hash: string };
}

interface Location { id; slug; country; city; dcLabel?; kinds: ('vps'|'dedicated')[]; code: string /* ANX, FRN… */ }
```

Rules: money as decimal strings; the displayed price is always BILLmanager's period price, never recomputed; the per-month equivalent and "saving vs monthly" are derived and labelled as such; EUR and USD are separate catalogs (different ids), never converted by us.

## 5. Sync, validation and reconciliation

1. Fetch S1 (both kinds). Validate with zod; reject whole sync if shape changes or counts drop > 20% vs the live snapshot.
2. For each plan id, fetch S2 in batches of ≤5 ids, concurrency 2, timeout 20 s, retry with backoff, a global budget so we never hammer the production billing host (roughly 70 requests per full sync for the ~336 EUR plans, estimated at a few minutes). Incremental: S2 is refetched only for ids whose S1 hash changed, plus a full refresh nightly.
3. Normalize (strict unit parsers), reconcile S1↔S2 (period prices must match to 0.005; mismatch → S2 wins, flag `price-mismatch`, alert).
4. Sanity rules: positive prices, quarterly ≤ 3×monthly, annual ≤ 12×monthly. Violations (like `176811`) are **published as-is but flagged**, excluded from "from €X" aggregates and comparisons, and surfaced in an admin report. We never silently "fix" a price.
5. Publish as `catalog:v{n}`, atomically move `catalog:live`. On any failure keep serving the last good snapshot; expose its age in `/api/internal/health`.

## 6. Caching and revalidation

| Layer | TTL | Invalidation |
|---|---|---|
| Redis `catalog:live` | no TTL, replaced atomically | new snapshot |
| Next data/page cache (Redis cacheHandler) | `revalidate: 3600` safety net | `revalidateTag('plan:{id}')`, `'location:{slug}'`, `'kind:vps'` for **changed plans only**, computed by diffing hashes |
| CDN | `s-maxage=300, stale-while-revalidate=86400` on HTML and API | purge by tag/URL after revalidation if the CDN supports it |
| Sync trigger | every 10 min scheduler **and** `POST /api/internal/revalidate` (HMAC, optional BILLmanager-side hook) | — |

Stale policy: if the snapshot is older than 6 h the pages still render (last-known prices) but an internal alert fires; if older than 48 h, order buttons keep working but a visible "prices as of {date}" notice is shown. Stampede protection with a Redis lock; secure caching means no per-user data in shared caches, no cookies on cacheable responses, cache keys built only from validated params.

## 7. URL, SEO and AEO architecture

**URLs (EN first, i18n-ready via `/{locale}/` prefix + hreflang; extra locales only after copy exists):**
`/vps`, `/vps/{location}`, `/vps/{location}/{plan-slug}`, `/dedicated-servers`, `/dedicated-servers/{location}`, `/dedicated-servers/{location}/{plan-slug}`, `/locations`, `/locations/{location}`, `/compare/vps-vs-dedicated-server`, `/learn/*` (glossary and Q&A), `/about`, `/legal`.
Plan slugs come from the BILLmanager name plus id suffix, so renames never 404 (old slug 301s to current by id).

**Indexation control**
- Indexable and in sitemap: hubs, location pages, plan pages with `availability=orderable`, learn pages.
- `noindex,follow` + canonical to the clean URL: any `?period=`, `?sort=`, `?currency=`, `?cpu=` etc. Filter state lives in the query string and is client-enhanced; server HTML always has the full table for the canonical state.
- Currency/period never create separate indexable pages. Duplicate EUR/USD twins collapse into one page.
- Plans flagged `price-anomaly` or unavailable: `noindex`, no `Offer` markup.

**Per page:** unique `<title>`/description generated from real data (e.g. lowest EUR monthly price in that location, computed at build), self-canonical, hreflang (`x-default` + locale), breadcrumbs with `BreadcrumbList`, semantic HTML (`table` with `caption/th scope`, `dl` for specs), internal links (hub ↔ location ↔ plan, "same plan in other locations", "dedicated alternative").

**Structured data (all generated from the same normalized objects as the visible HTML, so they cannot drift):**
`Organization` + `WebSite` (site-wide), `BreadcrumbList`, `Product` + `Offer`/`AggregateOffer` for plan and location pages (price, `priceCurrency`, `availability` only when known, `url` = order link, `priceValidUntil` omitted unless BILLmanager supplies one), `ItemList` on hubs, `FAQPage` only where the Q&A is visible on the page. Validated in CI against schema.org types and our own rules (price in JSON-LD == price in HTML). No `AggregateRating`/reviews (we have no review data).

**AEO / GEO**
- Public read-only JSON: `GET /api/v1/catalog`, `/plans`, `/plans/{id}`, `/locations`, `/products`; versioned, ETag, `Cache-Control`, snapshot timestamp and `currency` in every payload, schema published at `/api/v1/openapi.json`, per-IP rate limit.
- `/llms.txt` (curated index + how to use the API) and `/llms-full.txt` (generated catalog in Markdown, entity glossary, pricing snapshot with "as of" date and canonical links). Honest framing: these files are conventions that some tools read; we do not claim they improve citation.
- Entity architecture: Company → Products (VPS, Dedicated) → Locations → Plans, each with a stable URL, a consistent name, and `@id`s reused across JSON-LD.
- Q&A content: each hub/location page has 5–8 questions people actually ask (VPS vs dedicated, how billing periods work, what "traffic unlimited" means here, which locations, how to order) with **answers built only from BILLmanager data or reviewed editorial facts**.
- `robots.txt` allows mainstream search and AI crawlers explicitly (a policy choice, D7); sitemap split by section with `lastmod` = the plan's `source.s1At` change time, not "now".

**As built in Phase 6 (deviations from the plan above are deliberate):**
- API contract: `src/lib/api/schemas.ts` holds zod schemas for the query and for every response. Handlers validate with them, `/api/v1/openapi.json` (OpenAPI 3.1) is generated from them, and tests parse real responses with them under `.strict()`; `Equal<>` type assertions tie them to the TypeScript interfaces. The planned `/catalog` and `/products` endpoints were dropped: `/plans` (filterable) and `/locations` already carry everything, and a third view of the same data would only add drift risk.
- `/llms.txt` and `/llms-full.txt` are route handlers rendered from the snapshot by `src/lib/aeo/llms.ts`, cached with the `catalog` tag (so a sync that changes anything refreshes them) and pre-rendered at build. Both state the reading rules a machine must not get wrong (period price vs per-month figure, absent spec means unknown, port speed is not throughput, unmetered is not unlimited use) and list what the site does **not** state about Gcore's infrastructure.
- The planned `/compare/vps-vs-dedicated-server` became `/learn/vps-vs-dedicated-server`: six guides (VPS vs dedicated, shared vs dedicated CPU, SSD vs NVMe, port speed vs traffic, billing periods, DDoS) plus `/learn/glossary`. They are industry-general and make no statement about Gcore's network, hardware, SLA or protection (`tests/content/claims.test.ts` enforces: no absolute marketing claims, no first-person capability claims, no named third-party providers or certifications). The only Gcore-specific sentences are computed from the billing data at render time (`src/lib/aeo/learn-data.ts`) or say what the site does not publish.
- `FAQPage` is emitted on the guides, from the same strings as the visible, uncollapsed Q&A. Google restricts FAQ rich results to a few site types, so this is for other parsers and answer engines; no rich result or citation is promised. The glossary is a `DefinedTermSet`.
- Editorial facts about Gcore live in `src/content/facts.ts` (typed, validated with zod) instead of the planned `facts.yaml`: an entry needs a scope (company, one location, or one plan family), an evidence level, a source and a verification date. It is empty. Once an entry exists it is rendered with its scope everywhere (llms-full.txt, the DDoS guide), and the "not stated" notice for that topic disappears. See `docs/OWNER-FACTS.md`.
- A bug found on the way: the public API returned specs that the pages withhold (plan 173591 vCPU). `publicSpecs()` now applies the same withholding as the pages.

## 8. Hosting-domain correctness policy

- **Fact tiers.** (a) *Feed facts*: vCPU, RAM, disk size/count/type string, port speed, traffic, price, period, location. Shown directly. (b) *Parsed facts*: CPU model, RAID flag, GPU from name; shown with parser tests. (c) *Editorial facts*: DDoS protection scope, shared/dedicated CPU, NVMe, BGP/IP transit, colocation, uptime SLA, network capacity. **Not in any feed**; they can only appear if the Gcore team supplies the statement and a source, tracked in `content/facts.yaml` with owner + date + source. Until then, pages say nothing about them or link to the owner-approved page.
- **Educational content** (VPS vs dedicated, SSD vs NVMe, metered vs unmetered, port speed vs traffic, BGP vs transit, colocation) is written as generic industry explanation, clearly separated from Gcore-specific claims.
- **VPS "traffic ∞" with a 200 Mbit/s port** is rendered as "unmetered traffic, 200 Mbit/s port" (that is what the feed states); we do not add fair-use terms we do not have.
- **Colocation:** no data in the feed, so no colocation product page ships unless you provide the offering.

## 9. Security

- Secrets only in server env (`BILLMANAGER_*` if ever needed, `REVALIDATE_HMAC_SECRET`, `REDIS_URL`); validated at boot with zod; nothing prefixed `NEXT_PUBLIC_`. The two data sources are public, so **no BILLmanager credentials are required for the proposed design**.
- Browser → our origin only. SSRF-safe fetchers: fixed allow-listed hosts, no user-supplied URLs.
- Internal endpoints: HMAC with timestamp + replay window; constant-time compare; separate from public rate-limit tier.
- Public API: zod-validated params, per-IP sliding-window rate limit in Redis, response size caps, CORS `GET` only.
- Order links: we only emit links whose host is `hosting.gcore.com` and match the expected path, verified at sync time (a poisoned feed cannot inject an open redirect).
- Headers: CSP (nonce), HSTS, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`, frame-ancestors none. Structured logging (pino) with request ids; no PII; dependency audit in CI.

## 10. Testing strategy

| Requirement | Test |
|---|---|
| BILLmanager integration | contract tests with **recorded real responses as fixtures** (S1, S2 incl. the error shape, 504); zod schema break test; live smoke test (opt-in, nightly) |
| Price accuracy | property tests: displayed == feed for every plan; S1↔S2 reconciliation; anomaly flags (`176811` is a standing regression case); decimal arithmetic |
| Billing period accuracy | each period maps to the correct `period` id/length and the correct order-link `period=` |
| SSR HTML | Playwright with JS disabled: price, period, specs, location present in raw HTML for every route type |
| Structured data | parse every JSON-LD block, validate type rules, assert JSON-LD price == HTML price |
| SEO metadata | unique titles/descriptions across the site, canonical self-reference, hreflang reciprocity, noindex on filter URLs, sitemap contains only indexable canonicals |
| API security | auth/HMAC failure, replay, rate limit, input fuzz, no secret in any response or bundle (grep build output) |
| Cache invalidation | change a fixture price → sync → exactly that plan's tags revalidate, other pages unchanged; stale-on-failure behaviour |
| Mobile responsiveness | Playwright 375/768/1280 viewports: no horizontal overflow, tap targets, tables reflow |
| Performance | Lighthouse CI budgets (LCP < 2.5 s, CLS < 0.1, INP proxy via TBT), JS size budget per route |

Fixtures are real captured API responses, not invented data; mocks exist only in the test tree.

## 11. Implementation plan (phased, each phase demoable and reviewable)

| Phase | Deliverable | Gate |
|---|---|---|
| 0 | Repo scaffold, CI, env validation, Docker, Redis wiring | green CI |
| 1 | BILLmanager integration layer (S1+S2 clients, normalizers, reconciliation, snapshot store, health) + contract tests | fixtures of real data pass; quality report of all anomalies |
| 2 | Catalog API (`/api/v1`), revalidation endpoint, tag-based invalidation | cache-invalidation tests |
| 3 | Core pages: VPS hub/location/plan, Dedicated hub/location/plan, comparison table, period selector, order buttons, SSR tests | no-JS HTML passes |
| 4 | SEO layer: metadata, sitemap, robots, hreflang, breadcrumbs, JSON-LD, indexation rules | validation tests |
| 5 | Configurator (add-ons from S2) + order-link builder | order links verified against BILLmanager format |
| 6 | AEO layer: llms.txt/llms-full.txt, OpenAPI, Q&A/learn content (needs owner facts) | done for everything the data supports; owner facts registry is empty by design |
| 7 | Security hardening, perf tuning, mobile QA, launch checklist, redirect plan | budgets met |

## 12. Decisions needed from you before Phase 0

| # | Question | Why it matters / my default |
|---|---|---|
| D1 | **USD plans**: anonymous `pricelist.export` rejects them. Is USD meant to be public? If yes, is there a read-only BILLmanager staff account / access-group change we can use (server-side only)? | Default: **EUR-only orderable pricing at launch**, USD shown only if an order link can be produced. |
| D2 | Dedicated `discount` 2/6/10 %: applied at checkout or stale field? | Default: not advertised. |
| D3 | `os_price`: what exactly is it (Windows license? panel?) and is it mandatory or optional? | Default: shown as "optional OS surcharge, see order page" only after confirmation; hidden until then. |
| D4 | VPS storage: SSD (BILLmanager) or NVMe (marketing)? | Default: say SSD, nothing about NVMe. |
| D5 | Source for editorial facts: DDoS scope, SLA, CPU type, network/BGP, support. Who owns them? | Default: omitted until supplied in `facts.yaml`. |
| D6 | Hosting/runtime: containerised Node + managed Redis OK? | Default: yes. |
| D7 | AI crawler policy: allow all? | Default: allow. |
| D8 | Languages at launch (BILLmanager has `name_ru`; current site is EN)? Domain strategy given the canonical currently points to gcore.com? | Default: EN only, i18n-ready, self-canonical on gcore.hosting. |
| D9 | Fix the BILLmanager anomalies (`176811`, 3 VPS no-discount rows, 6 one-currency dedicated plans) before launch? | We flag but never alter prices. |
| D10 | Dedicated order flow: confirm `startform=dedic.order` links are right for the hidden/USD plans and that a plan listed in S1 but not in S2 should not be orderable. | Default: such plans are listed as "contact sales"/hidden, noindex. |
