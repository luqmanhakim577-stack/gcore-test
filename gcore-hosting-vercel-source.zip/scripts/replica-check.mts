// End-to-end check of cache coordination between replicas, with real production servers:
//
//   npm run build && npm run check:replicas
//   REDIS_URL=redis://host:6379 npm run check:replicas     # against a real Redis (uses throwaway keys? NO: see below)
//
// It starts two copies of the standalone build as two replicas sharing one Redis, publishes a changed
// snapshot, announces it to ONE replica and measures how long the OTHER takes to show it. Then it boots a
// third replica from the original build while the live snapshot has moved on, and checks that its boot
// reconciliation replaces the stale pages it was built with.
//
// Without REDIS_URL it starts scripts/mini-redis.mts (a stand-in, not Redis). With REDIS_URL it writes the
// project's real keys (gcore:catalog:*, gcore:revalidation): point it at a throwaway Redis, never production.
import { spawn, type ChildProcess } from 'node:child_process';
import { cpSync, existsSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { Redis } from 'ioredis';
import { diffCatalogs, tagsForDiff } from '../src/lib/catalog/diff';
import { catalogId, type Catalog, type CatalogMeta } from '../src/lib/catalog/model';
import { RedisStore } from '../src/lib/catalog/store';
import { listedPlans, planPath } from '../src/lib/catalog/views';
import { formatMoney } from '../src/lib/format';
import { signRequest } from '../src/lib/security/hmac';
import { startMiniRedis } from './mini-redis.mts';

const standalone = path.join(process.cwd(), '.next', 'standalone');
const snapshotFile = path.join(process.cwd(), '.cache', 'catalog.json');
if (!existsSync(path.join(standalone, 'server.js')) || !existsSync(snapshotFile)) {
  console.error('Run `npm run build` first (needs .next/standalone and .cache/catalog.json).');
  process.exit(2);
}

const SECRET = 'replica-check-secret-'.repeat(2);
const POLL_BUDGET_MS = 30_000;
const results: Array<{ name: string; ok: boolean; detail: string }> = [];
const check = (name: string, ok: boolean, detail = '') => {
  results.push({ name, ok, detail });
  const shown = !ok || /^\d+ ms|^€|^status/.test(detail) ? detail : ''; // server logs only when something failed
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${shown ? `  (${shown})` : ''}`);
};
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const dirs: string[] = [];
const children: ChildProcess[] = [];

function startReplica(name: string, port: number, redisUrl: string): { dir: string; proc: ChildProcess; log: () => string } {
  const dir = mkdtempSync(path.join(tmpdir(), `replica-${name}-`));
  dirs.push(dir);
  cpSync(standalone, dir, { recursive: true }); // a separate copy = a separate on-disk page cache, like a separate container
  let out = '';
  const proc = spawn(process.execPath, ['server.js'], {
    cwd: dir,
    env: {
      ...process.env,
      NODE_ENV: 'production',
      PORT: String(port),
      HOSTNAME: '127.0.0.1',
      REDIS_URL: redisUrl,
      REVALIDATE_HMAC_SECRET: SECRET,
      SITE_URL: `http://localhost:${port}`,
      SYNC_SCHEDULER: 'off', // snapshots are published by this script, not fetched from upstream
      LOG_LEVEL: 'info',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  proc.stdout?.on('data', (d) => (out += d));
  proc.stderr?.on('data', (d) => (out += d));
  children.push(proc);
  return { dir, proc, log: () => out };
}

async function waitReady(port: number): Promise<boolean> {
  for (let i = 0; i < 240; i++) { // up to two minutes: a cold start right after a build on a busy machine can be slow
    try {
      if ((await fetch(`http://127.0.0.1:${port}/api/health`)).status === 200) return true;
    } catch { /* not listening yet */ }
    await sleep(500);
  }
  return false;
}

const page = async (port: number, p: string) => (await fetch(`http://127.0.0.1:${port}${p}`)).text();

async function waitFor(port: number, p: string, needle: string): Promise<number | null> {
  const t0 = Date.now();
  while (Date.now() - t0 < POLL_BUDGET_MS) {
    if ((await page(port, p)).includes(needle)) return Date.now() - t0;
    await sleep(500);
  }
  return null;
}

function withPrice(base: Catalog, planId: string, amount: string, version: number): Catalog {
  const next = JSON.parse(JSON.stringify(base)) as Catalog;
  const plan = next.plans.find((p) => p.id === planId)!;
  plan.prices.monthly = { ...plan.prices.monthly, amount };
  plan.perMonthEquiv.monthly = { ...plan.perMonthEquiv.monthly, amount };
  plan.source.hash = `replica-check-${amount}`;
  next.version = version;
  next.generatedAt = new Date().toISOString();
  return next;
}

async function main() {
  const mini = process.env.REDIS_URL ? null : await startMiniRedis();
  const redisUrl = process.env.REDIS_URL ?? mini!.url;
  console.log(`Redis: ${process.env.REDIS_URL ? 'REDIS_URL (real)' : `mini-redis stand-in at ${redisUrl}`}`);
  const redis = new Redis(redisUrl, { maxRetriesPerRequest: 2 });
  const store = new RedisStore(redis);

  const built = JSON.parse(readFileSync(snapshotFile, 'utf8')) as { catalog: Catalog; meta: CatalogMeta };
  const base = built.catalog;
  const plan = listedPlans(base, 'vps')[0]!;
  const url = planPath(plan);
  const oldPrice = formatMoney(plan.prices.monthly);
  const metaFor = (c: Catalog): CatalogMeta => ({ version: c.version, lastCheckedAt: c.generatedAt, lastPublishedAt: c.generatedAt });
  console.log(`Plan under test: ${plan.id} ${url}, price ${oldPrice}; build snapshot ${catalogId(base)}`);

  await store.publish(base, built.meta);

  const A = startReplica('a', 3201, redisUrl);
  const B = startReplica('b', 3202, redisUrl);
  check('replica A is ready', await waitReady(3201), A.log().slice(-300));
  check('replica B is ready', await waitReady(3202), B.log().slice(-300));

  // 0. Built from the live snapshot, so boot reconciliation must find nothing to do. This also proves the build's
  //    snapshot id really is embedded in the server bundle: with no id every replica would revalidate everything.
  await sleep(6000); // the first reconciliation runs 3 s after boot
  check('replicas built from the live snapshot do not revalidate at boot', !/live snapshot differs/.test(A.log() + B.log()));

  // 1. Both serve the page they were built with.
  check('both replicas start with the build-time price', (await page(3201, url)).includes(oldPrice) && (await page(3202, url)).includes(oldPrice), oldPrice);

  // 2. A new snapshot appears in Redis. Nothing has told the replicas yet.
  const NEW1 = '777.77';
  const snap1 = withPrice(base, plan.id, NEW1, base.version + 1);
  await store.publish(snap1, metaFor(snap1));
  await sleep(1000);
  const pre = formatMoney(snap1.plans.find((p) => p.id === plan.id)!.prices.monthly);
  check('without an announcement both replicas still serve the cached page', !(await page(3201, url)).includes(pre) && !(await page(3202, url)).includes(pre));

  // 3. Announce to ONE replica through the internal endpoint, as a sync (or an operator) would.
  const tags = tagsForDiff(diffCatalogs(base, snap1));
  const body = JSON.stringify({ tags });
  const res = await fetch('http://127.0.0.1:3201/api/internal/revalidate', {
    method: 'POST',
    body,
    headers: { 'content-type': 'application/json', ...signRequest(SECRET, 'POST', '/api/internal/revalidate', body) },
  });
  check('the internal endpoint accepted the announcement on A', res.status === 200, `status ${res.status}`);
  const onA = await waitFor(3201, url, pre);
  check('replica A shows the new price', onA !== null, onA === null ? 'timed out' : `${onA} ms`);
  const onB = await waitFor(3202, url, pre);
  check('replica B (never contacted) shows the new price through the shared log', onB !== null, onB === null ? `timed out after ${POLL_BUDGET_MS} ms` : `${onB} ms`);
  if (onB === null) console.log(B.log().slice(-1500));

  // 4. Boot reconciliation: a replica started from the ORIGINAL build while the live snapshot has moved on.
  B.proc.kill();
  const NEW2 = '888.88';
  const snap2 = withPrice(base, plan.id, NEW2, base.version + 2);
  await store.publish(snap2, metaFor(snap2));
  const pre2 = formatMoney(snap2.plans.find((p) => p.id === plan.id)!.prices.monthly);
  const C = startReplica('c', 3203, redisUrl);
  check('replica C (fresh image, live snapshot has moved on) is ready', await waitReady(3203), C.log().slice(-300));
  const onC = await waitFor(3203, url, pre2);
  check('replica C replaces its build-time pages after booting (boot reconciliation, background loopback)', onC !== null, onC === null ? `timed out; log: ${C.log().slice(-800)}` : `${onC} ms after ready`);
  // the child's stdout reaches this process asynchronously: allow the line a moment to arrive
  for (let i = 0; i < 20 && !/live snapshot differs/.test(C.log()); i++) await sleep(250);
  check('replica C booted into a differing snapshot, so it revalidated everything', /live snapshot differs/.test(C.log()), C.log().slice(-600));

  redis.disconnect();
  await mini?.close();
}

try {
  await main();
} catch (e) {
  check('check script ran to completion', false, (e as Error).message);
} finally {
  for (const c of children) c.kill();
  await sleep(500);
  for (const d of dirs) rmSync(d, { recursive: true, force: true });
}
const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
process.exit(failed.length ? 1 : 0);
