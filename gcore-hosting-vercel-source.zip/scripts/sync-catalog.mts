// Runs one catalog sync against the live sources and publishes to the configured store
// (Redis when REDIS_URL is set, otherwise .cache/catalog.json for local development).
//
//   npm run catalog:sync            incremental
//   npm run catalog:sync -- --force refetch all BILLmanager detail
import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { log } from '../src/lib/log';
import { catalogId } from '../src/lib/catalog/model';
import { FileStore, getStore } from '../src/lib/catalog/store';
import { runSync, syncConfigFromEnv } from '../src/lib/catalog/sync';

const force = process.argv.includes('--force');
// --file: always write .cache/catalog.json (used by `prebuild`, so a build never touches Redis)
const fileMode = process.argv.includes('--file');
const store = fileMode ? new FileStore() : getStore();
const outcome = await runSync(store, syncConfigFromEnv(log), { force });

if (fileMode && outcome.status !== 'failed' && outcome.status !== 'rejected') {
  // Records which snapshot the coming build renders its pages from (next.config.ts embeds it); a replica compares
  // it with the live snapshot at boot and revalidates everything when they differ.
  const live = await store.getLive();
  if (live) await writeFile(path.join(process.cwd(), '.cache', 'build-info.json'), JSON.stringify({ catalogId: catalogId(live) }));
}
const summary =
  outcome.status === 'published'
    ? {
        status: outcome.status,
        version: outcome.catalog.version,
        stats: outcome.catalog.stats,
        diff: {
          added: outcome.diff.added.length,
          removed: outcome.diff.removed.length,
          changed: outcome.diff.changed.length,
        },
        tagCount: outcome.tags.length,
      }
    : outcome;
console.log(JSON.stringify(summary, null, 2));
process.exit(outcome.status === 'failed' || outcome.status === 'rejected' ? 1 : 0);
