// Captures REAL upstream responses into tests/fixtures. Tests run against these recordings;
// no invented data is used anywhere. Re-run to refresh, then review the diff in the contract tests.
//
//   npm run fixtures:capture
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const CALC = process.env.CALC_API_BASE_URL ?? 'https://hosting-calc-prod.i.gc.onl';
const BM = process.env.BILLMANAGER_BASE_URL ?? 'https://hosting.gcore.com';
const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'tests', 'fixtures');

// Plans chosen to cover: VPS standard + HIGHCPU, tiny VPS (no os_price), dedicated with GPU,
// dedicated with 2x10GbE, and the dedicated plan with an inconsistent quarterly price.
const S2_OK = ['170193', '173283', '170158', '145809', '125840', '176811'];
// USD plan that anonymous pricelist.export rejects.
const S2_HIDDEN = '123762';

async function get(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(60_000) });
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return { text: await res.text(), contentType: res.headers.get('content-type') };
}

const pl = (ids) => `${BM}/billmgr?func=pricelist.export&out=json&pricelist=${ids}`;
const manifest = { capturedAt: new Date().toISOString(), files: {} };

async function save(name, url) {
  const { text, contentType } = await get(url);
  JSON.parse(text); // must be JSON, whatever the content type says
  await writeFile(path.join(dir, name), text);
  manifest.files[name] = { url: url.replace(/\?.*$/, '?…'), contentType, bytes: text.length };
  console.log('saved', name, text.length);
}

await mkdir(dir, { recursive: true });
await save('calc-vps.json', `${CALC}/vps/?format=json`);
await save('calc-dedicated.json', `${CALC}/dedicated_servers/?format=json`);
for (const id of S2_OK) await save(`s2-${id}.json`, pl(id));
await save(`s2-hidden-${S2_HIDDEN}.json`, pl(S2_HIDDEN));
await save('s2-mixed-batch-error.json', pl(`170193,${S2_HIDDEN},170158`));
await writeFile(path.join(dir, 'MANIFEST.json'), JSON.stringify(manifest, null, 2));
