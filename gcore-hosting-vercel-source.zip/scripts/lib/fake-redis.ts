import type { Redis } from 'ioredis';

/**
 * An in-memory stand-in for the subset of Redis commands this project uses (strings with EX/PX/NX, INCR,
 * EXPIRE/PEXPIRE/TTL, the lock-release script, streams). It lets the Redis-backed classes run in unit tests.
 *
 * It is NOT Redis: it encodes our reading of the command semantics. Passing against it proves the call
 * sequence and the logic around it, not that a real server agrees. Real-server verification is in the
 * launch checklist (docs/LAUNCH.md).
 */
export class FakeRedis {
  private strings = new Map<string, { value: string; expiresAt?: number }>();
  private streams = new Map<string, { entries: Array<[string, string[]]>; seq: number; expiresAt?: number }>();
  readonly commands: string[] = [];
  /** Tests flip this to simulate an outage: every command rejects. */
  down = false;

  constructor(private readonly now: () => number = Date.now) {}

  private enter(name: string, ...args: unknown[]) {
    if (this.down) throw new Error('ECONNREFUSED');
    this.commands.push([name, ...args.map(String)].join(' '));
  }

  private live(key: string) {
    const e = this.strings.get(key);
    if (e?.expiresAt !== undefined && e.expiresAt <= this.now()) {
      this.strings.delete(key);
      return undefined;
    }
    return e;
  }

  async get(key: string) {
    this.enter('get', key);
    return this.live(key)?.value ?? null;
  }

  async set(key: string, value: string, ...opts: Array<string | number>) {
    this.enter('set', key, '…', ...opts);
    let expiresAt: number | undefined;
    let nx = false;
    for (let i = 0; i < opts.length; i++) {
      const o = String(opts[i]).toUpperCase();
      if (o === 'EX') expiresAt = this.now() + Number(opts[++i]) * 1000;
      else if (o === 'PX') expiresAt = this.now() + Number(opts[++i]);
      else if (o === 'NX') nx = true;
      else throw new Error(`ERR syntax error (unsupported SET option ${o})`);
    }
    if (nx && this.live(key)) return null;
    this.strings.set(key, { value: String(value), expiresAt });
    return 'OK';
  }

  async del(key: string) {
    this.enter('del', key);
    return this.strings.delete(key) ? 1 : 0;
  }

  async incr(key: string) {
    this.enter('incr', key);
    const cur = Number(this.live(key)?.value ?? 0) + 1;
    this.strings.set(key, { value: String(cur), expiresAt: this.live(key)?.expiresAt });
    return cur;
  }

  async expire(key: string, seconds: number) {
    this.enter('expire', key, seconds);
    return this.pexpire(key, seconds * 1000, true);
  }

  async pexpire(key: string, ms: number, quiet = false) {
    if (!quiet) this.enter('pexpire', key, ms);
    const s = this.live(key);
    if (s) {
      s.expiresAt = this.now() + ms;
      return 1;
    }
    const st = this.streams.get(key);
    if (st) {
      st.expiresAt = this.now() + ms;
      return 1;
    }
    return 0;
  }

  async ttl(key: string) {
    this.enter('ttl', key);
    const e = this.live(key);
    if (!e) return -2;
    return e.expiresAt === undefined ? -1 : Math.ceil((e.expiresAt - this.now()) / 1000);
  }

  /** Only the lock-release script the store uses: delete the key when it holds the given token. */
  async eval(script: string, numKeys: number, ...args: string[]) {
    this.enter('eval', '<script>', numKeys, ...args);
    if (!/redis\.call\('get', KEYS\[1\]\) == ARGV\[1\]/.test(script)) throw new Error('FakeRedis: unsupported script');
    const [key, token] = args as [string, string];
    if (this.live(key)?.value === token) return this.strings.delete(key) ? 1 : 0;
    return 0;
  }

  /** XADD key [MAXLEN [~] n] * field value ... — only auto ids. */
  async xadd(key: string, ...args: Array<string | number>) {
    this.enter('xadd', key, ...args);
    let i = 0;
    let maxlen: number | undefined;
    if (String(args[i]).toUpperCase() === 'MAXLEN') {
      i++;
      if (args[i] === '~' || args[i] === '=') i++;
      maxlen = Number(args[i++]);
    }
    if (args[i++] !== '*') throw new Error('FakeRedis: only auto-generated ids are supported');
    const fields = args.slice(i).map(String);
    if (fields.length === 0 || fields.length % 2 !== 0) throw new Error("ERR wrong number of arguments for 'xadd' command");
    const s = this.streams.get(key) ?? { entries: [], seq: 0 };
    s.seq++;
    const id = `${this.now()}-${s.seq}`;
    s.entries.push([id, fields]);
    if (maxlen !== undefined) while (s.entries.length > maxlen) s.entries.shift();
    this.streams.set(key, s);
    return id;
  }

  /** XREVRANGE key + - COUNT n */
  async xrevrange(key: string, end: string, start: string, ...rest: Array<string | number>) {
    this.enter('xrevrange', key, end, start, ...rest);
    if (end !== '+' || start !== '-') throw new Error('FakeRedis: only the full range is supported');
    const count = String(rest[0]).toUpperCase() === 'COUNT' ? Number(rest[1]) : Infinity;
    return [...(this.stream(key)?.entries ?? [])].reverse().slice(0, count);
  }

  /** XREAD COUNT n STREAMS key id — non-blocking; returns entries with an id greater than `id`, or null. */
  async xread(...args: Array<string | number>) {
    this.enter('xread', ...args);
    let count = Infinity;
    let i = 0;
    if (String(args[i]).toUpperCase() === 'COUNT') {
      count = Number(args[i + 1]);
      i += 2;
    }
    if (String(args[i++]).toUpperCase() !== 'STREAMS') throw new Error('ERR syntax error');
    const [key, id] = [String(args[i]), String(args[i + 1])];
    const after = parseId(id);
    const found = (this.stream(key)?.entries ?? []).filter(([eid]) => compareId(parseId(eid), after) > 0).slice(0, count);
    return found.length ? [[key, found]] : null;
  }

  private stream(key: string) {
    const s = this.streams.get(key);
    if (s?.expiresAt !== undefined && s.expiresAt <= this.now()) {
      this.streams.delete(key);
      return undefined;
    }
    return s;
  }

  /** The class under test types its dependency as ioredis' Redis. */
  asRedis(): Redis {
    return this as unknown as Redis;
  }
}

function parseId(id: string): [number, number] {
  const [ms = '0', seq = '0'] = id.split('-');
  return [Number(ms), Number(seq)];
}
function compareId(a: [number, number], b: [number, number]) {
  return a[0] - b[0] || a[1] - b[1];
}
