// Prints a data-quality report for the live catalog snapshot: what BILLmanager data needs attention.
//
//   npm run catalog:report
import { getStore } from '../src/lib/catalog/store';

const store = getStore();
const [catalog, meta] = await Promise.all([store.getLive(), store.getMeta()]);
if (!catalog) {
  console.error('No catalog snapshot yet. Run: npm run catalog:sync');
  process.exit(1);
}

console.log(`Snapshot v${catalog.version}, generated ${catalog.generatedAt}`);
console.log(`Last check: ${meta?.lastCheckedAt ?? '-'}${meta?.lastError ? `  LAST ERROR: ${meta.lastError.message}` : ''}`);
console.log(JSON.stringify(catalog.stats));
console.log(`Locations: ${catalog.locations.length}\n`);

const byCode = new Map<string, { severity: string; plans: string[] }>();
for (const p of catalog.plans) {
  for (const f of p.flags) {
    const e = byCode.get(f.code) ?? { severity: f.severity, plans: [] };
    e.plans.push(`${p.id} ${p.name} [${p.currency}]${f.severity !== 'info' ? ` - ${f.message}` : ''}`);
    byCode.set(f.code, e);
  }
}
const order = { error: 0, warn: 1, info: 2 } as Record<string, number>;
for (const [code, e] of [...byCode.entries()].sort((a, b) => (order[a[1].severity] ?? 9) - (order[b[1].severity] ?? 9))) {
  console.log(`[${e.severity.toUpperCase()}] ${code}: ${e.plans.length} plan(s)`);
  for (const line of e.plans.slice(0, e.severity === 'info' ? 3 : 12)) console.log(`    ${line}`);
  if (e.plans.length > 12 || (e.severity === 'info' && e.plans.length > 3)) console.log('    ...');
}
