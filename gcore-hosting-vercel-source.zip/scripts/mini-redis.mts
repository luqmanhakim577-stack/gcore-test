// A small in-memory Redis for local multi-replica checks (no Redis or Docker needed):
//
//   npx tsx scripts/mini-redis.mts [port]
//
// It speaks the Redis wire protocol (RESP2) for exactly the commands this project uses, backed by the same
// FakeRedis the unit tests use. It is NOT Redis. Use it to exercise the replica logic end to end; verify
// against a real server with `REDIS_URL=redis://... npm run check:replicas`.
import net from 'node:net';
import { FakeRedis } from './lib/fake-redis.ts';

/** `{ simple }` is a RESP simple string (+OK); a plain string is a bulk string. */
type Reply = string | number | null | { simple: string } | Reply[];

const enc = (r: Reply): string => {
  if (r === null) return '$-1\r\n';
  if (typeof r === 'number') return `:${r}\r\n`;
  if (typeof r === 'string') return `$${Buffer.byteLength(r)}\r\n${r}\r\n`;
  if (!Array.isArray(r)) return `+${r.simple}\r\n`;
  return `*${r.length}\r\n${r.map(enc).join('')}`;
};

/** Incremental RESP array parser: returns the commands completed so far and the unparsed rest. */
function parse(buf: Buffer): { commands: string[][]; rest: Buffer } {
  const commands: string[][] = [];
  let pos = 0;
  outer: while (pos < buf.length) {
    if (buf[pos] !== 0x2a /* * */) throw new Error('inline commands are not supported');
    const lineEnd = buf.indexOf('\r\n', pos);
    if (lineEnd < 0) break;
    const n = Number(buf.toString('utf8', pos + 1, lineEnd));
    let p = lineEnd + 2;
    const args: string[] = [];
    for (let i = 0; i < n; i++) {
      const e = buf.indexOf('\r\n', p);
      if (e < 0) break outer;
      const len = Number(buf.toString('utf8', p + 1, e));
      if (buf.length < e + 2 + len + 2) break outer;
      args.push(buf.toString('utf8', e + 2, e + 2 + len));
      p = e + 2 + len + 2;
    }
    commands.push(args);
    pos = p;
  }
  return { commands, rest: buf.subarray(pos) };
}

export function startMiniRedis(port = 0): Promise<{ port: number; url: string; close: () => Promise<void> }> {
  const redis = new FakeRedis();
  const sockets = new Set<net.Socket>();

  async function run(args: string[]): Promise<Reply> {
    const [cmd = '', ...a] = args;
    const name = cmd.toLowerCase();
    switch (name) {
      case 'ping': return { simple: 'PONG' };
      case 'info': return '# Server\r\nredis_version:7.2.0\r\nloading:0\r\n';
      case 'client': case 'select': case 'quit': return { simple: 'OK' };
      case 'get': return redis.get(a[0]!);
      case 'set': return (await redis.set(a[0]!, a[1]!, ...a.slice(2))) === 'OK' ? { simple: 'OK' } : null;
      case 'del': return redis.del(a[0]!);
      case 'incr': return redis.incr(a[0]!);
      case 'expire': return redis.expire(a[0]!, Number(a[1]));
      case 'pexpire': return redis.pexpire(a[0]!, Number(a[1]));
      case 'ttl': return redis.ttl(a[0]!);
      case 'eval': return redis.eval(a[0]!, Number(a[1]), ...a.slice(2));
      case 'xadd': return redis.xadd(a[0]!, ...a.slice(1));
      case 'xrevrange': return redis.xrevrange(a[0]!, a[1]!, a[2]!, ...a.slice(3)) as unknown as Reply;
      case 'xread': return (await redis.xread(...a)) as unknown as Reply;
      default: throw new Error(`unknown command '${cmd}'`);
    }
  }

  const server = net.createServer((socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
    socket.on('error', () => undefined);
    let pending: Buffer = Buffer.alloc(0);
    let chain: Promise<void> = Promise.resolve();
    socket.on('data', (chunk: Buffer) => {
      const { commands, rest } = parse(Buffer.concat([pending, chunk]));
      pending = Buffer.from(rest);
      for (const c of commands) {
        // replies must keep the order of the commands
        chain = chain.then(async () => {
          let out: string;
          try {
            out = enc(await run(c));
          } catch (e) {
            out = `-ERR ${(e as Error).message}\r\n`;
          }
          socket.write(out);
        });
      }
    });
  });

  return new Promise((resolve) => {
    server.listen(port, '127.0.0.1', () => {
      const p = (server.address() as net.AddressInfo).port;
      resolve({
        port: p,
        url: `redis://127.0.0.1:${p}`,
        close: () => new Promise((done) => { for (const s of sockets) s.destroy(); server.close(() => done()); }),
      });
    });
  });
}

if (process.argv[1]?.endsWith('mini-redis.mts')) {
  const { url } = await startMiniRedis(Number(process.argv[2] ?? 6390));
  console.log(`mini-redis listening on ${url} (a stand-in, not Redis)`);
}
