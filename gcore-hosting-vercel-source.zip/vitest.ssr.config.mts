import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

// Tests of build artifacts. Run after `npm run build`.
export default defineConfig({
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  oxc: { jsx: { runtime: 'automatic' } },
  test: { environment: 'node', include: ['tests/ssr/**/*.test.ts'] },
});
