import type { MetadataRoute } from 'next';
import { getSitemapEntries } from '@/lib/catalog/page-data';
import { absoluteUrl, LOCALES } from '@/lib/seo/config';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)

/**
 * One sitemap (about 400 URLs, far below the 50,000 limit). Revalidated with the `catalog` tag,
 * so it updates when a sync changes any plan. hreflang alternates mirror the page-level ones.
 */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const entries = await getSitemapEntries();
  return entries.map((e) => {
    const url = absoluteUrl(e.path);
    return {
      url,
      lastModified: e.lastModified,
      alternates: { languages: Object.fromEntries(LOCALES.map((l) => [l, url])) },
    };
  });
}
