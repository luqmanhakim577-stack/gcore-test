import Link from 'next/link';
import type { Metadata } from 'next';
import { ToneHeading } from '@/components/layout';
import { NAV } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Page not found',
  robots: { index: false, follow: true },
};

export default function NotFound() {
  return (
    <main id="main" className="mx-auto max-w-3xl px-4 py-20">
      <ToneHeading as="h1" lead="Page" tone="not found" />
      <p className="mt-4 text-lg text-muted">This page does not exist, or the plan is no longer offered. Try one of these:</p>
      <ul className="mt-8 flex flex-wrap gap-3">
        {NAV.map((n) => (
          <li key={n.href}>
            <Link href={n.href} className="btn-outline">
              {n.label}
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
