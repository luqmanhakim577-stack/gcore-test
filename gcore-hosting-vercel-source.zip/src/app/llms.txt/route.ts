import { getLlmsTxt } from '@/lib/catalog/page-data';
import { textResponse } from '@/lib/aeo/respond';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)

export async function GET() {
  return textResponse(await getLlmsTxt());
}
