import { kindRoutes } from '@/components/kind-routes';

const r = kindRoutes('dedicated');
export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)
export const generateStaticParams = r.locationParams;
export const generateMetadata = r.locationMetadata;
export default r.Location;
