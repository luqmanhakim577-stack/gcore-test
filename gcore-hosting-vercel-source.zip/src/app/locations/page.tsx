import { LocationsIndexPage, locationsIndexMetadata } from '@/components/pages';
import { getLocationsIndex } from '@/lib/catalog/page-data';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)

export async function generateMetadata() {
  return locationsIndexMetadata((await getLocationsIndex()).locations.length);
}

export default async function Page() {
  return <LocationsIndexPage v={await getLocationsIndex()} />;
}
