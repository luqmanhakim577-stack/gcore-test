import { notFound } from 'next/navigation';
import { LocationDetailPage, locationDetailMetadata } from '@/components/pages';
import { getLocationDetail, getStaticParams } from '@/lib/catalog/page-data';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)

type Props = { params: Promise<{ slug: string }> };

const valid = async (p: Props['params']) => {
  const { slug } = await p;
  if (!/^[a-z0-9-]{1,60}$/.test(slug)) notFound();
  return slug;
};

export async function generateStaticParams() {
  return (await getStaticParams()).locationSlugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props) {
  return locationDetailMetadata(await getLocationDetail(await valid(params)));
}

export default async function Page({ params }: Props) {
  return <LocationDetailPage v={await getLocationDetail(await valid(params))} />;
}
