import type { Metadata, Viewport } from 'next';
import { preload } from 'react-dom';
import { JsonLd, SiteFooter, SiteHeader } from '@/components/layout';
import { organizationLd, websiteLd } from '@/lib/seo/jsonld';
import { SITE_NAME } from '@/lib/site';
import './globals.css';

/** Montserrat, the gcore.hosting typeface: self-hosted (OFL, licence beside it), declared in globals.css. */
const FONT_URL = '/fonts/montserrat-latin-wght-v5.3.0.woff2';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.SITE_URL || 'https://gcore.hosting'),
  title: { default: SITE_NAME, template: `%s | ${SITE_NAME}` },
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#1e1224' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Fetched with the HTML, so with font-display "optional" the brand face is normally ready for the first render.
  preload(FONT_URL, { as: 'font', type: 'font/woff2', crossOrigin: 'anonymous' });
  return (
    <html lang="en">
      <body className="min-h-screen font-sans antialiased">
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-30 focus:rounded focus:bg-white focus:px-3 focus:py-2 focus:text-night-deep">
          Skip to content
        </a>
        <JsonLd data={organizationLd()} />
        <JsonLd data={websiteLd()} />
        <SiteHeader />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
