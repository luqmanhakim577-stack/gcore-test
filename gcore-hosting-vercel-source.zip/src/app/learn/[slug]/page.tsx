import { notFound } from 'next/navigation';
import { ArticlePage, articleMetadata } from '@/components/learn';
import { LEARN, LEARN_BY_SLUG } from '@/content/learn';
import { getCatalogFacts } from '@/lib/catalog/page-data';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)
export const dynamicParams = false;

export const generateStaticParams = () => LEARN.map((a) => ({ slug: a.slug }));

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  return articleMetadata((await params).slug);
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const article = LEARN_BY_SLUG.get((await params).slug);
  if (!article) notFound();
  return <ArticlePage article={article} facts={await getCatalogFacts()} />;
}
