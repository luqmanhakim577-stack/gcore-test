import { LearnIndexPage, learnIndexMetadata } from '@/components/learn';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)
export const generateMetadata = learnIndexMetadata;
export default LearnIndexPage;
