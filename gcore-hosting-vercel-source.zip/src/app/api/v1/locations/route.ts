import { handleLocations } from '@/lib/api/catalog-handlers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export function GET(request: Request) {
  return handleLocations(request);
}
