import { json, PUBLIC_CACHE } from '@/lib/api/http';
import { buildOpenApi } from '@/lib/api/openapi';

export const runtime = 'nodejs';
export const dynamic = 'force-static';

/** The API description depends on code and SITE_URL only, never on the catalog, so it is built once. */
export function GET() {
  return json(buildOpenApi(), { headers: { 'cache-control': PUBLIC_CACHE } });
}
