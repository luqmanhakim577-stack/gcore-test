import { handlePlans } from '@/lib/api/catalog-handlers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic'; // freshness comes from the snapshot + ETag, not the route cache

export function GET(request: Request) {
  return handlePlans(request);
}
