import { handleHealth } from '@/lib/api/internal-handlers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export function GET() {
  return handleHealth();
}
