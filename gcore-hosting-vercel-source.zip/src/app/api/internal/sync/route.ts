import { handleSync } from '@/lib/api/internal-handlers';
import { applyInRequest, revalidateFleet } from '@/lib/cache/request';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export function POST(request: Request) {
  return handleSync(request, { revalidate: revalidateFleet, revalidateLocal: applyInRequest });
}
