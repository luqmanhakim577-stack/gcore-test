import { HomePage, homeMetadata } from '@/components/pages';
import { getHome } from '@/lib/catalog/page-data';

export const revalidate = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)

export async function generateMetadata() {
  return homeMetadata(await getHome());
}

export default async function Page() {
  return <HomePage v={await getHome()} />;
}
