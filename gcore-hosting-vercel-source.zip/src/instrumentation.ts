// Node-only code lives in instrumentation-node.ts so the edge compilation of this file never
// tries to bundle ioredis/pino (Next compiles instrumentation for both runtimes).
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    // Not during `next build`, which has no Redis and no runtime secrets.
    if (process.env.NODE_ENV === 'production' && process.env.NEXT_PHASE !== 'phase-production-build') {
      const { assertProductionConfig } = await import('./lib/env');
      assertProductionConfig();
    }
    const { startScheduler } = await import('./instrumentation-node');
    startScheduler();
  }
}
