import Link from 'next/link';
import type { ConfigModel } from '@/lib/catalog/configurator';
import type { Plan, ProductKind } from '@/lib/catalog/model';
import { PERIODS, savingPercent, type PeriodKey } from '@/lib/catalog/money';
import { planPath } from '@/lib/catalog/views';
import {
  baseName,
  formatCpu,
  formatDisks,
  formatMoney,
  formatPort,
  formatRam,
  formatTraffic,
  PERIOD_LABEL,
  PERIOD_UNIT,
  specRows,
  withheldSpecs,
} from '@/lib/format';

/**
 * Billing period selector, styled as gcore.hosting's text tabs. Pure HTML + CSS (see globals.css): all periods are
 * rendered, the radios only choose which is visible. Place inside an element with className "period-root".
 */
export function PeriodSelector() {
  return (
    <fieldset className="period-selector">
      <legend className="mb-1 text-sm font-medium text-muted">Billing period</legend>
      <div className="flex flex-wrap items-center">
        {PERIODS.map((p) => (
          <span key={p} className="contents">
            <input type="radio" name="period" id={`period-${p}`} value={p} defaultChecked={p === 'monthly'} className="sr-only" />
            <label htmlFor={`period-${p}`} className={`period-tab${p === 'monthly' ? '' : ' period-sep'}`}>
              {PERIOD_LABEL[p]}
            </label>
          </span>
        ))}
      </div>
    </fieldset>
  );
}

function Saving({ plan, period }: { plan: Plan; period: PeriodKey }) {
  if (period === 'monthly') return null;
  const pct = savingPercent(plan.prices.monthly, plan.prices[period], period);
  return pct > 0 ? <span className="ml-1 text-xs font-semibold text-brand">−{pct}%</span> : null;
}

/** The price for every period; CSS shows the selected one. */
export function PriceCell({ plan }: { plan: Plan }) {
  return (
    <>
      {PERIODS.map((p) => (
        <div key={p} data-period={p}>
          <span className="whitespace-nowrap text-lg font-extrabold text-white">{formatMoney(plan.prices[p])}</span>{' '}
          <span className="text-xs text-muted">{PERIOD_UNIT[p]}</span>
          <Saving plan={plan} period={p} />
          {p !== 'monthly' && <div className="text-xs text-muted">≈ {formatMoney(plan.perMonthEquiv[p])} per month</div>}
        </div>
      ))}
    </>
  );
}

export function OrderButtons({ plan, label = 'Order' }: { plan: Plan; label?: string }) {
  return (
    <>
      {PERIODS.map((p) => {
        const href = plan.order.byPeriod[p];
        return href ? (
          <a key={p} data-period={p} href={href} rel="noopener" className="btn w-full md:w-auto">
            {label}
            <span className="sr-only"> {plan.name}, billed every {PERIOD_LABEL[p]}</span>
          </a>
        ) : null;
      })}
    </>
  );
}

function Dash() {
  return (
    <span className="text-muted" title="Being verified">
      —
    </span>
  );
}

function speed(plan: Plan, hide: ReturnType<typeof withheldSpecs>) {
  const port = hide.has('port') ? undefined : formatPort(plan.specs.portMbps);
  const traffic = hide.has('traffic') ? undefined : formatTraffic(plan.specs.traffic);
  // One element, so the mobile card layout (a flex row per cell) keeps it together on the right.
  return port || traffic ? (
    <span>
      {port ?? '—'} port<span aria-hidden="true"> · </span>
      <span className="block md:inline">{traffic ?? '—'} traffic</span>
    </span>
  ) : (
    <Dash />
  );
}

/** Comparison table. A semantic <table>; below md every row renders as a plan card via CSS. */
export function PlansTable({ plans, kind, caption, showLocation = false, locationNames }: {
  plans: Plan[];
  kind: ProductKind;
  caption: string;
  showLocation?: boolean;
  locationNames?: Map<string, string>;
}) {
  return (
    <div className="period-root">
      <PeriodSelector />
      <table className="rtable dtable mt-4">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr>
            <th scope="col">Plan</th>
            {showLocation && <th scope="col">Location</th>}
            {kind === 'vps' ? (
              <>
                <th scope="col">vCPU</th>
                <th scope="col">RAM</th>
                <th scope="col">Disk</th>
              </>
            ) : (
              <>
                <th scope="col">RAM</th>
                <th scope="col">Storage</th>
                <th scope="col">Extras</th>
              </>
            )}
            <th scope="col">Network</th>
            <th scope="col">Price</th>
            <th scope="col"><span className="sr-only">Order</span></th>
          </tr>
        </thead>
        <tbody>
          {plans.map((plan) => {
            const hide = withheldSpecs(plan);
            const s = plan.specs;
            return (
              <tr key={plan.id}>
                <td data-label="Plan">
                  <Link href={planPath(plan)} className="pill hover:brightness-110">
                    {kind === 'vps' ? baseName(plan) : (formatCpu(s) ?? baseName(plan))}
                    {kind === 'dedicated' && <span className="sr-only"> ({baseName(plan)})</span>}
                  </Link>
                </td>
                {showLocation && <td data-label="Location">{locationNames?.get(plan.locationId) ?? plan.locationId}</td>}
                {kind === 'vps' ? (
                  <>
                    <td data-label="vCPU">{!hide.has('vcpu') && s.vcpu !== undefined ? s.vcpu : <Dash />}</td>
                    <td data-label="RAM">{(!hide.has('ram') && formatRam(s.ramMiB)) || <Dash />}</td>
                    <td data-label="Disk">{(!hide.has('disk') && formatDisks(s.disks)) || <Dash />}</td>
                  </>
                ) : (
                  <>
                    <td className="whitespace-nowrap" data-label="RAM">{(!hide.has('ram') && formatRam(s.ramMiB)) || <Dash />}</td>
                    <td data-label="Storage">{(!hide.has('disk') && formatDisks(s.disks)) || <Dash />}</td>
                    <td data-label="Extras">{[s.raid ? 'RAID' : null, s.gpu ? `GPU ${s.gpu}` : null].filter(Boolean).join(', ') || <Dash />}</td>
                  </>
                )}
                <td data-label="Network">{speed(plan, hide)}</td>
                <td data-label="Price"><PriceCell plan={plan} /></td>
                <td className="pt-3 md:pt-[0.875rem] md:text-right"><OrderButtons plan={plan} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Static, crawlable price list of the configurable options for every billing period, in plain HTML.
 * Mirrors what the configurator offers; both are built from the same ConfigModel.
 */
export function AddonPriceTable({ model }: { model: ConfigModel }) {
  const rows: Array<{ key: string; label: string; note: string; prices: Record<PeriodKey, string> }> = [
    ...model.quantities.map((c) => ({
      key: c.id,
      label: `Additional ${c.label}`,
      note: `${c.included} included, up to ${c.max} in total. Price for each additional one:`,
      prices: c.unitPrices,
    })),
    ...(model.traffic?.choices
      .filter((c) => c.id !== model.traffic!.defaultId)
      .map((c) => ({ key: c.id, label: c.label, note: 'Traffic option, in addition to the plan price:', prices: c.prices })) ?? []),
  ];
  if (rows.length === 0) return null;
  return (
    <div className="mt-10 max-w-4xl">
      <h3 className="text-lg font-bold text-white">Option prices by billing period</h3>
      <table className="rtable dtable mt-3">
        <caption className="sr-only">Prices of additional options for each billing period</caption>
        <thead>
          <tr>
            <th scope="col">Option</th>
            {PERIODS.map((p) => (
              <th key={p} scope="col">{PERIOD_LABEL[p]}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.key}>
              <th scope="row" className="font-semibold text-white">
                <span>
                  {r.label}
                  <span className="block text-xs font-normal text-muted">{r.note}</span>
                </span>
              </th>
              {PERIODS.map((p) => (
                <td key={p} data-label={PERIOD_LABEL[p]}>
                  {formatMoney({ amount: r.prices[p], currency: model.currency })}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function SpecList({ plan }: { plan: Plan }) {
  // Same source as the Product JSON-LD: what is shown is exactly what is marked up.
  return (
    <dl className="grid grid-cols-1 gap-x-10 sm:grid-cols-2">
      {specRows(plan).map((r) => (
        <div key={r.label} className="flex justify-between gap-4 border-b border-line py-3">
          <dt className="text-muted">{r.label}</dt>
          <dd className="text-right font-semibold text-white">{r.text}</dd>
        </div>
      ))}
    </dl>
  );
}
