import { notFound, permanentRedirect } from 'next/navigation';
import type { Metadata } from 'next';
import type { ProductKind } from '@/lib/catalog/model';
import { getHub, getKindLocation, getPlan, getStaticParams } from '@/lib/catalog/page-data';
import { parsePlanParam, planPath } from '@/lib/catalog/views';
import { getEnv } from '@/lib/env';
import { HubPage, KindLocationPage, PlanPage, hubMetadata, kindLocationMetadata, planMetadata } from './pages';

/**
 * Route implementations shared by /vps/** and /dedicated-servers/**. The route files stay one-liners
 * (Next needs literal `revalidate` exports there) and only bind the product kind.
 */
const SLUG = /^[a-z0-9-]{1,60}$/;

export function kindRoutes(kind: ProductKind) {
  type LocationParams = { params: Promise<{ location: string }> };
  type PlanParams = { params: Promise<{ location: string; plan: string }> };

  const validLocation = async (p: LocationParams['params']) => {
    const { location } = await p;
    if (!SLUG.test(location)) notFound();
    return location;
  };

  async function planFromParams(p: PlanParams['params']) {
    const { location, plan } = await p;
    const parsed = SLUG.test(location) ? parsePlanParam(plan) : null;
    if (!parsed) notFound();
    const view = await getPlan(kind, parsed.id);
    // One canonical URL per plan: wrong slug or location segment redirects (renames never 404).
    if (location !== view.plan.locationId || parsed.slug !== view.plan.slug) permanentRedirect(planPath(view.plan));
    return view;
  }

  return {
    hubMetadata: async (): Promise<Metadata> => hubMetadata(await getHub(kind)),
    Hub: async () => <HubPage v={await getHub(kind)} />,

    locationParams: async () => (await getStaticParams()).locations.filter((l) => l.kind === kind).map((l) => ({ location: l.location })),
    locationMetadata: async ({ params }: LocationParams): Promise<Metadata> =>
      kindLocationMetadata(await getKindLocation(kind, await validLocation(params))),
    Location: async ({ params }: LocationParams) => <KindLocationPage v={await getKindLocation(kind, await validLocation(params))} />,

    planParams: async () => (await getStaticParams()).plans.filter((p) => p.kind === kind).map((p) => ({ location: p.location, plan: p.plan })),
    planMetadata: async ({ params }: PlanParams): Promise<Metadata> => planMetadata(await planFromParams(params)),
    // ORDER_ADDON_PARAMS is read when the page is (re)generated; flip it, then revalidate the "catalog" tag.
    Plan: async ({ params }: PlanParams) => (
      <PlanPage v={await planFromParams(params)} addonParams={getEnv().ORDER_ADDON_PARAMS === 'on'} />
    ),
  };
}
