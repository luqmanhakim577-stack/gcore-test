'use client';

import { useId, useMemo, useState } from 'react';
import {
  buildOrderLink,
  defaultSelection,
  quote,
  type ConfigModel,
  type QuantityControl,
  type Selection,
} from '@/lib/catalog/configurator';
import { PERIODS, type Currency, type PeriodKey } from '@/lib/catalog/periods';
import { formatMoney, PERIOD_LABEL, PERIOD_UNIT } from '@/lib/format';

interface Props {
  planName: string;
  currency: Currency;
  /** The plan's own price per billing period (BILLmanager). */
  basePrices: Record<PeriodKey, string>;
  /** BILLmanager's validated order link per period. */
  links: Partial<Record<PeriodKey, string>>;
  model: ConfigModel;
  /** Pass the configuration to the order page (ORDER_ADDON_PARAMS=on). Off until verified with a real order. */
  addonParams: boolean;
}

const money = (amount: string, currency: Currency) => formatMoney({ amount, currency });

function quantityOptions(q: QuantityControl): number[] {
  const out: number[] = [];
  for (let n = q.included; n <= q.max; n += q.step) out.push(n);
  return out;
}

/**
 * Configurator. The first render (also the server-rendered HTML) is the default configuration:
 * monthly, nothing extra, the plan price as the total. JavaScript then recomputes the estimated total
 * and the order link with the same pure functions the server uses.
 */
export function Configurator({ planName, currency, basePrices, links, model, addonParams }: Props) {
  const uid = useId();
  const [period, setPeriod] = useState<PeriodKey>('monthly');
  const [sel, setSel] = useState<Selection>(() => defaultSelection(model));

  const q = useMemo(() => quote(model, basePrices[period], period, sel), [model, basePrices, period, sel]);
  const baseLink = links[period];
  const href = useMemo(() => (baseLink ? buildOrderLink(baseLink, model, sel, { params: addonParams }) : undefined), [baseLink, model, sel, addonParams]);
  const customised = q.lines.length > 0;

  return (
    <div className="panel">
      <fieldset>
        <legend className="mb-1 text-sm font-medium text-muted">Billing period</legend>
        <div className="flex flex-wrap items-center">
          {PERIODS.map((p, i) => (
            <label
              key={p}
              data-active={period === p}
              className={`period-tab${i > 0 ? ' period-sep' : ''} focus-within:rounded-md focus-within:outline focus-within:outline-3 focus-within:outline-brand-soft`}
            >
              <input type="radio" name={`${uid}-period`} className="sr-only" checked={period === p} onChange={() => setPeriod(p)} />
              {PERIOD_LABEL[p]}
            </label>
          ))}
        </div>
      </fieldset>

      {model.quantities.map((c) => (
        <div key={c.id} className="mt-6">
          <label htmlFor={`${uid}-q-${c.id}`} className="block text-sm font-semibold text-white">
            {c.label}
          </label>
          <select
            id={`${uid}-q-${c.id}`}
            className="mt-2 min-h-11 w-full max-w-xs rounded-[10px] border border-white/70 bg-night-deep px-3 text-sm font-semibold text-white"
            value={sel.quantities[c.id] ?? c.included}
            onChange={(e) => setSel({ ...sel, quantities: { ...sel.quantities, [c.id]: Number(e.target.value) } })}
          >
            {quantityOptions(c).map((n) => (
              <option key={n} value={n}>
                {n === c.included ? `${n} (included)` : `${n} (+${n - c.included} × ${money(c.unitPrices[period], currency)})`}
              </option>
            ))}
          </select>
          <p className="mt-2 text-xs text-muted">
            {c.included} included in the plan. Each additional one: {money(c.unitPrices[period], currency)} {PERIOD_UNIT[period]}.
          </p>
        </div>
      ))}

      {model.traffic && (
        <fieldset className="mt-6">
          <legend className="text-sm font-semibold text-white">Traffic option</legend>
          <div className="mt-2 space-y-2">
            {model.traffic.choices.map((c) => {
              const surcharge = c.prices[period];
              return (
                <label
                  key={c.id}
                  className="flex cursor-pointer items-start gap-3 rounded-[14px] border border-chip/50 p-3 text-sm has-[:checked]:border-brand-soft has-[:checked]:bg-brand/10 has-[:checked]:shadow-[0_12px_24px_-12px_rgb(255_76_0/0.15)]"
                >
                  <input
                    type="radio"
                    name={`${uid}-traffic`}
                    className="mt-1 accent-brand"
                    checked={(sel.traffic ?? model.traffic!.defaultId) === c.id}
                    onChange={() => setSel({ ...sel, traffic: c.id })}
                  />
                  <span>
                    <span className="block font-semibold text-white">{c.label}</span>
                    <span className="block text-xs text-muted">
                      {Number(surcharge) === 0 ? 'Included in the plan price' : `+${money(surcharge, currency)} ${PERIOD_UNIT[period]}`}
                    </span>
                  </span>
                </label>
              );
            })}
          </div>
        </fieldset>
      )}

      {model.fixedResources && (
        <p className="mt-6 text-sm text-muted">
          Disk, RAM and vCPU are part of the plan and cannot be changed separately. For more, choose a larger plan.
        </p>
      )}

      <div className="mt-6 border-t border-line pt-5" aria-live="polite">
        <dl className="space-y-1 text-sm">
          <div className="flex justify-between gap-4">
            <dt className="text-muted">{planName}</dt>
            <dd className="text-white">{money(q.base, currency)}</dd>
          </div>
          {q.lines.map((l) => (
            <div key={l.id} className="flex justify-between gap-4">
              <dt className="text-muted">
                {l.label} <span className="text-xs">({l.detail})</span>
              </dt>
              <dd className="text-white">{money(l.amount, currency)}</dd>
            </div>
          ))}
          <div className="price-box mt-3 flex flex-wrap items-baseline justify-between gap-x-4">
            <dt className="text-sm font-semibold">Estimated total, {PERIOD_UNIT[period]}</dt>
            <dd data-testid="total" className="price text-3xl">
              {money(q.total, currency)}
            </dd>
          </div>
        </dl>
        <p className="mt-2 text-xs text-muted">
          Calculated from the prices in our billing system. The order page shows the final amount.
        </p>
      </div>

      {customised && !addonParams && (
        <p className="glass mt-4 text-sm text-text" data-testid="manual-note">
          The order page opens with the plan only. Add the options above there:{' '}
          {q.lines.map((l) => `${l.label} (${l.detail})`).join('; ')}.
        </p>
      )}

      {href ? (
        <a
          href={href}
          rel="noopener"
          data-testid="order"
          className="btn mt-5 w-full"
        >
          Order {planName}
          <span className="sr-only">, billed every {PERIOD_LABEL[period]}</span>
        </a>
      ) : null}

      <noscript>
        <p className="mt-3 text-sm text-muted">Changing options needs JavaScript. The price table above has an order link for every billing period.</p>
      </noscript>
    </div>
  );
}
