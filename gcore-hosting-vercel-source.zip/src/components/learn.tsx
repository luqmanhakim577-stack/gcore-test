import Link from 'next/link';
import type { Metadata } from 'next';
import { GLOSSARY, LEARN, LEARN_BY_SLUG, LEARN_UPDATED, type Article } from '@/content/learn';
import { OWNER_FACTS } from '@/content/facts';
import type { CatalogFacts } from '@/lib/aeo/catalog-facts';
import { learnBlock } from '@/lib/aeo/learn-data';
import { formatDate } from '@/lib/format';
import { absoluteUrl } from '@/lib/seo/config';
import { definedTermSetLd, faqLd, itemListLd } from '@/lib/seo/jsonld';
import { pageMetadata } from '@/lib/seo/meta';
import { Breadcrumbs, JsonLd, ToneHeading } from './layout';

const Page = ({ children }: { children: React.ReactNode }) => (
  <main id="main" className="mx-auto max-w-3xl px-4 pt-8">
    {children}
  </main>
);
const H1 = ({ children }: { children: React.ReactNode }) => (
  <h1 className="mt-6 text-4xl font-bold leading-[1.15] tracking-tight text-white sm:text-[2.75rem]">{children}</h1>
);

const GENERAL_NOTE =
  'This is a general explanation of an industry concept. It is not a statement about the network, data centers, hardware, service levels or protection of any Gcore product.';

export const learnIndexMetadata = (): Metadata =>
  pageMetadata({
    pathname: '/learn',
    title: 'Hosting guides: VPS, dedicated servers, storage, traffic and DDoS explained',
    description: `${LEARN.length} short guides to the terms behind hosting plans, plus a glossary. General industry explanations, with the current catalog data next to them.`,
  });

export function LearnIndexPage() {
  return (
    <Page>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Guides', href: '/learn' }]} />
      <JsonLd data={itemListLd('Hosting guides', [...LEARN.map((a) => ({ name: a.title, href: `/learn/${a.slug}` })), { name: 'Hosting glossary', href: '/learn/glossary' }])} />
      <ToneHeading as="h1" className="mt-6" lead="Hosting" tone="guides" />
      <p className="mt-4 leading-relaxed text-muted">{GENERAL_NOTE}</p>
      <ul className="mt-10 space-y-4">
        {LEARN.map((a) => (
          <li key={a.slug} className="tile">
            <h2 className="text-lg font-bold">
              <Link href={`/learn/${a.slug}`} className="text-white hover:text-brand">
                {a.title}
              </Link>
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{a.summary}</p>
          </li>
        ))}
        <li className="tile">
          <h2 className="text-lg font-bold">
            <Link href="/learn/glossary" className="text-white hover:text-brand">
              Hosting glossary
            </Link>
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">{GLOSSARY.length} terms, from ASN and BGP to vCPU, defined in plain language.</p>
        </li>
      </ul>
    </Page>
  );
}

export function articleMetadata(slug: string): Metadata {
  const a = LEARN_BY_SLUG.get(slug);
  if (!a) return {};
  return pageMetadata({ pathname: `/learn/${a.slug}`, title: a.title, description: a.description });
}

export function ArticlePage({ article: a, facts }: { article: Article; facts: CatalogFacts }) {
  const block = learnBlock(a.slug, facts, OWNER_FACTS);
  const related = a.related.flatMap((s) => (LEARN_BY_SLUG.get(s) ? [LEARN_BY_SLUG.get(s)!] : []));
  return (
    <Page>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Guides', href: '/learn' }, { label: a.title, href: `/learn/${a.slug}` }]} />
      <JsonLd data={faqLd(a.qa)} />
      <article>
        <H1>{a.title}</H1>
        <p className="glass mt-6 text-lg leading-relaxed text-white">{a.summary}</p>
        <p className="mt-4 text-sm leading-relaxed text-muted">
          Last revised <time dateTime={a.updated}>{formatDate(a.updated)}</time>. {GENERAL_NOTE}
        </p>
        {a.sections.map((s) => (
          <section key={s.heading} className="mt-12">
            <h2 className="text-2xl font-bold tracking-tight text-white">{s.heading}</h2>
            {s.body.map((p) => (
              <p key={p} className="mt-4 leading-relaxed text-text">
                {p}
              </p>
            ))}
            {s.list && (
              <ul className="tri-list mt-4 space-y-2 leading-relaxed text-text">
                {s.list.map((li) => (
                  <li key={li}>{li}</li>
                ))}
              </ul>
            )}
          </section>
        ))}
        {block && (
          <aside className="panel mt-12" aria-labelledby="catalog-block">
            <h2 id="catalog-block" className="text-xl font-bold text-white">
              {block.heading}
            </h2>
            <ul className="tri-list mt-4 space-y-2 text-sm leading-relaxed text-text">
              {block.lines.map((l) => (
                <li key={l}>{l}</li>
              ))}
            </ul>
          </aside>
        )}
        <section className="mt-14" aria-labelledby="questions">
          <ToneHeading id="questions" lead="Questions" tone="and answers" />
          {/* Every answer stays visible: FAQPage markup is only emitted where the Q&A can be read without interaction. */}
          <div className="mt-6 space-y-3">
            {a.qa.map((x) => (
              <div key={x.q} className="qa">
                <h3 className="font-bold text-white">{x.q}</h3>
                <p className="mt-2 text-sm leading-relaxed text-text">{x.a}</p>
              </div>
            ))}
          </div>
        </section>
      </article>
      <nav aria-label="Related" className="mt-14 border-t border-line pt-8">
        <h2 className="text-lg font-bold text-white">Related</h2>
        <ul className="mt-3 space-y-1">
          {related.map((r) => (
            <li key={r.slug}>
              <Link href={`/learn/${r.slug}`} className="link inline-flex min-h-11 items-center md:min-h-0">
                {r.title}
              </Link>
            </li>
          ))}
          <li>
            <Link href="/learn/glossary" className="link inline-flex min-h-11 items-center md:min-h-0">
              Hosting glossary
            </Link>
          </li>
          <li>
            <Link href="/vps" className="link inline-flex min-h-11 items-center md:min-h-0">
              VPS plans and prices
            </Link>
          </li>
          <li>
            <Link href="/dedicated-servers" className="link inline-flex min-h-11 items-center md:min-h-0">
              Dedicated server plans and prices
            </Link>
          </li>
        </ul>
      </nav>
    </Page>
  );
}

export const glossaryMetadata = (): Metadata =>
  pageMetadata({
    pathname: '/learn/glossary',
    title: 'Hosting glossary: VPS, dedicated server, BGP, NVMe, unmetered and more',
    description: `${GLOSSARY.length} hosting and network terms defined in plain language. Industry-general definitions, not statements about Gcore infrastructure.`,
  });

export function GlossaryPage() {
  return (
    <Page>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Guides', href: '/learn' }, { label: 'Glossary', href: '/learn/glossary' }]} />
      <JsonLd data={definedTermSetLd('Hosting glossary', absoluteUrl('/learn/glossary'), GLOSSARY)} />
      <ToneHeading as="h1" className="mt-6" lead="Hosting" tone="glossary" />
      <p className="mt-4 leading-relaxed text-muted">
        Definitions are industry-general. A term defined here does not mean that Gcore offers the service; what is on offer is listed on the plan pages. Last revised{' '}
        <time dateTime={LEARN_UPDATED}>{formatDate(LEARN_UPDATED)}</time>.
      </p>
      <dl className="mt-10 divide-y divide-line">
        {GLOSSARY.map((t) => (
          <div key={t.term} className="py-5">
            <dt className="text-lg font-bold text-white">{t.term}</dt>
            <dd className="mt-2 leading-relaxed text-text">{t.definition}</dd>
          </div>
        ))}
      </dl>
    </Page>
  );
}
