import Link from 'next/link';
import type { Metadata } from 'next';
import type { Location, ProductKind } from '@/lib/catalog/model';
import { buildConfigModel } from '@/lib/catalog/configurator';
import { PERIODS, type PeriodKey } from '@/lib/catalog/periods';
import type { HomeView, HubView, LocationPageView, PlanPageView } from '@/lib/catalog/views';
import { DISPLAY_CURRENCY, locationPath, planPath } from '@/lib/catalog/views';
import { baseName, formatCpu, formatMoney, PERIOD_LABEL, PERIOD_UNIT, specSummary } from '@/lib/format';
import { KIND_BASE, KIND_LABEL, KIND_NOUN } from '@/lib/site';
import { savingPercent } from '@/lib/catalog/money';
import { itemListLd, productLd } from '@/lib/seo/jsonld';
import { pageMetadata } from '@/lib/seo/meta';
import { Breadcrumbs, JsonLd, PriceFootnote, ToneHeading } from './layout';
import { Configurator } from './configurator';
import { AddonPriceTable, PlansTable, SpecList } from './shop';

const placeName = (l: Location) => `${l.city}, ${l.country}`;
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

const Page = ({ children }: { children: React.ReactNode }) => (
  <main id="main" className="mx-auto max-w-[1224px] px-4 pt-8">
    {children}
  </main>
);
const Section = ({ children, className = '', label }: { children: React.ReactNode; className?: string; label?: string }) => (
  <section className={`mt-20 ${className}`} aria-labelledby={label}>
    {children}
  </section>
);
const Lede = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <p className={`mt-4 max-w-3xl text-lg leading-relaxed text-muted ${className}`}>{children}</p>
);
/** Link pill for "same thing elsewhere" lists: a 44 px touch target with the brand outline. */
const pillLink = 'inline-flex min-h-11 items-center gap-2 rounded-full border border-white/60 px-4 text-sm font-semibold text-white hover:border-brand hover:text-brand';

// ---------------------------------------------------------------- metadata (data-driven)

export function homeMetadata(v: HomeView): Metadata {
  return pageMetadata({
    pathname: '/',
    title: 'Gcore Hosting: VPS and dedicated servers',
    absoluteTitle: true,
    description: `VPS and dedicated servers in ${v.locations.length} locations${v.hubs.vps.from ? `, VPS from ${formatMoney(v.hubs.vps.from)} per month` : ''}. Compare plans and billing periods, then order online.`,
  });
}

export function hubMetadata(v: HubView): Metadata {
  const noun = KIND_NOUN[v.kind];
  return pageMetadata({
    pathname: KIND_BASE[v.kind],
    title: `${cap(noun)} in ${v.locations.length} locations${v.from ? `, from ${formatMoney(v.from)}/month` : ''}`,
    description: `${v.planCount} ${noun} plans across ${v.locations.length} locations. Compare vCPU/CPU, RAM, storage, port speed and traffic, and choose a billing period from 1 to 12 months.`,
  });
}

export function kindLocationMetadata(v: LocationPageView): Metadata {
  const noun = KIND_NOUN[v.kind];
  return pageMetadata({
    pathname: locationPath(v.kind, v.location.slug),
    title: `${cap(noun)} in ${v.location.city}, ${v.location.country}: from ${formatMoney(v.from)}/month`,
    description: `${v.plans.length} ${noun} plans in ${placeName(v.location)}. Compare specifications and prices for 1, 3, 6 and 12 month billing periods and order online.`,
  });
}

/** Shared by the meta description and the Product JSON-LD, so they say the same thing. */
export function planDescription(v: PlanPageView): string {
  const { plan, location } = v;
  const kindWord = plan.kind === 'vps' ? 'VPS' : 'Dedicated server';
  const summary = specSummary(plan);
  const cheaperLonger = v.orderable && savingPercent(plan.prices.monthly, plan.prices.annually, 'annually') > 0;
  return `${kindWord} ${baseName(plan)} in ${placeName(location)}${summary ? `: ${summary}` : ''}.${v.orderable ? ` ${formatMoney(plan.prices.monthly)} per month${cheaperLonger ? ', less per month on longer billing periods' : ''}.` : ''}`;
}

export function planMetadata(v: PlanPageView): Metadata {
  const { plan, location } = v;
  // BILLmanager's plan name is unique within a location, so titles and descriptions never collide.
  const kindWord = plan.kind === 'vps' ? 'VPS' : 'Dedicated server';
  return pageMetadata({
    pathname: planPath(plan),
    title: `${kindWord} ${baseName(plan)} in ${location.city}${v.orderable ? `: from ${formatMoney(plan.prices.monthly)}/month` : ''}`,
    description: planDescription(v),
    noindex: !v.orderable,
  });
}

// ---------------------------------------------------------------- shared widgets

const intro: Record<ProductKind, string> = {
  vps: 'A VPS is a virtual server that runs on shared physical hardware, with its own allocated vCPU, RAM and disk. It starts quickly and suits most websites, applications and development environments.',
  dedicated: 'A dedicated server is a whole physical machine reserved for you: all of its CPU, memory and disks, with no other tenants on the hardware. It suits workloads that need predictable performance or specific hardware.',
};

/** The gcore.hosting plan card used for a product: name pill, white price box, triangle bullets, gradient button. */
function ProductCard({ kind, planCount, locationCount, from, href, cta, children, heading: Heading = 'h3' }: {
  kind: ProductKind;
  planCount: number;
  locationCount?: number;
  from?: import('@/lib/catalog/money').Money | null;
  href: string;
  cta: string;
  children?: React.ReactNode;
  /** Keep the outline gap-free: h2 directly under a page's h1, h3 inside a section. */
  heading?: 'h2' | 'h3';
}) {
  return (
    <article className="plan-card">
      <Heading>
        <span className="pill">{KIND_LABEL[kind]}</span>
      </Heading>
      {from && (
        <p className="price-box flex flex-wrap items-baseline gap-x-2 text-sm text-ink-soft">
          from <strong className="price text-4xl sm:text-5xl">{formatMoney(from)}</strong> per month
        </p>
      )}
      <ul className="tri-list space-y-2 text-white">
        <li>{planCount} plans</li>
        {locationCount !== undefined && <li>{locationCount} locations</li>}
        <li>Billing for 1, 3, 6 or 12 months</li>
      </ul>
      {children}
      <Link href={href} className="btn mt-auto w-full">
        {cta}
      </Link>
    </article>
  );
}

function LocationTiles({ locations }: { locations: HomeView['locations'] }) {
  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {locations.map(({ location, kinds }) => (
        <li key={location.id} className="tile">
          <Link href={`/locations/${location.slug}`} className="text-lg font-bold text-white hover:text-brand">
            {location.city}
          </Link>
          <span className="text-muted">, {location.country}</span>
          <ul className="mt-3 space-y-1 text-sm">
            {kinds.map((k) => (
              <li key={k.kind}>
                <Link href={locationPath(k.kind, location.slug)} className="link">
                  {KIND_LABEL[k.kind]}
                </Link>{' '}
                <span className="text-muted">{k.planCount} plans from</span> <span className="font-semibold text-white">{formatMoney(k.from)}</span>
                <span className="text-muted">/month</span>
              </li>
            ))}
          </ul>
        </li>
      ))}
    </ul>
  );
}

// ---------------------------------------------------------------- pages

export function HomePage({ v }: { v: HomeView }) {
  const vps = v.hubs.vps;
  const ded = v.hubs.dedicated;
  return (
    <Page>
      <section className="grid items-center gap-10 py-6 lg:grid-cols-[1.2fr_0.8fr] lg:py-14">
        <div>
          <span className="badge">VPS and dedicated servers</span>
          <h1 className="mt-5 text-4xl font-bold leading-[1.1] tracking-tight text-white sm:text-[3.25rem]">
            Virtual and dedicated servers <span className="tone">in {v.locations.length} locations</span>
          </h1>
          <Lede>Compare plans and billing periods, see the price for 1, 3, 6 or 12 months, then order through Gcore&apos;s billing system.</Lede>
          {(vps.from || ded.from) && (
            // Stacked on phones, one row from sm up: decided by the breakpoint, never by text width, so the web font
            // arriving cannot rewrap it (that rewrap was a measured layout shift).
            <div className="glass mt-7 flex flex-col gap-3 sm:inline-flex sm:flex-row sm:items-stretch sm:gap-x-6">
              {vps.from && (
                <div>
                  <p className="text-sm text-text">VPS from</p>
                  <p className="text-4xl font-extrabold tracking-tight text-white">
                    {formatMoney(vps.from)}
                    <span className="ml-1 text-base font-bold">/mo</span>
                  </p>
                </div>
              )}
              {vps.from && ded.from && <div className="hidden w-px self-stretch bg-white/40 sm:block" aria-hidden="true" />}
              {ded.from && (
                <div>
                  <p className="text-sm text-text">Dedicated servers from</p>
                  <p className="text-4xl font-extrabold tracking-tight text-white">
                    {formatMoney(ded.from)}
                    <span className="ml-1 text-base font-bold">/mo</span>
                  </p>
                </div>
              )}
            </div>
          )}
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={KIND_BASE.vps} className="btn">
              View VPS plans
            </Link>
            <Link href={KIND_BASE.dedicated} className="btn-outline">
              View dedicated servers
            </Link>
          </div>
        </div>
        <div className="panel">
          <h2 className="text-xl font-bold text-white">
            The catalog <span className="tone">today</span>
          </h2>
          <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-7">
            <div className="stat">
              <dt className="sr-only">Locations</dt>
              <dd className="stat-num">{v.locations.length}</dd>
              <dd className="text-sm text-muted">locations</dd>
            </div>
            <div className="stat">
              <dt className="sr-only">VPS plans</dt>
              <dd className="stat-num">{vps.planCount}</dd>
              <dd className="text-sm text-muted">VPS plans</dd>
            </div>
            <div className="stat">
              <dt className="sr-only">Dedicated server plans</dt>
              <dd className="stat-num">{ded.planCount}</dd>
              <dd className="text-sm text-muted">dedicated server plans</dd>
            </div>
            <div className="stat">
              <dt className="sr-only">Billing periods</dt>
              <dd className="stat-num">
                1-12<small>months</small>
              </dd>
              <dd className="text-sm text-muted">billing periods</dd>
            </div>
          </dl>
        </div>
      </section>

      <Section className="text-center" label="products">
        <ToneHeading id="products" lead="Pick a" tone="server type" />
        <Lede className="mx-auto">Every plan lists its specifications and its price for each billing period, taken from our billing system.</Lede>
        <div className="mt-10 grid gap-6 text-left md:grid-cols-2">
          {(['vps', 'dedicated'] as const).map((kind) => {
            const hub = v.hubs[kind];
            return (
              <ProductCard key={kind} kind={kind} planCount={hub.planCount} locationCount={hub.locations.length} from={hub.from} href={KIND_BASE[kind]} cta={`View ${KIND_NOUN[kind]}`}>
                <p className="text-sm leading-relaxed text-muted">{intro[kind]}</p>
              </ProductCard>
            );
          })}
        </div>
      </Section>

      <Section label="locations">
        <div className="text-center">
          <ToneHeading id="locations" lead="Put your server in" tone="the right place" />
          <Lede className="mx-auto">Every location with plans you can order today.</Lede>
        </div>
        <div className="mt-10">
          <LocationTiles locations={v.locations} />
        </div>
        <PriceFootnote generatedAt={v.generatedAt} currency={DISPLAY_CURRENCY} />
      </Section>

      <Section className="cta-box px-6 py-14 text-center sm:px-12" label="ready">
        <ToneHeading id="ready" lead="Ready to bring your" tone="project online?" />
        <Lede className="mx-auto">Choose the server, resources and location that fit your workload.</Lede>
        <Link href={KIND_BASE.vps} className="btn mt-8 px-10 text-base">
          Choose your server
        </Link>
      </Section>
    </Page>
  );
}

export function HubPage({ v }: { v: HubView }) {
  const kind = v.kind;
  return (
    <Page>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: KIND_LABEL[kind], href: KIND_BASE[kind] }]} />
      <JsonLd data={itemListLd(`${KIND_LABEL[kind]} locations`, v.locations.map((l) => ({ name: placeName(l.location), href: locationPath(kind, l.location.slug) })))} />
      <div className="mt-6">
        <ToneHeading as="h1" lead={kind === 'vps' ? 'VPS hosting' : 'Dedicated servers'} tone={`in ${v.locations.length} locations`} />
        <Lede>{intro[kind]}</Lede>
        <p className="glass mt-6 inline-flex flex-wrap items-baseline gap-x-2 text-text">
          {v.planCount} plans{v.from && <>, from <strong className="text-2xl font-extrabold text-white">{formatMoney(v.from)}</strong> per month</>}.
        </p>
      </div>

      <Section label="choose">
        <ToneHeading id="choose" lead="Choose a" tone="location" />
        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {v.locations.map(({ location, planCount, from }) => (
            <li key={location.id} className="tile flex flex-col gap-3">
              <div>
                <Link href={locationPath(kind, location.slug)} className="text-lg font-bold text-white hover:text-brand">
                  {placeName(location)}
                </Link>
                {location.dcLabel && <span className="block text-sm text-muted">{location.dcLabel}</span>}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="chip">{planCount} plans</span>
                <span className="text-sm text-muted">
                  from <span className="text-lg font-extrabold text-white">{formatMoney(from)}</span> per month
                </span>
              </div>
            </li>
          ))}
        </ul>
        <PriceFootnote generatedAt={v.generatedAt} currency={DISPLAY_CURRENCY} />
      </Section>
    </Page>
  );
}

export function KindLocationPage({ v }: { v: LocationPageView }) {
  const { kind, location } = v;
  return (
    <Page>
      <Breadcrumbs
        items={[
          { label: 'Home', href: '/' },
          { label: KIND_LABEL[kind], href: KIND_BASE[kind] },
          { label: location.city, href: locationPath(kind, location.slug) },
        ]}
      />
      <JsonLd data={itemListLd(`${cap(KIND_NOUN[kind])} in ${placeName(location)}`, v.plans.map((p) => ({ name: `${baseName(p)} (${location.city})`, href: planPath(p) })))} />
      <div className="mt-6">
        <ToneHeading as="h1" lead={`${cap(KIND_NOUN[kind])} in`} tone={`${location.city}, ${location.country}`} />
        <Lede>
          {v.plans.length} plans, from <strong className="text-white">{formatMoney(v.from)}</strong> per month. Choose a billing period to
          see the price for 1, 3, 6 or 12 months.
          {location.dcLabel && <> Data center: {location.dcLabel}.</>}
        </Lede>
      </div>
      <div className="mt-10">
        <PlansTable plans={v.plans} kind={kind} caption={`${KIND_LABEL[kind]} plans in ${placeName(location)}`} />
      </div>
      <PriceFootnote generatedAt={v.generatedAt} currency={DISPLAY_CURRENCY} />

      {v.otherLocations.length > 0 && (
        <Section label="elsewhere">
          <ToneHeading id="elsewhere" lead={KIND_LABEL[kind]} tone="in other locations" />
          <ul className="mt-6 flex flex-wrap gap-3">
            {v.otherLocations.map((s) => (
              <li key={s.location.id}>
                <Link href={locationPath(kind, s.location.slug)} className={pillLink}>
                  {s.location.city}
                  <span className="font-medium text-muted">from {formatMoney(s.from)}</span>
                </Link>
              </li>
            ))}
          </ul>
        </Section>
      )}
    </Page>
  );
}

export function PlanPage({ v, addonParams = false }: { v: PlanPageView; addonParams?: boolean }) {
  const { plan, location } = v;
  // Only confirmed, orderable plans are configurable; everything else shows no price and no order controls.
  const config = v.orderable ? buildConfigModel(plan) : null;
  const kind = plan.kind;
  const title = kind === 'vps' ? baseName(plan) : (formatCpu(plan.specs) ?? baseName(plan));
  const summary = specSummary(plan);
  return (
    <Page>
      <Breadcrumbs
        items={[
          { label: 'Home', href: '/' },
          { label: KIND_LABEL[kind], href: KIND_BASE[kind] },
          { label: location.city, href: locationPath(kind, location.slug) },
          { label: title, href: planPath(plan) },
        ]}
      />
      {v.orderable && <JsonLd data={productLd(plan, location, planDescription(v))} />}
      <div className="mt-6">
        <span className="badge">{KIND_LABEL[kind]}</span>
        <ToneHeading as="h1" className="mt-4" lead={title} tone={`in ${location.city}`} />
        {summary && <p className="mt-4 text-xl font-semibold text-white">{summary}</p>}
        <p className="mt-2 text-sm text-muted">
          {placeName(location)}
          {location.dcLabel && ` (${location.dcLabel})`}. Plan ID: {plan.id}.
        </p>
      </div>

      <Section label="prices">
        <ToneHeading id="prices" lead="Price by" tone="billing period" />
        {v.orderable ? (
          <ul className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {PERIODS.map((p) => {
              const pct = p === 'monthly' ? 0 : savingPercent(plan.prices.monthly, plan.prices[p], p);
              const href = plan.order.byPeriod[p];
              return (
                <li key={p} className="plan-card">
                  <h3>
                    <span className="pill">{PERIOD_LABEL[p]}</span>
                  </h3>
                  <p className="price-box">
                    <strong className="price block text-4xl">{formatMoney(plan.prices[p])}</strong>
                    <span className="text-sm text-ink-soft">{PERIOD_UNIT[p]}</span>
                  </p>
                  <ul className="tri-list space-y-2 text-sm text-white">
                    <li>{formatMoney(plan.perMonthEquiv[p])} per month</li>
                    <li>{p === 'monthly' ? 'Paid month by month' : pct > 0 ? `${pct}% less than paying monthly` : 'Same as paying monthly'}</li>
                  </ul>
                  {href && (
                    <a href={href} rel="noopener" className="btn mt-auto w-full">
                      Order<span className="sr-only"> {title}, {PERIOD_LABEL[p]}</span>
                    </a>
                  )}
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="glass mt-6 max-w-2xl text-text">
            Online ordering for this configuration is currently unavailable while its pricing is being verified. Please check back later
            or choose another plan below.
          </p>
        )}
        {v.orderable && <PriceFootnote generatedAt={v.generatedAt} currency={DISPLAY_CURRENCY} />}
      </Section>

      {config && (
        <Section label="configure">
          <ToneHeading id="configure" lead="Configure" tone="and order" />
          <div className="mt-8 max-w-2xl">
            <Configurator
              planName={title}
              currency={plan.currency}
              basePrices={Object.fromEntries(PERIODS.map((p) => [p, plan.prices[p].amount])) as Record<PeriodKey, string>}
              links={plan.order.byPeriod}
              model={config}
              addonParams={addonParams}
            />
          </div>
          <AddonPriceTable model={config} />
        </Section>
      )}

      <Section label="specs">
        <ToneHeading id="specs" lead="Plan" tone="specifications" />
        <div className="panel mt-8 max-w-4xl">
          <SpecList plan={plan} />
        </div>
      </Section>

      {v.elsewhere.length > 0 && (
        <Section label="same-plan">
          <ToneHeading id="same-plan" lead="The same plan" tone="in other locations" />
          <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {v.elsewhere.map(({ plan: p, location: l }) => (
              <li key={p.id} className="tile">
                <Link href={planPath(p)} className="font-bold text-white hover:text-brand">
                  {placeName(l)}
                </Link>
                <div className="mt-1 text-sm text-muted">
                  <span className="font-semibold text-white">{formatMoney(p.prices.monthly)}</span> per month
                </div>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {v.siblingsHere.length > 0 && (
        <Section label="siblings">
          <ToneHeading id="siblings" lead={`Other ${KIND_NOUN[kind]}`} tone={`in ${location.city}`} />
          <div className="mt-8">
            <PlansTable plans={v.siblingsHere} kind={kind} caption={`Other ${KIND_NOUN[kind]} in ${placeName(location)}`} />
          </div>
        </Section>
      )}
      <p className="mt-12 text-sm">
        <Link href={locationPath(kind, location.slug)} className="link inline-flex min-h-11 items-center">
          ← All {KIND_NOUN[kind]} in {location.city}
        </Link>
      </p>
    </Page>
  );
}

export function LocationsIndexPage({ v }: { v: { locations: HomeView['locations']; generatedAt: string } }) {
  return (
    <Page>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Locations', href: '/locations' }]} />
      <JsonLd data={itemListLd('Hosting locations', v.locations.map((l) => ({ name: placeName(l.location), href: `/locations/${l.location.slug}` })))} />
      <div className="mt-6">
        <ToneHeading as="h1" lead="Hosting" tone="locations" />
        <Lede>{v.locations.length} locations with plans available to order today.</Lede>
      </div>
      <div className="mt-10">
        <LocationTiles locations={v.locations} />
      </div>
      <PriceFootnote generatedAt={v.generatedAt} currency={DISPLAY_CURRENCY} />
    </Page>
  );
}

export function LocationDetailPage({ v }: { v: { location: Location; kinds: HomeView['locations'][number]['kinds']; generatedAt: string } }) {
  const { location } = v;
  return (
    <Page>
      <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Locations', href: '/locations' }, { label: location.city, href: `/locations/${location.slug}` }]} />
      <div className="mt-6">
        <ToneHeading as="h1" lead="Hosting in" tone={`${location.city}, ${location.country}`} />
        <Lede>
          Data center: {location.city}
          {location.dcLabel ? ` (${location.dcLabel})` : ''}, {location.country}. Available here:
        </Lede>
      </div>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {v.kinds.map((k) => (
          <ProductCard key={k.kind} heading="h2" kind={k.kind} planCount={k.planCount} from={k.from} href={locationPath(k.kind, location.slug)} cta={`View ${KIND_NOUN[k.kind]} in ${location.city}`} />
        ))}
      </div>
      <PriceFootnote generatedAt={v.generatedAt} currency={DISPLAY_CURRENCY} />
    </Page>
  );
}

export function locationDetailMetadata(v: { location: Location; kinds: Array<{ kind: ProductKind; planCount: number; from: import('@/lib/catalog/money').Money }> }): Metadata {
  const { location } = v;
  return pageMetadata({
    pathname: `/locations/${location.slug}`,
    title: `Hosting in ${location.city}, ${location.country}`,
    description: `${v.kinds.map((k) => `${k.planCount} ${KIND_NOUN[k.kind]} plans from ${formatMoney(k.from)}/month`).join(' and ')} in ${placeName(location)}. Compare specifications and billing periods, then order online.`,
  });
}

export const locationsIndexMetadata = (count: number): Metadata =>
  pageMetadata({
    pathname: '/locations',
    title: `Hosting locations: ${count} data center locations`,
    description: `VPS and dedicated server locations with prices: ${count} locations.`,
  });
