import Link from 'next/link';
import { breadcrumbLd, serializeLd, type Crumb } from '@/lib/seo/jsonld';
import { MACHINE_LINKS, NAV } from '@/lib/site';
import { GcoreLogo } from './logo';

export type { Crumb };

/** Inline JSON-LD. The payload is escaped so it can never terminate the script element. */
export function JsonLd({ data }: { data: object | object[] }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: serializeLd(data) }} />;
}

/** The floating white bar of gcore.hosting: logo left, navigation right. */
export function SiteHeader() {
  return (
    <header className="z-20 px-3 pt-3 sm:sticky sm:top-0 sm:px-4">
      <div className="mx-auto flex max-w-[1224px] flex-wrap items-center justify-between gap-x-6 rounded-[10px] bg-white px-3 py-1 text-night-deep shadow-[0_16px_32px_-16px_rgb(21_12_24/0.1),0_2px_6px_-2px_rgb(21_12_24/0.04)] sm:px-8 lg:px-12">
        <Link href="/" className="inline-flex min-h-11 items-center">
          <GcoreLogo className="h-7 w-auto" />
          <span className="sr-only">Gcore Hosting, home</span>
        </Link>
        <nav aria-label="Main">
          <ul className="flex flex-wrap gap-x-3 text-[0.8125rem] font-semibold sm:gap-x-5 sm:text-sm">
            {NAV.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="inline-flex min-h-11 items-center text-night-deep hover:text-brand-deep">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}

/** The light footer band. */
export function SiteFooter() {
  const link = 'inline-flex min-h-11 items-center hover:text-night-deep hover:underline md:min-h-0';
  return (
    <footer className="mt-24 bg-paper text-paper-ink">
      <div className="mx-auto flex max-w-[1224px] flex-col gap-4 px-4 py-8 text-[0.8125rem] font-medium md:flex-row md:items-start md:justify-between">
        <p>© 2026 Gcore. All rights reserved.</p>
        <div className="flex flex-col gap-2 md:items-end">
          <nav aria-label="Footer">
            <ul className="flex flex-wrap gap-x-5 md:justify-end">
              {NAV.map((n) => (
                <li key={n.href}>
                  <Link href={n.href} className={link}>
                    {n.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <nav aria-label="For machines and developers">
            <ul className="flex flex-wrap gap-x-5 md:justify-end">
              {MACHINE_LINKS.map((n) => (
                <li key={n.href}>
                  {/* plain anchors: these are files, not app routes */}
                  <a href={n.href} className={link}>
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </footer>
  );
}

/** Visible breadcrumb trail plus BreadcrumbList JSON-LD generated from the same items. */
export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <>
      <JsonLd data={breadcrumbLd(items)} />
      <nav aria-label="Breadcrumb" className="text-sm text-muted">
        <ol className="flex flex-wrap items-center gap-x-2">
          {items.map((c, i) => (
            <li key={c.href} className="flex items-center gap-2">
              {i < items.length - 1 ? (
                <Link href={c.href} className="inline-flex min-h-11 items-center hover:text-brand md:min-h-0">
                  {c.label}
                </Link>
              ) : (
                <span aria-current="page" className="text-text">{c.label}</span>
              )}
              {i < items.length - 1 && <span aria-hidden="true">/</span>}
            </li>
          ))}
        </ol>
      </nav>
    </>
  );
}

export function PriceFootnote({ generatedAt, currency }: { generatedAt: string; currency: string }) {
  return (
    <p className="mt-4 text-xs text-muted">
      Prices in {currency}, taken from our billing system. Price data as of{' '}
      <time dateTime={generatedAt}>{new Date(generatedAt).toISOString().slice(0, 10)}</time>. The order page shows the final
      amount.
    </p>
  );
}

/** Section heading in the gcore.hosting style: white, with the closing phrase in brand orange. */
export function ToneHeading({
  as: Tag = 'h2',
  lead,
  tone,
  className = '',
  id,
}: {
  as?: 'h1' | 'h2';
  lead: React.ReactNode;
  tone?: React.ReactNode;
  className?: string;
  id?: string;
}) {
  const size = Tag === 'h1' ? 'text-4xl sm:text-5xl' : 'text-3xl sm:text-4xl';
  return (
    <Tag id={id} className={`${size} font-bold leading-[1.1] tracking-tight text-white ${className}`}>
      {lead}
      {tone && (
        <>
          {' '}
          <span className="tone">{tone}</span>
        </>
      )}
    </Tag>
  );
}
