import { loadCatalog } from '@/lib/catalog/read';
import { isVerified, locationMap, toPublicLocation, toPublicPlan } from '@/lib/catalog/public';
import { etagFor, json, limited, problem, PUBLIC_API_LIMIT, PUBLIC_CACHE } from './http';
import { plansQuery } from './schemas';

function notReady(): Response {
  return problem(503, 'Catalog not available yet', 'The first catalog sync has not completed.', { 'retry-after': '60' });
}

function notModified(request: Request, etag: string): Response | null {
  return request.headers.get('if-none-match') === etag
    ? new Response(null, { status: 304, headers: { etag, 'cache-control': PUBLIC_CACHE } })
    : null;
}

export async function handlePlans(request: Request): Promise<Response> {
  const blocked = await limited(request, PUBLIC_API_LIMIT);
  if (blocked) return blocked;

  const url = new URL(request.url);
  const q = plansQuery.safeParse(Object.fromEntries(url.searchParams));
  if (!q.success) return problem(400, 'Invalid query parameters', q.error.issues.map((i) => i.path.join('.')).join(', '));

  const catalog = await loadCatalog();
  if (!catalog) return notReady();

  const etag = etagFor(catalog.version, url);
  const nm = notModified(request, etag);
  if (nm) return nm;

  const { kind, location, currency, include, limit, offset } = q.data;
  const locs = locationMap(catalog);
  const matching = catalog.plans.filter(
    (p) =>
      (!kind || p.kind === kind) &&
      (!location || p.locationId === location) &&
      (!currency || p.currency === currency) &&
      (include === 'unverified' || isVerified(p)),
  );
  const page = matching.slice(offset, offset + limit).map((p) => toPublicPlan(p, locs));

  return json(
    {
      data: page,
      meta: { total: matching.length, limit, offset, snapshotVersion: catalog.version, generatedAt: catalog.generatedAt },
    },
    { headers: { etag, 'cache-control': PUBLIC_CACHE } },
  );
}

export async function handlePlan(request: Request, id: string): Promise<Response> {
  const blocked = await limited(request, PUBLIC_API_LIMIT);
  if (blocked) return blocked;
  if (!/^\d{1,12}$/.test(id)) return problem(400, 'Invalid plan id');

  const catalog = await loadCatalog();
  if (!catalog) return notReady();
  const plan = catalog.plans.find((p) => p.id === id);
  if (!plan) return problem(404, 'Plan not found');

  const url = new URL(request.url);
  const etag = etagFor(catalog.version, url);
  const nm = notModified(request, etag);
  if (nm) return nm;
  return json(
    { data: toPublicPlan(plan, locationMap(catalog)), meta: { snapshotVersion: catalog.version, generatedAt: catalog.generatedAt } },
    { headers: { etag, 'cache-control': PUBLIC_CACHE } },
  );
}

export async function handleLocations(request: Request): Promise<Response> {
  const blocked = await limited(request, PUBLIC_API_LIMIT);
  if (blocked) return blocked;

  const catalog = await loadCatalog();
  if (!catalog) return notReady();
  const url = new URL(request.url);
  const etag = etagFor(catalog.version, url);
  const nm = notModified(request, etag);
  if (nm) return nm;
  return json(
    {
      data: catalog.locations.map(toPublicLocation),
      meta: { total: catalog.locations.length, snapshotVersion: catalog.version, generatedAt: catalog.generatedAt },
    },
    { headers: { etag, 'cache-control': PUBLIC_CACHE } },
  );
}
