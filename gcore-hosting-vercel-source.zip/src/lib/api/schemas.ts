import { z } from 'zod';
import type { PublicLocation, PublicPlan } from '@/lib/catalog/public';

/**
 * The public API contract, written once as zod schemas. Three things consume it:
 *  - the handlers parse query strings with `plansQuery`;
 *  - the OpenAPI document (openapi.ts) is generated from these schemas;
 *  - the tests parse every real response with them, so documentation, validation and behaviour cannot drift.
 * The `Equal` assertions at the bottom fail the type check if a schema and the TypeScript interface diverge.
 */

export const slug = z.string().regex(/^[a-z0-9-]{1,60}$/);

export const plansQuery = z.object({
  kind: z.enum(['vps', 'dedicated']).optional().meta({ description: 'Product kind.' }),
  location: slug.optional().meta({ description: 'Location id, as returned by /api/v1/locations (for example `frankfurt`).' }),
  currency: z.enum(['EUR', 'USD']).optional().meta({
    description: 'Currency of the plan. Only EUR plans can be confirmed against the billing system, so USD plans are never `verified`.',
  }),
  /** Unverified plans (not confirmed by BILLmanager) are excluded unless explicitly requested. */
  include: z.enum(['unverified']).optional().meta({
    description: 'Also return plans the billing system did not confirm. They are labelled `verified: false` and carry no order URLs.',
  }),
  limit: z.coerce.number().int().min(1).max(500).default(100).meta({ description: 'Page size.' }),
  offset: z.coerce.number().int().min(0).max(100_000).default(0).meta({ description: 'Number of plans to skip.' }),
});

export const currencySchema = z.enum(['EUR', 'USD']);
export const kindSchema = z.enum(['vps', 'dedicated']);

export const moneySchema = z
  .object({
    amount: z.string().regex(/^\d+(\.\d+)?$/).meta({ description: 'Decimal string. Never a float.' }),
    currency: currencySchema,
  })
  .meta({ id: 'Money', description: 'An amount of money. The amount is a decimal string so that no precision is lost.' });

const periodMap = <T extends z.ZodType>(value: T) =>
  z.object({ monthly: value, quarterly: value, semiannually: value, annually: value });

const diskSchema = z.object({
  count: z.number().int().positive(),
  sizeGB: z.number().positive(),
  type: z.enum(['SSD', 'NVMe', 'SATA', 'SAS', 'HDD']),
  typeSource: z.enum(['billmanager', 'plan-name']).meta({ description: 'Where the disk type came from: the billing system text, or a token in the plan name.' }),
});

export const specsSchema = z
  .object({
    vcpu: z.number().int().positive().optional(),
    ramMiB: z.number().positive().optional(),
    disks: z.array(diskSchema).optional(),
    cpuModel: z.string().optional(),
    cpuSockets: z.number().int().positive().optional(),
    gpu: z.string().optional(),
    raid: z.boolean().optional(),
    portMbps: z.number().positive().optional().meta({ description: 'Port speed in Mbit/s. A port speed is not a throughput guarantee.' }),
    traffic: z
      .discriminatedUnion('kind', [
        z.object({ kind: z.literal('unlimited') }).meta({ description: 'The billing system lists the traffic as unlimited. Fair-use and acceptable-use terms still apply.' }),
        z.object({ kind: z.literal('metered'), includedGB: z.number().nonnegative() }),
      ])
      .optional(),
  })
  .meta({
    id: 'PlanSpecs',
    description:
      'Specifications taken from the billing system. A field that is absent is unknown or withheld; it does not mean zero or "not included".',
  });

export const publicPlanSchema = z
  .object({
    id: z.string().regex(/^\d+$/).meta({ description: 'Billing-system pricelist id. Stable.' }),
    kind: kindSchema,
    name: z.string().meta({ description: 'Plan name exactly as in the billing system, including the location code.' }),
    slug: z.string(),
    family: z.string().optional(),
    location: z.object({ id: z.string(), country: z.string(), city: z.string(), dcLabel: z.string().optional() }),
    currency: currencySchema,
    specs: specsSchema,
    prices: periodMap(moneySchema).meta({ description: 'Price for the whole billing period, exactly as in the billing system.' }),
    perMonthEquivalent: periodMap(moneySchema).meta({ description: 'Derived for display (period price divided by months). The commercial price is `prices`.' }),
    availability: z.enum(['orderable', 'unavailable', 'unknown']),
    verified: z.boolean().meta({
      description: 'True when the billing system confirmed the plan at the last sync and it passed validation. Only verified plans carry order URLs.',
    }),
    orderUrls: z.object({ monthly: z.url().optional(), quarterly: z.url().optional(), semiannually: z.url().optional(), annually: z.url().optional() }),
    addons: z.array(
      z.object({
        id: z.string(),
        name: z.string(),
        min: z.number().optional(),
        max: z.number().optional(),
        step: z.number().optional(),
        prices: z.object({ monthly: z.string().optional(), quarterly: z.string().optional(), semiannually: z.string().optional(), annually: z.string().optional() }),
      }),
    ),
  })
  .meta({ id: 'Plan', description: 'One purchasable plan at one location in one currency.' });

export const publicLocationSchema = z
  .object({ id: z.string(), country: z.string(), city: z.string(), dcLabel: z.string().optional(), products: z.array(kindSchema) })
  .meta({ id: 'Location', description: 'A location, with the product kinds sold there.' });

const snapshotMeta = {
  snapshotVersion: z.number().int().positive().meta({ description: 'Version of the catalog snapshot this response was built from.' }),
  generatedAt: z.iso.datetime({ offset: true }).meta({ description: 'When that snapshot was generated.' }),
};

export const plansResponseSchema = z
  .object({
    data: z.array(publicPlanSchema),
    meta: z.object({ total: z.number().int().nonnegative(), limit: z.number().int(), offset: z.number().int(), ...snapshotMeta }),
  })
  .meta({ id: 'PlansResponse' });

export const planResponseSchema = z.object({ data: publicPlanSchema, meta: z.object(snapshotMeta) }).meta({ id: 'PlanResponse' });

export const locationsResponseSchema = z
  .object({ data: z.array(publicLocationSchema), meta: z.object({ total: z.number().int().nonnegative(), ...snapshotMeta }) })
  .meta({ id: 'LocationsResponse' });

export const problemSchema = z
  .object({ type: z.string(), title: z.string(), status: z.number().int(), detail: z.string().optional() })
  .meta({ id: 'Problem', description: 'RFC 9457 problem details. Never echoes request input.' });

// ---- compile-time agreement with the TypeScript interfaces ------------------------------------

type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends <T>() => T extends B ? 1 : 2 ? true : false;
const assertTrue = <_T extends true>() => undefined;
assertTrue<Equal<z.infer<typeof publicPlanSchema>, PublicPlan>>();
assertTrue<Equal<z.infer<typeof publicLocationSchema>, PublicLocation>>();
