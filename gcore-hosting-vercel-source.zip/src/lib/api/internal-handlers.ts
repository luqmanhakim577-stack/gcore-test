import { z } from 'zod';
import { TAG_PATTERN } from '@/lib/cache/tags';
import { getEnv } from '@/lib/env';
import { loadCatalog, resetCatalogMemo } from '@/lib/catalog/read';
import { getStore, type CatalogStore } from '@/lib/catalog/store';
import { runSync, syncConfigFromEnv, type SyncConfig } from '@/lib/catalog/sync';
import { log } from '@/lib/log';
import { SIGNATURE_WINDOW_SECONDS, verifyRequest } from '@/lib/security/hmac';
import { getLimits, type LimitBackend } from '@/lib/security/limits';
import { INTERNAL_LIMIT, json, limited, problem } from './http';

export interface InternalDeps {
  /** Revalidate this replica and announce the tags to the others. */
  revalidate: (tags: string[], version?: number) => Promise<unknown>;
  /** Revalidate this replica only (the replica's own background tasks call this through the loopback). */
  revalidateLocal: (tags: string[]) => void;
  store?: CatalogStore;
  syncConfig?: () => SyncConfig;
  limits?: LimitBackend;
  now?: () => number;
}

const MAX_BODY_BYTES = 10_000;

const syncBody = z.object({ force: z.boolean().optional() }).strict();
const revalidateBody = z
  .object({
    tags: z.array(z.string().regex(TAG_PATTERN)).min(1).max(200),
    /** "local": this replica only. Default "fleet": this replica and every other one. */
    scope: z.enum(['local', 'fleet']).default('fleet'),
  })
  .strict();

/**
 * Authenticate an internal request: configured secret, bounded body, rate limit, HMAC signature
 * inside the time window, and a one-time nonce (replay protection; fails closed).
 */
async function authenticate(request: Request, deps: InternalDeps): Promise<{ body: string } | Response> {
  const secret = getEnv().REVALIDATE_HMAC_SECRET;
  if (!secret) return problem(503, 'Internal endpoint not configured');

  const blocked = await limited(request, INTERNAL_LIMIT);
  if (blocked) return blocked;

  const declared = Number(request.headers.get('content-length') ?? '0');
  if (declared > MAX_BODY_BYTES) return problem(413, 'Payload too large');
  const body = await request.text();
  if (body.length > MAX_BODY_BYTES) return problem(413, 'Payload too large');

  const pathname = new URL(request.url).pathname;
  const v = verifyRequest(secret, request.method, pathname, body, request.headers, deps.now?.());
  if (!v.ok) {
    log.warn({ reason: v.reason, path: pathname }, 'internal request rejected');
    return problem(401, 'Unauthorized'); // same body for every failure reason
  }
  let first = false;
  try {
    first = await (deps.limits ?? getLimits()).once(`nonce:${v.nonce}`, SIGNATURE_WINDOW_SECONDS * 2);
  } catch {
    return problem(503, 'Replay protection unavailable');
  }
  if (!first) {
    log.warn({ path: pathname }, 'internal request replay rejected');
    return problem(401, 'Unauthorized');
  }
  return { body };
}

function parseJson(body: string): unknown {
  if (body.trim() === '') return {};
  try {
    return JSON.parse(body);
  } catch {
    return Symbol.for('invalid');
  }
}

/** POST /api/internal/sync  { force?: boolean }  -> run a sync and revalidate exactly the changed tags. */
export async function handleSync(request: Request, deps: InternalDeps): Promise<Response> {
  const auth = await authenticate(request, deps);
  if (auth instanceof Response) return auth;
  const parsed = syncBody.safeParse(parseJson(auth.body));
  if (!parsed.success) return problem(400, 'Invalid body');

  const store = deps.store ?? getStore();
  const outcome = await runSync(store, (deps.syncConfig ?? (() => syncConfigFromEnv(log)))(), { force: parsed.data.force });

  if (outcome.status === 'published') {
    resetCatalogMemo();
    await deps.revalidate(outcome.tags, outcome.catalog.version);
    return json({
      status: 'published',
      version: outcome.catalog.version,
      added: outcome.diff.added.length,
      removed: outcome.diff.removed.length,
      changed: outcome.diff.changed.length,
      revalidatedTags: outcome.tags.length,
    });
  }
  if (outcome.status === 'unchanged') resetCatalogMemo();
  if (outcome.status === 'failed' || outcome.status === 'rejected') {
    return json({ status: outcome.status }, { status: 502 }); // reason stays in logs/meta, not in the response
  }
  return json(outcome);
}

/** POST /api/internal/revalidate  { tags: string[] }  -> manual invalidation by tag. */
export async function handleRevalidate(request: Request, deps: InternalDeps): Promise<Response> {
  const auth = await authenticate(request, deps);
  if (auth instanceof Response) return auth;
  const parsed = revalidateBody.safeParse(parseJson(auth.body));
  if (!parsed.success) return problem(400, 'Invalid body');
  const { tags, scope } = parsed.data;
  if (scope === 'local') {
    deps.revalidateLocal(tags);
  } else {
    await deps.revalidate(tags);
  }
  return json({ status: 'revalidated', tags: tags.length, scope });
}

/** GET /api/health  Minimal on purpose: no plan data, no error text. */
export async function handleHealth(): Promise<Response> {
  // The store can be unreachable or misconfigured; health must report that, never throw.
  const catalog = await loadCatalog().catch(() => null);
  const meta = await (async () => getStore().getMeta())().catch(() => null);
  if (!catalog) return json({ status: 'empty' }, { status: 503, headers: { 'cache-control': 'no-store' } });
  const checked = meta ? Date.parse(meta.lastCheckedAt) : NaN;
  const ageSeconds = Number.isFinite(checked) ? Math.max(0, Math.round((Date.now() - checked) / 1000)) : null;
  const stale = ageSeconds === null || ageSeconds > 6 * 3600;
  return json(
    { status: stale ? 'stale' : 'ok', snapshotVersion: catalog.version, lastCheckedSecondsAgo: ageSeconds, lastSyncFailed: Boolean(meta?.lastError) },
    { headers: { 'cache-control': 'no-store' } },
  );
}
