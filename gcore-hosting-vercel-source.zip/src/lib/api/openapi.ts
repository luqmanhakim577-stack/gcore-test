import { z } from 'zod';
import { siteUrl } from '@/lib/seo/config';
import { SYNC_INTERVAL_MINUTES } from '@/lib/site';
import { plansQuery } from './schemas'; // importing the module also registers every component schema (their `id` meta)

/**
 * OpenAPI 3.1 description of the public read-only API, generated from the zod schemas the handlers and
 * tests use. Internal endpoints (HMAC-signed sync/revalidate) are deliberately not documented.
 */

type JsonSchema = Record<string, unknown>;

const ref = (id: string) => ({ $ref: `#/components/schemas/${id}` });

function componentSchemas(): Record<string, JsonSchema> {
  // Registering by id keeps nested types (Money, PlanSpecs, ...) as shared $refs instead of repeating them.
  const out = z.toJSONSchema(z.globalRegistry, { uri: (id) => `#/components/schemas/${id}`, target: 'draft-2020-12', io: 'output' }) as {
    schemas: Record<string, JsonSchema>;
  };
  const schemas: Record<string, JsonSchema> = {};
  for (const [id, s] of Object.entries(out.schemas)) {
    const { $schema: _omit, ...rest } = s as JsonSchema & { $schema?: string };
    schemas[id] = rest;
  }
  return schemas;
}

function queryParameters() {
  const js = z.toJSONSchema(plansQuery, { target: 'draft-2020-12', io: 'input' }) as { properties: Record<string, JsonSchema>; required?: string[] };
  return Object.entries(js.properties).map(([name, schema]) => {
    const { description, ...rest } = schema as { description?: string };
    return { name, in: 'query', required: js.required?.includes(name) ?? false, description, schema: rest };
  });
}

const problemResponse = (description: string, extraHeaders: Record<string, unknown> = {}) => ({
  description,
  headers: extraHeaders,
  content: { 'application/json': { schema: ref('Problem') } },
});

const cacheHeaders = {
  ETag: { description: 'Weak validator bound to the snapshot version and the request URL. Send it back as If-None-Match.', schema: { type: 'string' } },
  'Cache-Control': { description: 'Shared caches may keep a response for 5 minutes and serve a stale one while revalidating.', schema: { type: 'string' } },
};

const retryAfter = { 'Retry-After': { description: 'Seconds to wait before retrying.', schema: { type: 'integer' } } };

const notModified = { description: 'The snapshot has not changed since the ETag you sent.', headers: cacheHeaders };

export function buildOpenApi() {
  const origin = siteUrl();
  return {
    openapi: '3.1.0',
    info: {
      title: 'Gcore Hosting public catalog API',
      version: '1.0.0',
      summary: 'Read-only catalog of VPS and dedicated server plans, prices and locations.',
      description: [
        'Machine-readable view of the same catalog the website renders. No authentication, no API key.',
        '',
        '**Source of truth.** Prices, billing periods, specifications and order URLs come from the BILLmanager 6 billing system. They are never computed or hardcoded here. Prices are for the whole billing period (`prices`); `perMonthEquivalent` is only a display convenience.',
        '',
        '**Verified plans.** By default only plans the billing system confirmed at the last sync are returned. Pass `include=unverified` to see the rest; they are labelled `verified: false` and carry no order URLs. USD plans cannot be confirmed and are therefore never verified.',
        '',
        '**Absent means unknown.** A missing spec field is unknown or withheld, never zero. Port speed is not a throughput guarantee, and `traffic.kind = unlimited` does not remove fair-use or acceptable-use terms.',
        '',
        '**Prices are not the final payable amount.** Taxes and optional services are applied by the order page, which is authoritative.',
        '',
        `**Freshness.** Every response carries \`meta.snapshotVersion\` and \`meta.generatedAt\`. The catalog is re-synchronised from the billing system about every ${SYNC_INTERVAL_MINUTES} minutes; responses may be cached for 5 minutes.`,
        '',
        '**Limits.** 120 requests per minute per client; HTTP 429 with `Retry-After` when exceeded.',
      ].join('\n'),
    },
    servers: [{ url: origin }],
    tags: [{ name: 'Catalog', description: 'Plans and locations.' }],
    paths: {
      '/api/v1/plans': {
        get: {
          operationId: 'listPlans',
          tags: ['Catalog'],
          summary: 'List plans',
          description: 'Plans matching the filters, in snapshot order (not sorted by price). Use `limit` and `offset` to page.',
          parameters: queryParameters(),
          responses: {
            '200': { description: 'A page of plans.', headers: cacheHeaders, content: { 'application/json': { schema: ref('PlansResponse') } } },
            '304': notModified,
            '400': problemResponse('Invalid query parameters. The body names the offending parameters, never their values.'),
            '429': problemResponse('Rate limit exceeded.', retryAfter),
            '503': problemResponse('The first catalog sync has not completed yet.', retryAfter),
          },
        },
      },
      '/api/v1/plans/{id}': {
        get: {
          operationId: 'getPlan',
          tags: ['Catalog'],
          summary: 'Get one plan',
          description: 'Returns the plan whether or not it is verified; check `verified` before relying on its price or order URLs.',
          parameters: [{ name: 'id', in: 'path', required: true, description: 'Billing-system pricelist id.', schema: { type: 'string', pattern: '^\\d{1,12}$' } }],
          responses: {
            '200': { description: 'The plan.', headers: cacheHeaders, content: { 'application/json': { schema: ref('PlanResponse') } } },
            '304': notModified,
            '400': problemResponse('Malformed id.'),
            '404': problemResponse('No plan with this id.'),
            '429': problemResponse('Rate limit exceeded.', retryAfter),
            '503': problemResponse('The first catalog sync has not completed yet.', retryAfter),
          },
        },
      },
      '/api/v1/locations': {
        get: {
          operationId: 'listLocations',
          tags: ['Catalog'],
          summary: 'List locations',
          description: 'Every location in the catalog and the product kinds sold there. A location listed here may currently have no verified plan.',
          responses: {
            '200': { description: 'All locations.', headers: cacheHeaders, content: { 'application/json': { schema: ref('LocationsResponse') } } },
            '304': notModified,
            '429': problemResponse('Rate limit exceeded.', retryAfter),
            '503': problemResponse('The first catalog sync has not completed yet.', retryAfter),
          },
        },
      },
    },
    components: { schemas: componentSchemas() },
  };
}
