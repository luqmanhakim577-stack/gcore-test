import { createHash } from 'node:crypto';
import { checkRateLimit, clientKeyOf, type RateLimitPolicy } from '@/lib/security/limits';

/**
 * Shared caches may reuse a response for 5 minutes and may serve one up to a minute stale while refreshing it.
 * Serving it stale because the origin is failing is allowed for a day (better an old price than an error), but
 * stale-while-revalidate is deliberately short: a long one would hand an idle endpoint's next visitor a price
 * that is a day old.
 */
export const PUBLIC_CACHE = 'public, s-maxage=300, stale-while-revalidate=60, stale-if-error=86400';

const baseHeaders = {
  'x-content-type-options': 'nosniff',
  'cross-origin-resource-policy': 'cross-origin',
} as const;

export function json(body: unknown, init: { status?: number; headers?: Record<string, string> } = {}): Response {
  return new Response(JSON.stringify(body), {
    status: init.status ?? 200,
    headers: { 'content-type': 'application/json; charset=utf-8', ...baseHeaders, ...init.headers },
  });
}

export function problem(status: number, title: string, detail?: string, headers: Record<string, string> = {}): Response {
  // RFC 9457-style body; never echoes raw input or internals.
  return json({ type: 'about:blank', title, status, ...(detail ? { detail } : {}) }, {
    status,
    headers: { 'cache-control': 'no-store', ...headers },
  });
}

/** Weak ETag derived from the snapshot version and the request URL, so 304s are cheap and exact. */
export function etagFor(version: number, url: URL): string {
  const h = createHash('sha1').update(`${version}|${url.pathname}?${url.searchParams.toString()}`).digest('hex').slice(0, 16);
  return `W/"v${version}-${h}"`;
}

export async function limited(request: Request, policy: RateLimitPolicy): Promise<Response | null> {
  const r = await checkRateLimit(policy, clientKeyOf(request.headers));
  if (r.allowed) return null;
  return problem(429, 'Too Many Requests', undefined, { 'retry-after': String(r.retryAfter) });
}

export const PUBLIC_API_LIMIT: RateLimitPolicy = { name: 'public-api', limit: 120, windowSeconds: 60 };
export const INTERNAL_LIMIT: RateLimitPolicy = { name: 'internal', limit: 20, windowSeconds: 60 };
