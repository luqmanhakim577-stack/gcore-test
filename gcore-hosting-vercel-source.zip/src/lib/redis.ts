import { Redis } from 'ioredis';
import { getEnv } from './env';

const g = globalThis as unknown as { __redis?: Redis | null };

/** Shared Redis client, or null when REDIS_URL is not configured (development/tests). */
export function getRedis(): Redis | null {
  if (g.__redis !== undefined) return g.__redis;
  const url = getEnv().REDIS_URL;
  if (!url) {
    g.__redis = null;
    return null;
  }
  const client = new Redis(url, { maxRetriesPerRequest: 2, enableOfflineQueue: false });
  client.on('error', () => undefined); // failures surface per request; avoid unhandled 'error' events
  g.__redis = client;
  return client;
}
