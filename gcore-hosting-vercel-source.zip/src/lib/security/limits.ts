import type { Redis } from 'ioredis';
import { getEnv } from '@/lib/env';
import { getRedis } from '@/lib/redis';

/**
 * Small abstraction over "count within a window" and "seen before" with Redis in production
 * and an in-memory fallback for development/tests. Redis failures fail OPEN for rate limiting
 * (availability of public pages/API matters more) and fail CLOSED for replay protection on
 * internal endpoints (a signed request we cannot de-duplicate is rejected).
 */
export interface LimitBackend {
  /** Increment a fixed-window counter; returns the count including this call and seconds until reset. */
  hit(key: string, windowSeconds: number): Promise<{ count: number; resetIn: number }>;
  /** Returns true the first time a key is seen within ttl, false afterwards. */
  once(key: string, ttlSeconds: number): Promise<boolean>;
}

export class MemoryLimits implements LimitBackend {
  private counters = new Map<string, { count: number; until: number }>();
  private seen = new Map<string, number>();

  constructor(private readonly now: () => number = Date.now) {}

  async hit(key: string, windowSeconds: number) {
    const t = this.now();
    this.gc(t);
    const cur = this.counters.get(key);
    if (!cur || cur.until <= t) {
      this.counters.set(key, { count: 1, until: t + windowSeconds * 1000 });
      return { count: 1, resetIn: windowSeconds };
    }
    cur.count++;
    return { count: cur.count, resetIn: Math.max(1, Math.ceil((cur.until - t) / 1000)) };
  }

  async once(key: string, ttlSeconds: number) {
    const t = this.now();
    this.gc(t);
    if ((this.seen.get(key) ?? 0) > t) return false;
    this.seen.set(key, t + ttlSeconds * 1000);
    return true;
  }

  private gc(t: number) {
    if (this.counters.size + this.seen.size < 5000) return;
    for (const [k, v] of this.counters) if (v.until <= t) this.counters.delete(k);
    for (const [k, v] of this.seen) if (v <= t) this.seen.delete(k);
  }
}

export class RedisLimits implements LimitBackend {
  constructor(private readonly redis: Redis) {}

  async hit(key: string, windowSeconds: number) {
    const k = `gcore:rl:${key}`;
    const count = await this.redis.incr(k);
    if (count === 1) await this.redis.expire(k, windowSeconds);
    const ttl = await this.redis.ttl(k);
    return { count, resetIn: ttl > 0 ? ttl : windowSeconds };
  }

  async once(key: string, ttlSeconds: number) {
    const res = await this.redis.set(`gcore:once:${key}`, '1', 'EX', ttlSeconds, 'NX');
    return res === 'OK';
  }
}

const g = globalThis as unknown as { __limits?: LimitBackend };

export function getLimits(): LimitBackend {
  if (g.__limits) return g.__limits;
  const redis = getRedis();
  g.__limits = redis ? new RedisLimits(redis) : new MemoryLimits();
  return g.__limits;
}

export interface RateLimitPolicy {
  name: string;
  limit: number;
  windowSeconds: number;
}

export type RateLimitResult = { allowed: true; remaining: number } | { allowed: false; retryAfter: number };

export async function checkRateLimit(
  policy: RateLimitPolicy,
  clientKey: string,
  backend: LimitBackend = getLimits(),
): Promise<RateLimitResult> {
  try {
    const { count, resetIn } = await backend.hit(`${policy.name}:${clientKey}`, policy.windowSeconds);
    if (count > policy.limit) return { allowed: false, retryAfter: resetIn };
    return { allowed: true, remaining: policy.limit - count };
  } catch {
    return { allowed: true, remaining: policy.limit }; // fail open
  }
}

/**
 * Client identity for rate limiting. The left side of X-Forwarded-For is whatever the client chose to send;
 * only entries appended by our own proxies can be trusted. Each trusted proxy appends the address it received
 * the request from, so the client is the entry `hops` positions from the right (TRUSTED_PROXY_HOPS). Taking the
 * left-most entry instead lets anyone mint a fresh rate-limit bucket per request by sending a made-up header.
 * With no trusted proxy (hops 0) or no usable header everyone shares one bucket.
 */
export function clientKeyOf(headers: { get(name: string): string | null }, hops: number = getEnv().TRUSTED_PROXY_HOPS): string {
  if (hops <= 0) return 'unknown';
  const chain = (headers.get('x-forwarded-for') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  const raw = chain.length > 0 ? chain[Math.max(0, chain.length - hops)] : headers.get('x-real-ip')?.trim();
  return normalizeClientIp(raw ?? '');
}

/** Characters an address can contain, and IPv6 clients grouped by /64 (one subscriber controls a whole /64). */
function normalizeClientIp(raw: string): string {
  const ip = raw.slice(0, 64).replace(/[^0-9a-fA-F:.]/g, '');
  if (!ip) return 'unknown';
  if (!ip.includes(':') || ip.includes('.')) return ip; // IPv4, or an IPv4-mapped form: keep as given
  const [head = '', tail = ''] = ip.split('::');
  const headGroups = head ? head.split(':') : [];
  const tailGroups = ip.includes('::') && tail ? tail.split(':') : [];
  const groups = ip.includes('::') ? [...headGroups, ...Array(Math.max(0, 8 - headGroups.length - tailGroups.length)).fill('0'), ...tailGroups] : headGroups;
  return `${groups.slice(0, 4).map((g) => g.toLowerCase().replace(/^0+(?=.)/, '')).join(':')}::/64`;
}
