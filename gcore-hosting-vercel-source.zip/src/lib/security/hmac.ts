import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';

/**
 * Request signing for internal endpoints (sync/revalidate).
 *   signature = HMAC-SHA256(secret, `${timestamp}.${nonce}.${METHOD}.${pathname}.${body}`)
 * Headers: x-timestamp (unix seconds), x-nonce, x-signature (hex).
 * The timestamp bounds replay to a short window; the nonce (see ReplayGuard) rejects reuse inside it.
 */
export const SIGNATURE_WINDOW_SECONDS = 300;

export type SignedHeaders = {
  'x-timestamp': string;
  'x-nonce': string;
  'x-signature': string;
};

function compute(secret: string, timestamp: string, nonce: string, method: string, pathname: string, body: string): string {
  return createHmac('sha256', secret).update(`${timestamp}.${nonce}.${method.toUpperCase()}.${pathname}.${body}`).digest('hex');
}

export function signRequest(
  secret: string,
  method: string,
  pathname: string,
  body = '',
  opts: { now?: number; nonce?: string } = {},
): SignedHeaders {
  const timestamp = String(Math.floor((opts.now ?? Date.now()) / 1000));
  const nonce = opts.nonce ?? randomUUID();
  return {
    'x-timestamp': timestamp,
    'x-nonce': nonce,
    'x-signature': compute(secret, timestamp, nonce, method, pathname, body),
  };
}

export type VerifyResult = { ok: true; nonce: string } | { ok: false; reason: 'missing' | 'stale' | 'bad-signature' };

export function verifyRequest(
  secret: string,
  method: string,
  pathname: string,
  body: string,
  headers: { get(name: string): string | null },
  now = Date.now(),
): VerifyResult {
  const timestamp = headers.get('x-timestamp');
  const nonce = headers.get('x-nonce');
  const signature = headers.get('x-signature');
  if (!timestamp || !nonce || !signature) return { ok: false, reason: 'missing' };
  if (!/^\d{1,12}$/.test(timestamp) || nonce.length > 100) return { ok: false, reason: 'missing' };
  if (Math.abs(now / 1000 - Number(timestamp)) > SIGNATURE_WINDOW_SECONDS) return { ok: false, reason: 'stale' };

  const expected = Buffer.from(compute(secret, timestamp, nonce, method, pathname, body), 'hex');
  let given: Buffer;
  try {
    given = Buffer.from(signature, 'hex');
  } catch {
    return { ok: false, reason: 'bad-signature' };
  }
  // Constant-time comparison; length check first because timingSafeEqual throws on mismatch.
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return { ok: false, reason: 'bad-signature' };
  return { ok: true, nonce };
}
