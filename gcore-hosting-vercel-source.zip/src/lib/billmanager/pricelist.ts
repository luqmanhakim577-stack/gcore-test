import { z } from 'zod';
import type { Addon, ProductKind } from '@/lib/catalog/model';
import { normalizeAmount, PERIODS, type Currency, type PeriodKey } from '@/lib/catalog/money';

/**
 * S2: BILLmanager 6 `pricelist.export` (public, documented for website integration).
 * Values are wrapped as {"$": "..."}; empty values appear as {}; numbers are strings.
 */

/** Unwrap a BILLmanager value: "x" | {"$":"x"} | {} -> string | undefined. */
export function bmStr(v: unknown): string | undefined {
  if (typeof v === 'string') return v;
  if (v && typeof v === 'object' && '$' in v) {
    const inner = (v as Record<string, unknown>)['$'];
    if (typeof inner === 'string') return inner;
  }
  return undefined;
}

function bmNum(v: unknown): number | undefined {
  const s = bmStr(v);
  if (s === undefined || s === '') return undefined;
  const n = Number(s);
  return Number.isFinite(n) ? n : undefined;
}

/** BILLmanager returns one element as an object and several as an array, depending on the function. */
function many(v: unknown): unknown[] {
  if (Array.isArray(v)) return v;
  if (v === undefined || v === null) return [];
  return [v];
}

function rec(v: unknown): Record<string, unknown> {
  return v && typeof v === 'object' ? (v as Record<string, unknown>) : {};
}

export interface S2Period {
  cost: string;
  length: number;
  orderLink?: string;
}

export interface S2Plan {
  id: string;
  name: string;
  itemtype: ProductKind | undefined;
  rawItemtype?: string;
  active: boolean;
  hidden: boolean;
  currency?: Currency;
  datacenterName?: string;
  descriptionText: string;
  orderLink?: string;
  periods: Partial<Record<PeriodKey, S2Period>>;
  addons: Addon[];
}

const ITEMTYPE_TO_KIND: Record<string, ProductKind> = { vds: 'vps', dedic: 'dedicated' };

function periodKeyOf(length: number | undefined, type: string | undefined): PeriodKey | undefined {
  if (type !== 'month') return undefined;
  return PERIODS.find((p) => ({ monthly: 1, quarterly: 3, semiannually: 6, annually: 12 })[p] === length);
}

function parsePeriods(price: unknown): { currency?: Currency; periods: Partial<Record<PeriodKey, S2Period>> } {
  const p = rec(price);
  const cur = bmStr(p['$currency']);
  const currency = cur === 'EUR' || cur === 'USD' ? cur : undefined;
  const periods: Partial<Record<PeriodKey, S2Period>> = {};
  for (const raw of many(p['period'])) {
    const r = rec(raw);
    const length = bmNum(r['$length']);
    const key = periodKeyOf(length, bmStr(r['$type']));
    const cost = bmStr(r['$cost']);
    if (!key || length === undefined || cost === undefined) continue;
    periods[key] = { cost: normalizeAmount(cost), length, orderLink: bmStr(r['$orderlink']) };
  }
  return { currency, periods };
}

/** `measure` is [ {"$": "3"}, {id, name: {"$": "GiB"}} ] (id, then the unit object) or a bare {"$": "1"}. */
function measureName(v: unknown): string | undefined {
  for (const m of many(v)) {
    const name = bmStr(rec(m)['name']);
    if (name) return name;
  }
  return undefined;
}

function parseAddon(raw: unknown): Addon | undefined {
  const a = rec(raw);
  const id = bmStr(a['id']);
  const name = bmStr(a['name']);
  if (!id || !name) return undefined;
  const { currency, periods } = parsePeriods(a['price']);
  const prices: Addon['prices'] = {};
  for (const key of PERIODS) {
    const p = periods[key];
    if (p) prices[key] = p.cost;
  }
  return {
    id,
    name: name.trim(),
    intname: bmStr(a['intname']),
    type: bmStr(a['addontype']),
    billType: bmStr(a['billtype']),
    min: bmNum(a['addonmin']),
    max: bmNum(a['addonmax']),
    step: bmNum(a['addonstep']),
    included: bmNum(a['addonlimit']),
    typeId: bmStr(a['itemtype']),
    parentTypeId: bmStr(rec(a['addon_itemtype_info'])['parent']),
    unit: measureName(a['measure']),
    currency,
    prices,
  };
}

/** Strip HTML tags/entities from BILLmanager's rich-text description. */
export function htmlToText(html: string): string {
  return html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function parsePlan(raw: unknown): S2Plan | undefined {
  const p = rec(raw);
  const id = bmStr(p['id']);
  const name = bmStr(p['name']);
  if (!id || !name) return undefined;
  const rawItemtype = bmStr(rec(p['itemtype_info'])['intname']);
  const { currency, periods } = parsePeriods(p['price']);
  const dc = rec(many(p['datacenter'])[0]);
  return {
    id,
    name,
    itemtype: rawItemtype ? ITEMTYPE_TO_KIND[rawItemtype] : undefined,
    rawItemtype,
    active: bmStr(p['active']) === 'on',
    hidden: bmStr(p['hidden_type']) === 'on',
    currency,
    datacenterName: bmStr(dc['name']),
    descriptionText: htmlToText(bmStr(p['description']) ?? ''),
    orderLink: bmStr(p['orderlink']),
    periods,
    addons: many(p['addon']).map(parseAddon).filter((a): a is Addon => a !== undefined),
  };
}

export type PricelistParse =
  | { ok: true; plans: S2Plan[] }
  | { ok: false; error: 'invalid-pricelist'; offendingId?: string }
  | { ok: false; error: 'other'; message: string };

const rootSchema = z.object({ doc: z.record(z.string(), z.unknown()) });

/**
 * Parse a pricelist.export body. A request containing a plan id that the anonymous user cannot see
 * fails as a whole with an `invalid value` error naming the first offending id.
 */
export function parsePricelistExport(body: string): PricelistParse {
  let json: unknown;
  try {
    json = JSON.parse(body);
  } catch {
    return { ok: false, error: 'other', message: 'pricelist.export returned non-JSON' };
  }
  const root = rootSchema.safeParse(json);
  if (!root.success) return { ok: false, error: 'other', message: 'pricelist.export: unexpected root shape' };
  const doc = root.data.doc;

  const err = doc['error'];
  if (err !== undefined) {
    const e = rec(err);
    const params = many(e['param']).map(rec);
    const isPricelist = e['$object'] === 'pricelist' && e['$type'] === 'value';
    const value = params.find((q) => q['$name'] === 'value');
    if (isPricelist) return { ok: false, error: 'invalid-pricelist', offendingId: bmStr(value) };
    return { ok: false, error: 'other', message: bmStr(e['msg']) ?? 'pricelist.export error' };
  }

  const plans = many(doc['pricelist']).map(parsePlan).filter((p): p is S2Plan => p !== undefined);
  return { ok: true, plans };
}

/**
 * Only accept order links that point at the BILLmanager host's register endpoint.
 * A poisoned or misconfigured feed must not be able to inject an arbitrary redirect.
 */
export function guardOrderLink(link: string | undefined, billmanagerBaseUrl: string): string | undefined {
  if (!link) return undefined;
  let u: URL;
  try {
    u = new URL(link);
  } catch {
    return undefined;
  }
  const base = new URL(billmanagerBaseUrl);
  if (u.origin !== base.origin) return undefined;
  if (u.pathname !== '/billmgr') return undefined;
  if (u.searchParams.get('func') !== 'register') return undefined;
  return u.toString();
}
