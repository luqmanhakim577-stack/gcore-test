import { parsePricelistExport, type S2Plan } from './pricelist';

export interface PricelistClientConfig {
  baseUrl: string;
  batchSize: number;
  concurrency: number;
  timeoutMs?: number;
  retries?: number;
  /** Base delay for exponential backoff between retries. */
  backoffMs?: number;
  /** Consecutive exhausted requests after which the remaining ids are marked failed. Default 4. */
  maxExhaustedRequests?: number;
  fetchImpl?: typeof fetch;
  /** Called for diagnostics only; must not receive secrets or payloads. */
  onEvent?: (event: { type: string; ids?: string[]; detail?: string }) => void;
}

export interface PricelistFetchResult {
  plans: Map<string, S2Plan>;
  /** Ids BILLmanager rejected for anonymous access (hidden/unlisted/unknown). Not an outage. */
  notPublic: Set<string>;
  /** Ids we could not fetch because of transport/server errors. Callers carry over previous data. */
  failed: Set<string>;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    for (;;) {
      const i = next++;
      if (i >= items.length) return;
      out[i] = await fn(items[i] as T);
    }
  });
  await Promise.all(workers);
  return out;
}

function chunk<T>(items: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}

function buildUrl(baseUrl: string, ids: string[]): URL {
  const u = new URL('/billmgr', baseUrl);
  u.searchParams.set('func', 'pricelist.export');
  u.searchParams.set('out', 'json');
  u.searchParams.set('pricelist', ids.join(','));
  return u;
}

/**
 * Fetch plan details in small batches (a bulk call without ids times out at the proxy).
 * - transport/5xx errors are retried with backoff; a failing batch is split to isolate the cause
 * - an `invalid value` error names one id the anonymous user cannot see: that id is recorded as
 *   notPublic and the rest of the batch is retried
 */
export async function fetchPricelists(ids: string[], cfg: PricelistClientConfig): Promise<PricelistFetchResult> {
  const f = cfg.fetchImpl ?? fetch;
  const retries = cfg.retries ?? 2;
  const backoff = cfg.backoffMs ?? 500;
  const result: PricelistFetchResult = { plans: new Map(), notPublic: new Set(), failed: new Set() };

  // Circuit breaker: when BILLmanager is down, stop after a few exhausted requests instead of
  // spending minutes retrying every batch against a billing host that is already struggling.
  const maxExhausted = cfg.maxExhaustedRequests ?? 4;
  let exhaustedInARow = 0;
  const tripped = () => exhaustedInARow >= maxExhausted;

  async function request(batch: string[]): Promise<string> {
    let lastErr: unknown;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await f(buildUrl(cfg.baseUrl, batch), {
          headers: { accept: 'application/json' },
          signal: AbortSignal.timeout(cfg.timeoutMs ?? 25_000),
          cache: 'no-store',
        });
        if (res.status >= 500) throw new Error(`pricelist.export responded ${res.status}`);
        const text = await res.text();
        exhaustedInARow = 0;
        return text;
      } catch (e) {
        lastErr = e;
        if (attempt < retries) await sleep(backoff * 2 ** attempt);
      }
    }
    exhaustedInARow++;
    throw lastErr instanceof Error ? lastErr : new Error('pricelist.export request failed');
  }

  async function runBatch(batch: string[]): Promise<void> {
    if (tripped()) {
      cfg.onEvent?.({ type: 'circuit-open', ids: batch });
      for (const id of batch) result.failed.add(id);
      return;
    }
    let pending = [...batch];
    while (pending.length > 0) {
      let body: string;
      try {
        body = await request(pending);
      } catch (e) {
        if (pending.length > 1) {
          // Isolate: a slow/oversized batch may succeed in halves; a single bad id will fail alone.
          cfg.onEvent?.({ type: 'split', ids: pending, detail: (e as Error).message });
          const mid = Math.ceil(pending.length / 2);
          await runBatch(pending.slice(0, mid));
          await runBatch(pending.slice(mid));
        } else {
          cfg.onEvent?.({ type: 'failed', ids: pending, detail: (e as Error).message });
          for (const id of pending) result.failed.add(id);
        }
        return;
      }

      const parsed = parsePricelistExport(body);
      if (parsed.ok) {
        for (const p of parsed.plans) result.plans.set(p.id, p);
        // Requested but absent from a successful response: treat as not public, not as an outage.
        for (const id of pending) if (!result.plans.has(id)) result.notPublic.add(id);
        return;
      }
      if (parsed.error === 'invalid-pricelist') {
        const bad = parsed.offendingId;
        if (bad && pending.includes(bad)) {
          result.notPublic.add(bad);
          pending = pending.filter((id) => id !== bad);
          continue;
        }
        // Unattributable error: fall back to one-by-one to attribute precisely.
        if (pending.length > 1) {
          for (const id of pending) await runBatch([id]);
        } else {
          for (const id of pending) result.notPublic.add(id);
        }
        return;
      }
      cfg.onEvent?.({ type: 'error-response', ids: pending, detail: parsed.message });
      for (const id of pending) result.failed.add(id);
      return;
    }
  }

  await mapLimit(chunk(ids, cfg.batchSize), cfg.concurrency, runBatch);
  return result;
}
