import { z } from 'zod';
import type { ProductKind } from '@/lib/catalog/model';

/**
 * S1: the calc feed. A flat index of every plan x location x currency.
 * Each row's `id` is the BILLmanager pricelist id.
 *
 * Known quirks (see ARCHITECTURE.md 2.2): Content-Type is text/html although the body is JSON;
 * the `discount` field does not match the period prices; spec strings use mixed units.
 */

const priceBlock = z.object({
  name: z.string().optional(),
  currency: z.enum(['EUR', 'USD']),
  monthly: z.number(),
  quarterly: z.number(),
  semiannually: z.number(),
  annually: z.number(),
});

export const calcRowSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  cpu: z.string(),
  gpu: z.string().nullish(),
  ram: z.string(),
  hdd: z.string(),
  country: z.string().min(1),
  data_center: z.string().min(1),
  raid: z.boolean().nullish(),
  os_price: priceBlock.nullish(),
  server_price: priceBlock,
  discount: z
    .object({ quarterly: z.number(), semiannually: z.number(), annually: z.number() })
    .optional(),
  connection_speed: z.string(),
  traffic: z.string(),
});

export type CalcRow = z.infer<typeof calcRowSchema>;

export const CALC_PATHS: Record<ProductKind, string> = {
  vps: '/vps/?format=json',
  dedicated: '/dedicated_servers/?format=json',
};

export class FeedShapeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'FeedShapeError';
  }
}

export interface CalcFeedResult {
  kind: ProductKind;
  rows: CalcRow[];
  invalid: Array<{ index: number; error: string }>;
  fetchedAt: string;
}

/** Share of rows allowed to fail validation before the whole feed is rejected. */
const MAX_INVALID_RATIO = 0.02;

/** Validate an already-fetched feed body. Pure; used by the client and by tests on real fixtures. */
export function parseCalcFeed(kind: ProductKind, body: string, fetchedAt = new Date().toISOString()): CalcFeedResult {
  let json: unknown;
  try {
    json = JSON.parse(body);
  } catch {
    throw new FeedShapeError(`calc feed (${kind}) is not valid JSON`);
  }
  if (!Array.isArray(json)) throw new FeedShapeError(`calc feed (${kind}) is not an array`);
  if (json.length === 0) throw new FeedShapeError(`calc feed (${kind}) is empty`);

  const rows: CalcRow[] = [];
  const invalid: CalcFeedResult['invalid'] = [];
  json.forEach((item, index) => {
    const r = calcRowSchema.safeParse(item);
    if (r.success) rows.push(r.data);
    else invalid.push({ index, error: z.prettifyError(r.error).slice(0, 300) });
  });
  if (invalid.length / json.length > MAX_INVALID_RATIO) {
    throw new FeedShapeError(
      `calc feed (${kind}): ${invalid.length}/${json.length} rows failed validation, first: ${invalid[0]?.error}`,
    );
  }
  const seen = new Set<string>();
  for (const row of rows) {
    if (seen.has(row.id)) throw new FeedShapeError(`calc feed (${kind}): duplicate id ${row.id}`);
    seen.add(row.id);
  }
  return { kind, rows, invalid, fetchedAt };
}

export interface CalcClientConfig {
  baseUrl: string;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
}

export async function fetchCalcFeed(kind: ProductKind, cfg: CalcClientConfig): Promise<CalcFeedResult> {
  const f = cfg.fetchImpl ?? fetch;
  const url = new URL(CALC_PATHS[kind], cfg.baseUrl);
  const res = await f(url, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(cfg.timeoutMs ?? 30_000),
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`calc feed (${kind}) responded ${res.status}`);
  // Do not trust Content-Type: the feed serves JSON as text/html.
  return parseCalcFeed(kind, await res.text());
}
