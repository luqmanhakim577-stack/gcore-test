import type { Disk, DiskType, Traffic } from '@/lib/catalog/model';

/**
 * Strict spec parsers for the calc feed's free-text fields. Each returns undefined when the
 * text is not in a known format; callers flag that instead of guessing.
 */

export function parseVcpu(s: string): number | undefined {
  const m = /^\s*(\d+)\s*vCPU\s*$/i.exec(s);
  return m ? Number(m[1]) : undefined;
}

/** "24 GB", "16 Gb", "128Gb", "1024 MB" -> MiB. GB/Gb are treated as 1024 MiB (hosting convention). */
export function parseRamMiB(s: string): number | undefined {
  const m = /^\s*(\d+(?:\.\d+)?)\s*(GB|Gb|G|MB|Mb|M)\s*$/.exec(s);
  if (!m) return undefined;
  const n = Number(m[1]);
  const unit = (m[2] ?? '').toUpperCase();
  return unit.startsWith('G') ? Math.round(n * 1024) : Math.round(n);
}

/** Single VPS disk: "500 GB", "20 Gb". Type is not in this string. */
export function parseVpsDiskGB(s: string): number | undefined {
  const m = /^\s*(\d+(?:\.\d+)?)\s*(GB|Gb|TB|Tb)\s*$/.exec(s);
  if (!m) return undefined;
  const n = Number(m[1]);
  return (m[2] ?? '').toUpperCase() === 'TB' ? n * 1000 : n;
}

const DISK_TYPES: Record<string, DiskType> = {
  SSD: 'SSD',
  NVME: 'NVMe',
  SATA: 'SATA',
  SAS: 'SAS',
  HDD: 'HDD',
};

/** Dedicated storage: "2x960SSD", "250SSD", "2x2000SSD + 2x4000SATA", "2x7600NVMe". Sizes are GB. */
export function parseDedicatedDisks(s: string): Disk[] | undefined {
  const groups = s.split('+').map((g) => g.trim());
  const disks: Disk[] = [];
  for (const g of groups) {
    const m = /^(?:(\d+)\s*x\s*)?(\d+)\s*(SSD|NVMe|SATA|SAS|HDD)$/i.exec(g);
    if (!m) return undefined;
    const type = DISK_TYPES[(m[3] ?? '').toUpperCase()];
    if (!type) return undefined;
    disks.push({ count: m[1] ? Number(m[1]) : 1, sizeGB: Number(m[2]), type, typeSource: 'billmanager' });
  }
  return disks.length ? disks : undefined;
}

/** "2xSilver-4214" -> 2 sockets; "E-2136" -> 1 socket. */
export function parseCpu(s: string): { cpuModel: string; cpuSockets: number } | undefined {
  const t = s.trim();
  if (!t) return undefined;
  const m = /^(\d+)x(.+)$/.exec(t);
  if (m) return { cpuSockets: Number(m[1]), cpuModel: (m[2] ?? '').trim() };
  return { cpuSockets: 1, cpuModel: t };
}

/** "200Mbit/s", "50Mbit/s", "1 Gbps", "10 Gbps" -> Mbit/s. */
export function parsePortMbps(s: string): number | undefined {
  const m = /^\s*(\d+(?:\.\d+)?)\s*(Mbit\/s|Mbps|Gbit\/s|Gbps)\s*$/i.exec(s);
  if (!m) return undefined;
  const n = Number(m[1]);
  return /^g/i.test(m[2] ?? '') ? n * 1000 : n;
}

/** "∞" -> unlimited; "10000GB", "30 TB" -> metered (TB = 1000 GB). */
export function parseTraffic(s: string): Traffic | undefined {
  const t = s.trim();
  if (t === '∞') return { kind: 'unlimited' };
  const m = /^(\d+(?:\.\d+)?)\s*(GB|Gb|TB|Tb)$/.exec(t);
  if (!m) return undefined;
  const n = Number(m[1]);
  return { kind: 'metered', includedGB: (m[2] ?? '').toUpperCase() === 'TB' ? n * 1000 : n };
}

export interface VpsDescription {
  vcpu?: number;
  ramMiB?: number;
  diskGB?: number;
  diskType?: DiskType;
  portMbps?: number;
  trafficUnlimited?: boolean;
}

/**
 * BILLmanager VPS description line, e.g.
 * "vCPU: 12x | RAM: 24GB | Disk: 500GB SSD | Network speed: 200Mbit/s, traffic unlimited".
 */
export function parseVpsDescription(text: string): VpsDescription {
  const out: VpsDescription = {};
  const vcpu = /vCPU:\s*(\d+)\s*x?/i.exec(text);
  if (vcpu) out.vcpu = Number(vcpu[1]);
  const ram = /RAM:\s*(\d+(?:\.\d+)?)\s*(GB|MB)/i.exec(text);
  if (ram) out.ramMiB = parseRamMiB(`${ram[1]} ${ram[2]}`);
  const disk = /Disk:\s*(\d+(?:\.\d+)?)\s*(GB|TB)?\s*(SSD|NVMe|HDD|SATA|SAS)?/i.exec(text);
  if (disk) {
    out.diskGB = parseVpsDiskGB(`${disk[1]} ${disk[2] ?? 'GB'}`);
    if (disk[3]) out.diskType = DISK_TYPES[disk[3].toUpperCase()];
  }
  const speed = /Network speed:\s*(\d+(?:\.\d+)?\s*(?:Mbit\/s|Mbps|Gbit\/s|Gbps))/i.exec(text);
  if (speed) out.portMbps = parsePortMbps(speed[1] ?? '');
  if (/traffic\s+unlimited/i.test(text)) out.trafficUnlimited = true;
  return out;
}
