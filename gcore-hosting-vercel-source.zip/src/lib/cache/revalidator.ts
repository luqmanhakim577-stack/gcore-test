import { EMPTY_LOG_ID, type RevalidationLog } from './revalidation-log';
import { SITE_TAG, isValidTag } from './tags';

type Logger = {
  info: (o: object, msg?: string) => void;
  warn: (o: object, msg?: string) => void;
};

export interface RevalidatorDeps {
  log: RevalidationLog;
  /**
   * Revalidate THIS replica's Next cache. Inside a request handler that is `revalidateTag`; background code
   * (scheduler, poller) has no request, where `revalidateTag` throws, so it calls the replica's own signed
   * internal endpoint instead.
   */
  applyLocal: (tags: string[]) => Promise<void> | void;
  replicaId: string;
  logger?: Logger;
  /**
   * The image's pages were rendered from the snapshot `buildId`. When the live snapshot is a different one the
   * replica cannot know which pages are stale, so it revalidates everything once.
   */
  boot?: { buildId: string; liveId: () => Promise<string | null> };
}

const POLL_BATCH = 200;
const MAX_BATCHES_PER_POLL = 5;
/** A bigger change set means "nearly everything changed": one tag is cheaper and safe. */
export const MAX_TAGS_PER_ANNOUNCEMENT = 150;

export class Revalidator {
  private cursor: string | null = null;
  private reconciled = false;
  /** Tags this replica failed to apply (e.g. its own server was not accepting requests yet); retried on every tick. */
  private pending = new Set<string>();

  constructor(private readonly deps: RevalidatorDeps) {}

  /** Apply on this replica now, then tell the others. Never throws. */
  async announce(tags: string[], version?: number): Promise<{ propagated: boolean }> {
    const unique = [...new Set(tags.filter(isValidTag))];
    if (unique.length === 0) return { propagated: true };
    const send = unique.length > MAX_TAGS_PER_ANNOUNCEMENT ? [SITE_TAG] : unique;
    await this.apply(send);
    try {
      await this.deps.log.append({ origin: this.deps.replicaId, tags: send, ...(version !== undefined ? { version } : {}) });
      return { propagated: true };
    } catch (e) {
      // Other replicas fall back to the time-based revalidation of every page (at most one sync interval).
      this.deps.logger?.warn({ err: (e as Error).message }, 'revalidation not propagated to other replicas');
      return { propagated: false };
    }
  }

  /** One round of replica housekeeping: reconcile once after boot, retry failed applies, replay others' announcements. */
  async tick(): Promise<void> {
    if (!this.reconciled && this.deps.boot) {
      try {
        await this.reconcile(this.deps.boot.buildId, this.deps.boot.liveId);
        this.reconciled = true;
      } catch (e) {
        this.deps.logger?.warn({ err: (e as Error).message }, 'boot reconciliation will be retried');
        return;
      }
    }
    await this.retryPending();
    await this.poll();
  }

  /** Apply what other replicas announced since the last poll. The first call only records where the log is. */
  async poll(): Promise<number> {
    const collected = new Set<string>();
    try {
      if (this.cursor === null) {
        this.cursor = await this.deps.log.head();
        return 0;
      }
      for (let i = 0; i < MAX_BATCHES_PER_POLL; i++) {
        const events = await this.deps.log.readAfter(this.cursor, POLL_BATCH);
        for (const e of events) {
          this.cursor = e.id;
          if (e.origin === this.deps.replicaId) continue; // already applied when announced
          for (const t of e.tags) if (isValidTag(t)) collected.add(t);
        }
        if (events.length < POLL_BATCH) break;
      }
    } catch (e) {
      this.deps.logger?.warn({ err: (e as Error).message }, 'revalidation poll failed');
    }
    if (collected.size > 0) {
      await this.apply([...collected]);
      this.deps.logger?.info({ tags: collected.size }, 'applied revalidation announced by another replica');
    }
    return collected.size;
  }

  /** Compare the snapshot the image was built from with the live one. */
  async reconcile(buildId: string, liveId: () => Promise<string | null>): Promise<'current' | 'revalidated' | 'no-snapshot'> {
    // Position in the log first: anything announced after this point is replayed by poll().
    this.cursor ??= await this.deps.log.head();
    const live = await liveId();
    if (!live) return 'no-snapshot';
    if (live === buildId) return 'current';
    this.deps.logger?.info({ buildId, live }, 'live snapshot differs from the one this image was built from: revalidating all pages');
    await this.apply([SITE_TAG]);
    return 'revalidated';
  }

  private async apply(tags: string[]): Promise<void> {
    try {
      await this.deps.applyLocal(tags);
    } catch (e) {
      for (const t of tags) this.pending.add(t);
      this.deps.logger?.warn({ err: (e as Error).message, tags: tags.length }, 'could not revalidate this replica yet; will retry');
    }
  }

  private async retryPending(): Promise<void> {
    if (this.pending.size === 0) return;
    const tags = [...this.pending];
    this.pending.clear();
    await this.apply(tags);
  }
}

export { EMPTY_LOG_ID };
