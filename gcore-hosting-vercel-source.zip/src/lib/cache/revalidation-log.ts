import { randomUUID } from 'node:crypto';
import type { Redis } from 'ioredis';
import { getRedis } from '@/lib/redis';

/**
 * Fleet-wide revalidation log. Next's cache lives on each replica, so `revalidateTag` on the replica that
 * ran a sync does nothing for the others. Every announcement is appended here; every replica replays the
 * entries it has not seen and revalidates its own cache.
 */
export interface RevalidationEvent {
  id: string;
  /** Replica that announced it (it has already applied the tags itself). */
  origin: string;
  tags: string[];
  /** Snapshot version the announcement belongs to, when it came from a sync. */
  version?: number;
}

export interface RevalidationLog {
  append(event: Omit<RevalidationEvent, 'id'>): Promise<void>;
  /** Id of the newest entry, or "0-0" when the log is empty. */
  head(): Promise<string>;
  /** Entries strictly after `id`, oldest first. */
  readAfter(id: string, limit: number): Promise<RevalidationEvent[]>;
}

export const EMPTY_LOG_ID = '0-0';

export class MemoryRevalidationLog implements RevalidationLog {
  private entries: RevalidationEvent[] = [];
  private seq = 0;

  async append(event: Omit<RevalidationEvent, 'id'>) {
    this.entries.push({ ...event, id: `${++this.seq}-0` });
    if (this.entries.length > 1000) this.entries.shift();
  }
  async head() {
    return this.entries.at(-1)?.id ?? EMPTY_LOG_ID;
  }
  async readAfter(id: string, limit: number) {
    const after = Number.parseInt(id, 10) || 0;
    return this.entries.filter((e) => Number.parseInt(e.id, 10) > after).slice(0, limit);
  }
}

const STREAM_KEY = 'gcore:revalidation';
const MAX_ENTRIES = 1000;
const STREAM_TTL_MS = 7 * 24 * 3600_000;

/** Redis stream: XADD is atomic and ids are monotonic, so no counter or Lua script is needed. */
export class RedisRevalidationLog implements RevalidationLog {
  constructor(private readonly redis: Redis) {}

  async append(event: Omit<RevalidationEvent, 'id'>) {
    const fields = ['o', event.origin, 't', JSON.stringify(event.tags), ...(event.version !== undefined ? ['v', String(event.version)] : [])];
    await this.redis.xadd(STREAM_KEY, 'MAXLEN', '~', MAX_ENTRIES, '*', ...fields);
    await this.redis.pexpire(STREAM_KEY, STREAM_TTL_MS);
  }

  async head() {
    const rows = (await this.redis.xrevrange(STREAM_KEY, '+', '-', 'COUNT', 1)) as unknown as Array<[string, string[]]>;
    return rows[0]?.[0] ?? EMPTY_LOG_ID;
  }

  async readAfter(id: string, limit: number) {
    // XREAD returns entries with an id greater than the given one.
    const reply = (await this.redis.xread('COUNT', limit, 'STREAMS', STREAM_KEY, id)) as unknown as Array<[string, Array<[string, string[]]>]> | null;
    const rows = reply?.[0]?.[1] ?? [];
    return rows.flatMap(([entryId, flat]) => {
      const f = new Map<string, string>();
      for (let i = 0; i + 1 < flat.length; i += 2) f.set(flat[i]!, flat[i + 1]!);
      const tags = parseTags(f.get('t'));
      if (!tags) return []; // a malformed entry is skipped, never applied
      const version = f.has('v') ? Number(f.get('v')) : undefined;
      return [{ id: entryId, origin: f.get('o') ?? '', tags, ...(Number.isFinite(version) ? { version } : {}) }];
    });
  }
}

function parseTags(raw: string | undefined): string[] | null {
  if (!raw) return null;
  try {
    const v: unknown = JSON.parse(raw);
    return Array.isArray(v) && v.every((t) => typeof t === 'string') ? (v as string[]) : null;
  } catch {
    return null;
  }
}

const g = globalThis as unknown as { __revalidationLog?: RevalidationLog; __replicaId?: string };

/** One id per process, stamped on everything this replica announces so it can skip its own entries. */
export function replicaId(): string {
  return (g.__replicaId ??= randomUUID());
}

export function getRevalidationLog(): RevalidationLog {
  if (g.__revalidationLog) return g.__revalidationLog;
  const redis = getRedis();
  g.__revalidationLog = redis ? new RedisRevalidationLog(redis) : new MemoryRevalidationLog();
  return g.__revalidationLog;
}
