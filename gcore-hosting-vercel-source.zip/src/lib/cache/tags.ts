/**
 * Cache tags. `catalog`, `kind:*`, `location:*`, `plan:*` and `group:*` are precise (a sync revalidates only
 * what changed). `site` is on every cached loader and means "everything": used when a replica cannot know
 * what it missed (it booted from an image built from an older snapshot).
 */
export const SITE_TAG = 'site';

const TAG = /^(site|catalog|(plan|location):[a-z0-9-]{1,60}|kind:(vps|dedicated)|group:(vps|dedicated):[a-z0-9-]{1,120})$/;

export function isValidTag(tag: unknown): tag is string {
  return typeof tag === 'string' && TAG.test(tag);
}

export const TAG_PATTERN = TAG;
