import { revalidateTag } from 'next/cache';
import { resetCatalogMemo } from '@/lib/catalog/read';
import { log } from '@/lib/log';
import { Revalidator } from './revalidator';
import { getRevalidationLog, replicaId } from './revalidation-log';

/** Inside a request handler `revalidateTag` works. The memo is cleared first so regeneration reads the new snapshot. */
export function applyInRequest(tags: string[]): void {
  resetCatalogMemo();
  for (const tag of tags) revalidateTag(tag);
}

const g = globalThis as unknown as { __requestRevalidator?: Revalidator };

function requestRevalidator(): Revalidator {
  return (g.__requestRevalidator ??= new Revalidator({
    log: getRevalidationLog(),
    applyLocal: applyInRequest,
    replicaId: replicaId(),
    logger: log,
  }));
}

/** For internal endpoints: revalidate this replica and announce to the fleet. */
export const revalidateFleet = (tags: string[], version?: number) => requestRevalidator().announce(tags, version);
