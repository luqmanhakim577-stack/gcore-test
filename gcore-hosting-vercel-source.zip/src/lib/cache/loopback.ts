import { getEnv } from '@/lib/env';
import { signRequest } from '@/lib/security/hmac';

const PATH = '/api/internal/revalidate';

export interface LoopbackOptions {
  fetchImpl?: typeof fetch;
  baseUrl?: string;
  secret?: string;
}

/**
 * Revalidate this replica from background code. `revalidateTag` only works inside a request, so the
 * scheduler and the log poller send a signed request to the replica's own internal endpoint, scoped to
 * this replica ("local": it is not announced again).
 */
export function loopbackApply(opts: LoopbackOptions = {}): (tags: string[]) => Promise<void> {
  return async (tags) => {
    const secret = opts.secret ?? getEnv().REVALIDATE_HMAC_SECRET;
    if (!secret) throw new Error('REVALIDATE_HMAC_SECRET is not set: this replica cannot revalidate its own cache');
    const base = opts.baseUrl ?? process.env.INTERNAL_BASE_URL ?? `http://127.0.0.1:${process.env.PORT ?? 3000}`;
    const body = JSON.stringify({ tags, scope: 'local' });
    const res = await (opts.fetchImpl ?? fetch)(new URL(PATH, base), {
      method: 'POST',
      body,
      headers: { 'content-type': 'application/json', ...signRequest(secret, 'POST', PATH, body) },
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) throw new Error(`local revalidation answered ${res.status}`);
  };
}
