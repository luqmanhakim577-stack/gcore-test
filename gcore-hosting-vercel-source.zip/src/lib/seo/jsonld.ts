import type { BreadcrumbList, DefinedTermSet, FAQPage, ItemList, Offer, Organization, Product, PropertyValue, WebSite, WithContext } from 'schema-dts';
import type { Location, Plan } from '@/lib/catalog/model';
import { PERIODS, PERIOD_MONTHS, type PeriodKey } from '@/lib/catalog/money';
import { planPath } from '@/lib/catalog/views';
import { baseName, specRows } from '@/lib/format';
import { SITE_NAME } from '@/lib/site';
import { absoluteUrl, COMPANY, siteUrl } from './config';

/**
 * Typed JSON-LD builders (schema-dts checks property names at compile time). Every value comes from
 * the same normalized objects, and the same formatting helpers, as the visible HTML, so markup cannot
 * drift from what the page shows. Nothing is emitted that the page does not display.
 */

export const ORGANIZATION_ID = () => `${siteUrl()}/#organization`;
export const WEBSITE_ID = () => `${siteUrl()}/#website`;

export function organizationLd(): WithContext<Organization> {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': ORGANIZATION_ID(),
    name: COMPANY.name,
    url: COMPANY.url,
  };
}

export function websiteLd(): WithContext<WebSite> {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': WEBSITE_ID(),
    url: siteUrl(),
    name: SITE_NAME,
    inLanguage: 'en',
    publisher: { '@id': ORGANIZATION_ID() },
  };
}

export interface Crumb {
  label: string;
  /** Site path, including for the current (last) page. */
  href: string;
}

export function breadcrumbLd(items: Crumb[]): WithContext<BreadcrumbList> {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((c, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: c.label,
      item: absoluteUrl(c.href),
    })),
  };
}

export function itemListLd(name: string, items: Array<{ name: string; href: string }>): WithContext<ItemList> {
  return {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name,
    numberOfItems: items.length,
    itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, url: absoluteUrl(it.href) })),
  };
}

const PERIOD_NAME: Record<PeriodKey, string> = {
  monthly: 'Billed every month',
  quarterly: 'Billed every 3 months',
  semiannually: 'Billed every 6 months',
  annually: 'Billed every 12 months',
};

/**
 * Product + one Offer per billing period (the periods are different purchases, not a price range).
 * Call only for plans that are verified and orderable: the page itself shows no price otherwise.
 * Offer.url is the plan's canonical page (where the offer is displayed); the BILLmanager order link is in the HTML.
 */
export function productLd(plan: Plan, location: Location, description: string): WithContext<Product> {
  const url = absoluteUrl(planPath(plan));
  const offers: Offer[] = PERIODS.map((p) => ({
    '@type': 'Offer',
    name: PERIOD_NAME[p],
    price: plan.prices[p].amount,
    priceCurrency: plan.prices[p].currency,
    availability: 'https://schema.org/InStock',
    url,
    priceSpecification: {
      '@type': 'UnitPriceSpecification',
      price: plan.prices[p].amount,
      priceCurrency: plan.prices[p].currency,
      billingDuration: { '@type': 'QuantitativeValue', value: PERIOD_MONTHS[p], unitCode: 'MON' },
    },
    seller: { '@id': ORGANIZATION_ID() },
  }));

  const additionalProperty: PropertyValue[] = specRows(plan).map((r) => ({
    '@type': 'PropertyValue',
    name: r.label,
    value: r.value ?? r.text,
    ...(r.unit ? { unitText: r.unit } : {}),
  }));

  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    '@id': `${url}#product`,
    name: `${plan.kind === 'vps' ? 'VPS' : 'Dedicated server'} ${baseName(plan)} in ${location.city}`,
    description,
    sku: plan.id,
    category: plan.kind === 'vps' ? 'Virtual private server' : 'Dedicated server',
    url,
    brand: { '@type': 'Brand', name: COMPANY.name },
    additionalProperty,
    offers,
  };
}

/**
 * FAQPage from the same question/answer strings the page renders (visible, not collapsed away).
 * Google limits FAQ rich results to a few site types, so this is for other parsers and answer engines;
 * it makes no promise of a rich result or of being cited.
 */
export function faqLd(qa: Array<{ q: string; a: string }>): WithContext<FAQPage> {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: qa.map((x) => ({ '@type': 'Question', name: x.q, acceptedAnswer: { '@type': 'Answer', text: x.a } })),
  };
}

/** The glossary as a DefinedTermSet; every term is also visible on the page. */
export function definedTermSetLd(name: string, url: string, terms: Array<{ term: string; definition: string }>): WithContext<DefinedTermSet> {
  return {
    '@context': 'https://schema.org',
    '@type': 'DefinedTermSet',
    '@id': `${url}#terms`,
    name,
    url,
    publisher: { '@id': ORGANIZATION_ID() },
    hasDefinedTerm: terms.map((t) => ({ '@type': 'DefinedTerm', name: t.term, description: t.definition, inDefinedTermSet: `${url}#terms` })),
  };
}

/** Safe for inlining in HTML: no sequence in the output can close the script element or start a comment. */
export function serializeLd(data: unknown): string {
  return JSON.stringify(data).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}
