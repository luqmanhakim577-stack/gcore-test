/**
 * Site-wide SEO constants. One place for the origin, the locale list and the company identity, so
 * canonical URLs, hreflang, sitemap, robots and JSON-LD can never disagree.
 */
export const DEFAULT_SITE_URL = 'https://gcore.hosting';

/** Add a locale here (and translated content) to get hreflang for it everywhere. English only today. */
export const LOCALES = ['en'] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = 'en';

export const COMPANY = {
  name: 'Gcore',
  /** Corporate site. Legal name, address and contact details are not in any data source we have. */
  url: 'https://gcore.com',
} as const;

export function siteUrl(): string {
  return (process.env.SITE_URL || DEFAULT_SITE_URL).replace(/\/+$/, '');
}

/** Absolute canonical URL for a site path. "/" -> origin, "/vps" -> origin + "/vps". Never carries a query. */
export function absoluteUrl(pathname: string): string {
  const p = pathname.split(/[?#]/)[0] ?? '/';
  return p === '/' || p === '' ? siteUrl() : `${siteUrl()}${p.startsWith('/') ? p : `/${p}`}`;
}
