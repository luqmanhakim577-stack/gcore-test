import { LEARN, LEARN_UPDATED } from '@/content/learn';
import type { Catalog, Plan } from '@/lib/catalog/model';
import { listedPlans, locationPath, locationSummaries, locationsIndexView, planPath } from '@/lib/catalog/views';
import { KIND_BASE } from '@/lib/site';

export interface SitemapEntry {
  path: string;
  /** ISO timestamp of the last real content change among the plans the page shows. */
  lastModified: string;
}

const latest = (plans: Plan[], fallback: string): string =>
  plans.reduce((max, p) => (p.source.changedAt > max ? p.source.changedAt : max), plans[0]?.source.changedAt ?? fallback);

/**
 * Exactly the indexable pages: the ones that render prices from BILLmanager-confirmed plans.
 * Withheld plans, USD twins, query-string variants and API routes never appear here.
 * `lastModified` moves only when a plan on that page actually changed, not on every sync.
 */
export function sitemapEntries(catalog: Catalog): SitemapEntry[] {
  const out: SitemapEntry[] = [];
  const vps = listedPlans(catalog, 'vps');
  const ded = listedPlans(catalog, 'dedicated');
  const all = [...vps, ...ded];
  const fallback = catalog.generatedAt;

  out.push({ path: '/', lastModified: latest(all, fallback) });
  out.push({ path: KIND_BASE.vps, lastModified: latest(vps, fallback) });
  out.push({ path: KIND_BASE.dedicated, lastModified: latest(ded, fallback) });
  out.push({ path: '/locations', lastModified: latest(all, fallback) });

  for (const l of locationsIndexView(catalog).locations) {
    out.push({ path: `/locations/${l.location.slug}`, lastModified: latest(all.filter((p) => p.locationId === l.location.id), fallback) });
  }
  for (const kind of ['vps', 'dedicated'] as const) {
    for (const s of locationSummaries(catalog, kind)) {
      out.push({ path: locationPath(kind, s.location.slug), lastModified: latest(listedPlans(catalog, kind, s.location.id), fallback) });
    }
  }
  for (const p of all) out.push({ path: planPath(p), lastModified: p.source.changedAt });

  // Editorial pages: lastmod is the date of the last editorial revision, not the sync time.
  const at = (date: string) => `${date}T00:00:00.000Z`;
  out.push({ path: '/learn', lastModified: at(LEARN_UPDATED) });
  for (const a of LEARN) out.push({ path: `/learn/${a.slug}`, lastModified: at(a.updated) });
  out.push({ path: '/learn/glossary', lastModified: at(LEARN_UPDATED) });
  return out;
}
