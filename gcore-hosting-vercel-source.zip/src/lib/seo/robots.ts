import type { MetadataRoute } from 'next';
import { absoluteUrl } from './config';

/**
 * Crawler policy (decision D7: allow). Search and AI crawlers may read all public pages and the
 * public read-only API; only internal endpoints are off limits. Listing AI user agents explicitly
 * documents the policy; it does not change what `*` already permits. robots.txt is advisory, not access control.
 * Query-string variants are not blocked here on purpose: a blocked URL cannot show its canonical,
 * so they are served `noindex` + canonical by the middleware instead.
 */
export const AI_CRAWLERS = [
  'GPTBot',
  'OAI-SearchBot',
  'ChatGPT-User',
  'ClaudeBot',
  'Claude-SearchBot',
  'Claude-User',
  'PerplexityBot',
  'Perplexity-User',
  'Google-Extended',
  'Applebot-Extended',
] as const;

export const DISALLOWED = ['/api/internal/'];

export function robotsConfig(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: '*', allow: '/', disallow: DISALLOWED },
      ...AI_CRAWLERS.map((userAgent) => ({ userAgent, allow: '/', disallow: DISALLOWED })),
    ],
    sitemap: absoluteUrl('/sitemap.xml'),
  };
}
