import type { Metadata } from 'next';
import { DEFAULT_LOCALE, LOCALES } from './config';
import { SITE_NAME } from '@/lib/site';

/** canonical + hreflang (self-referencing per locale + x-default). Paths are relative to metadataBase. */
export function alternatesFor(pathname: string): NonNullable<Metadata['alternates']> {
  const languages: Record<string, string> = {};
  for (const l of LOCALES) languages[l] = pathname; // single locale today: no /{locale} prefix
  languages['x-default'] = pathname;
  return { canonical: pathname, languages };
}

/**
 * Unique, data-driven metadata for one indexable page. `title` is the page title (without the site
 * suffix); Open Graph and Twitter mirror it so social previews match what search shows.
 */
export function pageMetadata(opts: {
  pathname: string;
  title: string;
  description: string;
  /** true -> noindex,follow (e.g. plans whose pricing is withheld). */
  noindex?: boolean;
  absoluteTitle?: boolean;
}): Metadata {
  const { pathname, title, description } = opts;
  const full = opts.absoluteTitle ? title : `${title} | ${SITE_NAME}`;
  return {
    title: opts.absoluteTitle ? { absolute: title } : title,
    description,
    alternates: alternatesFor(pathname),
    robots: opts.noindex ? { index: false, follow: true } : undefined,
    openGraph: {
      type: 'website',
      siteName: SITE_NAME,
      title: full,
      description,
      url: pathname,
      locale: DEFAULT_LOCALE === 'en' ? 'en_US' : DEFAULT_LOCALE,
    },
    twitter: { card: 'summary', title: full, description },
  };
}
