import { planCodeOf } from '@/lib/catalog/locations';
import type { Disk, Plan, PlanSpecs, Traffic } from '@/lib/catalog/model';
import type { Money, PeriodKey } from '@/lib/catalog/money';

const moneyFmt = new Map<string, Intl.NumberFormat>();

/** "EUR 59.99" -> "€59.99". Deterministic on server and client. */
export function formatMoney(m: Money): string {
  let f = moneyFmt.get(m.currency);
  if (!f) {
    f = new Intl.NumberFormat('en', { style: 'currency', currency: m.currency, minimumFractionDigits: 2, maximumFractionDigits: 4 });
    moneyFmt.set(m.currency, f);
  }
  return f.format(Number(m.amount));
}

export const PERIOD_LABEL: Record<PeriodKey, string> = {
  monthly: '1 month',
  quarterly: '3 months',
  semiannually: '6 months',
  annually: '12 months',
};

export const PERIOD_UNIT: Record<PeriodKey, string> = {
  monthly: 'per month',
  quarterly: 'per 3 months',
  semiannually: 'per 6 months',
  annually: 'per year',
};

export function formatRam(mib?: number): string | undefined {
  if (mib === undefined) return undefined;
  return mib % 1024 === 0 ? `${mib / 1024} GB` : `${mib} MB`;
}

export function formatSize(gb: number): string {
  return gb >= 1000 && gb % 1000 === 0 ? `${gb / 1000} TB` : `${gb} GB`;
}

export function formatDisks(disks?: Disk[]): string | undefined {
  if (!disks?.length) return undefined;
  return disks.map((d) => `${d.count > 1 ? `${d.count} × ` : ''}${formatSize(d.sizeGB)} ${d.type}`).join(' + ');
}

export function formatPort(mbps?: number): string | undefined {
  if (mbps === undefined) return undefined;
  return mbps >= 1000 ? `${mbps / 1000} Gbit/s` : `${mbps} Mbit/s`;
}

export function formatTraffic(t?: Traffic): string | undefined {
  if (!t) return undefined;
  return t.kind === 'unlimited' ? 'Unmetered' : `${formatSize(t.includedGB)} included`;
}

export function formatCpu(s: PlanSpecs): string | undefined {
  if (!s.cpuModel) return undefined;
  return s.cpuSockets && s.cpuSockets > 1 ? `${s.cpuSockets} × ${s.cpuModel}` : s.cpuModel;
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('en', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(iso));
}

/** BILLmanager plan name without the trailing location code: KVM-SSD-1-FRN -> KVM-SSD-1. */
export function baseName(plan: Pick<Plan, 'name'>): string {
  const code = planCodeOf(plan.name);
  return code ? plan.name.slice(0, plan.name.length - code.length - 1) : plan.name;
}

/**
 * Specs we must not display because BILLmanager's own text contradicts the calc feed
 * (flag `spec-mismatch`). The page says "being verified" instead of guessing.
 */
const MISMATCH_FIELD: Record<string, 'vcpu' | 'ram' | 'port' | 'disk' | 'traffic'> = {
  vCPU: 'vcpu',
  'RAM MiB': 'ram',
  'port Mbit/s': 'port',
  'disk GB': 'disk',
  'disk type': 'disk',
  traffic: 'traffic',
};

export function withheldSpecs(plan: Pick<Plan, 'flags'>): Set<'vcpu' | 'ram' | 'port' | 'disk' | 'traffic'> {
  const out = new Set<'vcpu' | 'ram' | 'port' | 'disk' | 'traffic'>();
  for (const f of plan.flags) {
    if (f.code !== 'spec-mismatch' && f.code !== 'addon-spec-mismatch') continue;
    const field = MISMATCH_FIELD[f.message.split(':')[0] ?? ''];
    if (field) out.add(field);
  }
  return out;
}

export interface SpecRow {
  label: string;
  /** What the page displays. */
  text: string;
  /** Machine-readable form for structured data, when the spec is a single quantity. */
  value?: number;
  unit?: string;
}

/**
 * The specifications we are willing to show for a plan, in display order. The visible spec list and
 * the Product JSON-LD both render from this, so they cannot disagree. Withheld specs are absent.
 */
export function specRows(plan: Plan): SpecRow[] {
  const hide = withheldSpecs(plan);
  const s = plan.specs;
  const rows: SpecRow[] = [];
  const add = (r: SpecRow | null) => r && rows.push(r);

  if (plan.kind === 'vps') {
    if (!hide.has('vcpu') && s.vcpu !== undefined) add({ label: 'vCPU', text: String(s.vcpu), value: s.vcpu });
  } else {
    const cpu = formatCpu(s);
    if (cpu) add({ label: 'CPU', text: cpu });
  }
  if (!hide.has('ram') && s.ramMiB !== undefined) {
    const gb = s.ramMiB % 1024 === 0;
    add({ label: 'RAM', text: formatRam(s.ramMiB)!, value: gb ? s.ramMiB / 1024 : s.ramMiB, unit: gb ? 'GB' : 'MB' });
  }
  const disks = hide.has('disk') ? undefined : formatDisks(s.disks);
  if (disks) add({ label: plan.kind === 'vps' ? 'Disk' : 'Storage', text: disks });
  if (plan.kind === 'dedicated') {
    if (s.raid !== undefined) add({ label: 'RAID', text: s.raid ? 'Yes' : 'No' });
    if (s.gpu) add({ label: 'GPU', text: s.gpu });
  }
  if (!hide.has('port') && s.portMbps !== undefined) {
    const g = s.portMbps >= 1000;
    add({ label: 'Port speed', text: formatPort(s.portMbps)!, value: g ? s.portMbps / 1000 : s.portMbps, unit: g ? 'Gbit/s' : 'Mbit/s' });
  }
  const traffic = hide.has('traffic') ? undefined : formatTraffic(s.traffic);
  if (traffic) add({ label: 'Traffic', text: traffic });
  return rows;
}

/** One-line human summary, used in titles and descriptions. Only includes specs we are willing to show. */
export function specSummary(plan: Plan): string {
  const hide = withheldSpecs(plan);
  const s = plan.specs;
  const parts: Array<string | undefined> =
    plan.kind === 'vps'
      ? [
          !hide.has('vcpu') && s.vcpu !== undefined ? `${s.vcpu} vCPU` : undefined,
          !hide.has('ram') ? formatRam(s.ramMiB) && `${formatRam(s.ramMiB)} RAM` : undefined,
          !hide.has('disk') ? formatDisks(s.disks) : undefined,
        ]
      : [formatCpu(s), formatRam(s.ramMiB) && `${formatRam(s.ramMiB)} RAM`, formatDisks(s.disks), s.gpu && `GPU ${s.gpu}`];
  return parts.filter(Boolean).join(', ');
}
