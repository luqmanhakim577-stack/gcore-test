import { EVIDENCE_LABEL, describeScope, type OwnerFact } from '@/content/facts';
import { formatMoney, formatPort, formatSize } from '@/lib/format';
import { KIND_NOUN } from '@/lib/site';
import type { ProductKind } from '@/lib/catalog/model';
import type { CatalogFacts, KindFacts } from './catalog-facts';

/**
 * The only Gcore-specific statements on the editorial pages. Each is computed from the billing data
 * the site lists, or states plainly what the site does NOT publish, so an explainer can never be read
 * as a claim about Gcore's network, hardware or terms.
 */
export interface LearnBlock {
  heading: string;
  lines: string[];
}

const KINDS: ProductKind[] = ['vps', 'dedicated'];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
const list = (xs: string[]) => (xs.length <= 1 ? (xs[0] ?? '') : `${xs.slice(0, -1).join(', ')} and ${xs.at(-1)}`);

function trafficLine(kind: ProductKind, k: KindFacts): string {
  const t = k.traffic;
  const parts: string[] = [];
  if (t.unmetered) parts.push(`${plural(t.unmetered, 'plan')} with unmetered traffic`);
  if (t.metered) {
    const range =
      t.meteredGBMin !== undefined && t.meteredGBMax !== undefined
        ? t.meteredGBMin === t.meteredGBMax
          ? ` (${formatSize(t.meteredGBMin)} included)`
          : ` (from ${formatSize(t.meteredGBMin)} to ${formatSize(t.meteredGBMax)} included)`
        : '';
    parts.push(`${plural(t.metered, 'plan')} with a traffic allowance${range}`);
  }
  if (t.undisclosed) parts.push(`${plural(t.undisclosed, 'plan')} with no traffic information`);
  return `${cap(KIND_NOUN[kind])}: ${list(parts) || 'no traffic information'}.`;
}

function diskLine(kind: ProductKind, k: KindFacts): string {
  const types = Object.entries(k.diskTypes).sort((a, b) => b[1] - a[1]);
  const body = types.length ? list(types.map(([t, n]) => `${t} on ${plural(n, 'plan')}`)) : 'no drive information';
  return `${cap(KIND_NOUN[kind])}: ${body}${k.noDiskInfo ? `; ${plural(k.noDiskInfo, 'plan')} without drive information` : ''}.`;
}

function savingLine(kind: ProductKind, k: KindFacts): string {
  const s = k.annualSaving;
  const total = s.cheaper + s.notCheaper;
  if (!total) return `${cap(KIND_NOUN[kind])}: no plans listed.`;
  const range = s.minPercent !== undefined && s.maxPercent !== undefined ? `, by ${s.minPercent} to ${s.maxPercent} percent` : '';
  return `${cap(KIND_NOUN[kind])}: on ${s.cheaper} of ${total} plans the 12-month price is lower than twelve monthly payments${range}${s.notCheaper ? `; on ${s.notCheaper} it is not` : ''}.`;
}

export function learnBlock(slug: string, facts: CatalogFacts, owner: OwnerFact[]): LearnBlock | null {
  const v = facts.kinds.vps;
  const d = facts.kinds.dedicated;
  const asOf = `Billing data as of ${facts.generatedAt.slice(0, 10)}; prices in ${facts.currency}.`;

  switch (slug) {
    case 'vps-vs-dedicated-server':
      return {
        heading: 'In our catalog now',
        lines: [
          ...KINDS.map((kind) => {
            const k = facts.kinds[kind];
            return k.plans
              ? `${plural(k.plans, `${KIND_NOUN[kind]} plan`)} in ${plural(k.locations, 'location')}, from ${formatMoney(k.fromMonthly!)} per month.`
              : `No ${KIND_NOUN[kind]} plans are listed right now.`;
          }),
          'VPS plan pages list the vCPU count, RAM, disk, port speed and traffic. Dedicated server pages also list the CPU model and RAID where the billing data states them.',
          asOf,
        ],
      };
    case 'shared-vs-dedicated-cpu':
      return {
        heading: 'What this site states',
        lines: [
          v.withCpuModel
            ? `${v.withCpuModel} of ${v.plans} VPS plans list a CPU model.`
            : 'VPS plans on this site list a vCPU count only. This site does not state the CPU model or whether the vCPUs are shared, reserved or pinned, so none of that should be assumed.',
          `${d.withCpuModel} of ${d.plans} dedicated server plans list a CPU model.`,
          asOf,
        ],
      };
    case 'ssd-vs-nvme':
      return {
        heading: 'In our catalog now',
        lines: [
          'Drive types as the billing data states them (a plan with several drive types counts once for each):',
          ...KINDS.map((kind) => diskLine(kind, facts.kinds[kind])),
          'This site does not publish the drive interface or model, or measured IOPS or throughput, for any plan.',
          asOf,
        ],
      };
    case 'port-speed-vs-traffic':
      return {
        heading: 'In our catalog now',
        lines: [
          ...KINDS.map((kind) => {
            const k = facts.kinds[kind];
            return `${kind === 'vps' ? 'VPS' : 'Dedicated server'} port speeds listed: ${k.portMbps.length ? list(k.portMbps.map((m) => formatPort(m)!)) : 'none'}.`;
          }),
          ...KINDS.map((kind) => trafficLine(kind, facts.kinds[kind])),
          'This site does not state whether the capacity behind a port is shared or guaranteed, which direction counts against a traffic allowance, or the fair-use policy that applies to unmetered plans.',
          asOf,
        ],
      };
    case 'billing-periods-and-prices':
      return {
        heading: 'In our catalog now',
        lines: ['Every listed plan has a price for 1, 3, 6 and 12 months.', ...KINDS.map((kind) => savingLine(kind, facts.kinds[kind])), asOf],
      };
    case 'ddos-protection-explained':
      return owner.some((f) => f.topic === 'ddos')
        ? {
            heading: 'What Gcore has confirmed',
            lines: owner
              .filter((f) => f.topic === 'ddos')
              .map((f) => `${f.claim} Applies to: ${describeScope(f)}. Evidence: ${EVIDENCE_LABEL[f.evidence]} (${f.source}, checked ${f.verifiedOn}).${f.limitations ? ` Limits: ${f.limitations}` : ''}`),
          }
        : {
            heading: 'What this site states',
            lines: [
              'This site does not currently state a DDoS protection scope, capacity or guarantee for any plan or location, so none should be assumed. Confirm it with Gcore before relying on it.',
            ],
          };
    default:
      return null;
  }
}
