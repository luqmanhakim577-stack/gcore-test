import { PUBLIC_CACHE } from '@/lib/api/http';

/** Plain-text response for machine-readable site files. UTF-8, not sniffable, cacheable by shared caches. */
export function textResponse(body: string): Response {
  return new Response(body, {
    headers: {
      'content-type': 'text/plain; charset=utf-8',
      'x-content-type-options': 'nosniff',
      'cache-control': PUBLIC_CACHE,
    },
  });
}
