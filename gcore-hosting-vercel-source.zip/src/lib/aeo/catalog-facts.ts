import type { Catalog, ProductKind } from '@/lib/catalog/model';
import { dec, savingPercent, type Money } from '@/lib/catalog/money';
import { publicSpecs } from '@/lib/catalog/public';
import { listedPlans, locationSummaries } from '@/lib/catalog/views';

/**
 * Aggregates over the plans the site actually lists (billing-system confirmed, EUR, specs not withheld).
 * The editorial pages quote these numbers instead of hardcoding them, so they cannot go stale or
 * contradict the catalog. Plain JSON: safe to cache.
 */
export interface KindFacts {
  plans: number;
  locations: number;
  fromMonthly: Money | null;
  /** Plans listing at least one drive of this type, by the type the billing data states. */
  diskTypes: Record<string, number>;
  /** Plans with no disk information. */
  noDiskInfo: number;
  withCpuModel: number;
  traffic: { unmetered: number; metered: number; undisclosed: number; meteredGBMin?: number; meteredGBMax?: number };
  /** Distinct port speeds in Mbit/s, ascending. */
  portMbps: number[];
  /** Plans where the 12-month price is lower than 12 x the monthly price, and the range of that saving in percent. */
  annualSaving: { cheaper: number; notCheaper: number; minPercent?: number; maxPercent?: number };
}

export interface CatalogFacts {
  generatedAt: string;
  currency: 'EUR';
  kinds: Record<ProductKind, KindFacts>;
}

function kindFacts(catalog: Catalog, kind: ProductKind): KindFacts {
  const plans = listedPlans(catalog, kind);
  const diskTypes: Record<string, number> = {};
  const ports = new Set<number>();
  const traffic: KindFacts['traffic'] = { unmetered: 0, metered: 0, undisclosed: 0 };
  const saving: KindFacts['annualSaving'] = { cheaper: 0, notCheaper: 0 };
  let noDiskInfo = 0;
  let withCpuModel = 0;
  const meteredGB: number[] = [];
  const percents: number[] = [];

  for (const p of plans) {
    const s = publicSpecs(p);
    const types = new Set((s.disks ?? []).map((d) => d.type));
    if (types.size === 0) noDiskInfo++;
    for (const t of types) diskTypes[t] = (diskTypes[t] ?? 0) + 1;
    if (s.cpuModel) withCpuModel++;
    if (s.portMbps !== undefined) ports.add(s.portMbps);
    if (!s.traffic) traffic.undisclosed++;
    else if (s.traffic.kind === 'unlimited') traffic.unmetered++;
    else {
      traffic.metered++;
      meteredGB.push(s.traffic.includedGB);
    }
    const pct = savingPercent(p.prices.monthly, p.prices.annually, 'annually');
    if (dec(p.prices.annually).lt(dec(p.prices.monthly).mul(12))) {
      saving.cheaper++;
      percents.push(pct);
    } else saving.notCheaper++;
  }
  if (meteredGB.length) {
    traffic.meteredGBMin = Math.min(...meteredGB);
    traffic.meteredGBMax = Math.max(...meteredGB);
  }
  if (percents.length) {
    saving.minPercent = Math.min(...percents);
    saving.maxPercent = Math.max(...percents);
  }
  const from = plans.length ? plans.reduce((a, b) => (dec(b.prices.monthly).lt(dec(a.prices.monthly)) ? b : a)).prices.monthly : null;
  return {
    plans: plans.length,
    locations: locationSummaries(catalog, kind).length,
    fromMonthly: from,
    diskTypes,
    noDiskInfo,
    withCpuModel,
    traffic,
    portMbps: [...ports].sort((a, b) => a - b),
    annualSaving: saving,
  };
}

export function catalogFacts(catalog: Catalog): CatalogFacts {
  return { generatedAt: catalog.generatedAt, currency: 'EUR', kinds: { vps: kindFacts(catalog, 'vps'), dedicated: kindFacts(catalog, 'dedicated') } };
}
