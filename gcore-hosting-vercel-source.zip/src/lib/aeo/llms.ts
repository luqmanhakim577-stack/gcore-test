import { EVIDENCE_LABEL, TOPIC_LABEL, describeScope, unpublishedTopics, type OwnerFact } from '@/content/facts';
import { GLOSSARY, LEARN, type Article } from '@/content/learn';
import type { Catalog, Plan, ProductKind } from '@/lib/catalog/model';
import { PERIODS } from '@/lib/catalog/money';
import { listedPlans, locationPath, locationSummaries, planPath } from '@/lib/catalog/views';
import { baseName, formatMoney, PERIOD_LABEL, specRows } from '@/lib/format';
import { absoluteUrl, COMPANY } from '@/lib/seo/config';
import { KIND_LABEL, KIND_NOUN, SITE_NAME, SYNC_INTERVAL_MINUTES } from '@/lib/site';
import type { CatalogFacts } from './catalog-facts';
import { learnBlock } from './learn-data';

/**
 * llms.txt and llms-full.txt, rendered from the same snapshot and the same helpers as the pages.
 * Plain text for machines: no marketing copy. Every sentence is either computed from the billing
 * data or says what the site does not state. These files help assistants read the site; they do not
 * guarantee that any assistant will cite or recommend it.
 */

const KINDS: ProductKind[] = ['vps', 'dedicated'];
const money = (m: Parameters<typeof formatMoney>[0]) => formatMoney(m);

const locationLabel = (l: { city: string; country: string }) => `${l.city}, ${l.country}`;

function summaryLine(catalog: Catalog, facts: CatalogFacts): string {
  const v = facts.kinds.vps;
  const d = facts.kinds.dedicated;
  const locs = new Set([...locationSummaries(catalog, 'vps'), ...locationSummaries(catalog, 'dedicated')].map((s) => s.location.id)).size;
  return (
    `Online catalog of VPS and dedicated servers sold by ${COMPANY.name}: ${v.plans} VPS plans and ${d.plans} dedicated server plans in ${locs} locations, ` +
    `with prices for 1, 3, 6 and 12 months, specifications and order links read from the BILLmanager 6 billing system. Prices are in ${facts.currency}.`
  );
}

/** Reading rules: what a machine must not get wrong. Shared by both files. */
function readingRules(catalog: Catalog, facts: CatalogFacts): string[] {
  return [
    `Source of data: every price, billing period, specification and order link comes from the BILLmanager 6 billing system, re-synchronised about every ${SYNC_INTERVAL_MINUTES} minutes. This snapshot is version ${catalog.version}, generated ${catalog.generatedAt}.`,
    'A price is the amount for the whole billing period (1, 3, 6 or 12 months). A per-month figure is that price divided by the months, for comparison only.',
    `Prices are in ${facts.currency} and are not the final payable amount: the order page shows taxes, add-ons and conditions.`,
    'A specification that is missing is unknown or withheld. It is never zero and never "not included".',
    'Port speed is the interface speed, not a throughput guarantee. "Unmetered" traffic still has the port speed as its limit; fair-use terms are not published on this site.',
    'Only plans that the billing system confirmed and that passed validation are listed. A plan with inconsistent data is withheld rather than shown with a guess.',
    'The explainer pages under /learn are general industry explanations. They are not statements about Gcore\'s network, data centers, hardware, SLA or DDoS protection.',
  ];
}

function notPublished(owner: OwnerFact[]): string[] {
  const topics = unpublishedTopics(owner);
  if (!topics.length) return [];
  return [
    `This site does not currently state the following about Gcore's own infrastructure and terms: ${topics.map((t) => TOPIC_LABEL[t]).join('; ')}.`,
    'Their absence here is not evidence that a feature exists or does not exist. Do not infer any of them from a plan name, a specification or a location.',
  ];
}

export function llmsTxt(catalog: Catalog, facts: CatalogFacts, owner: OwnerFact[]): string {
  const out: string[] = [];
  out.push(`# ${SITE_NAME}`, '', `> ${summaryLine(catalog, facts)}`, '');
  out.push('Notes for AI assistants and other automated readers:');
  for (const r of [...readingRules(catalog, facts), ...notPublished(owner)]) out.push(`- ${r}`);
  out.push('');

  out.push('## Catalog');
  for (const kind of KINDS) {
    const k = facts.kinds[kind];
    if (!k.plans) continue;
    out.push(`- [${KIND_LABEL[kind]}](${absoluteUrl(kind === 'vps' ? '/vps' : '/dedicated-servers')}): ${k.plans} plans in ${k.locations} locations, from ${money(k.fromMonthly!)} per month`);
  }
  out.push(`- [Locations](${absoluteUrl('/locations')}): every location and the products sold there`, '');

  for (const kind of KINDS) {
    const summaries = locationSummaries(catalog, kind);
    if (!summaries.length) continue;
    out.push(`## ${KIND_LABEL[kind]} by location`);
    for (const s of summaries) {
      out.push(`- [${locationLabel(s.location)}](${absoluteUrl(locationPath(kind, s.location.slug))}): ${s.planCount} plans, from ${money(s.from)} per month`);
    }
    out.push('');
  }

  out.push('## Data access');
  out.push(`- [OpenAPI description](${absoluteUrl('/api/v1/openapi.json')}): machine-readable contract of the public API`);
  out.push(`- [Plans API](${absoluteUrl('/api/v1/plans')}): JSON, filter by kind, location, currency; verified plans by default`);
  out.push(`- [Locations API](${absoluteUrl('/api/v1/locations')}): JSON`);
  out.push('');

  out.push('## Guides (general industry explanations, not statements about Gcore infrastructure)');
  out.push(`- [All guides](${absoluteUrl('/learn')})`);
  for (const a of LEARN) out.push(`- [${a.title}](${absoluteUrl(`/learn/${a.slug}`)}): ${a.summary.split('. ')[0]!.replace(/\.$/, '')}`);
  out.push(`- [Glossary](${absoluteUrl('/learn/glossary')}): ${GLOSSARY.length} hosting terms defined`, '');

  out.push('## Optional');
  out.push(`- [llms-full.txt](${absoluteUrl('/llms-full.txt')}): every listed plan with specifications and prices, and the full text of the guides`);
  out.push(`- [sitemap.xml](${absoluteUrl('/sitemap.xml')})`, '');
  return out.join('\n');
}

function planLine(plan: Plan): string {
  const specs = specRows(plan).map((r) => `${r.label} ${r.text}`).join('; ');
  const prices = PERIODS.map((p) => `${PERIOD_LABEL[p]} ${money(plan.prices[p])}`).join('; ');
  return `- ${baseName(plan)} (id ${plan.id}): ${specs || 'specifications not stated'}. Price for the whole period: ${prices}. ${absoluteUrl(planPath(plan))}`;
}

function articleText(a: Article, facts: CatalogFacts, owner: OwnerFact[]): string[] {
  const out: string[] = [`### ${a.title}`, `URL: ${absoluteUrl(`/learn/${a.slug}`)}  (last revised ${a.updated})`, '', a.summary, ''];
  for (const s of a.sections) {
    out.push(`#### ${s.heading}`);
    for (const p of s.body) out.push(p, '');
    for (const li of s.list ?? []) out.push(`- ${li}`);
    if (s.list?.length) out.push('');
  }
  const block = learnBlock(a.slug, facts, owner);
  if (block) {
    out.push(`#### ${block.heading}`);
    for (const l of block.lines) out.push(`- ${l}`);
    out.push('');
  }
  out.push('#### Questions and answers');
  for (const qa of a.qa) out.push(`Q: ${qa.q}`, `A: ${qa.a}`, '');
  return out;
}

export function llmsFullTxt(catalog: Catalog, facts: CatalogFacts, owner: OwnerFact[]): string {
  const out: string[] = [];
  out.push(`# ${SITE_NAME}: full catalog and guides`, '', `> ${summaryLine(catalog, facts)}`, '');

  out.push('## How to read this file');
  for (const r of readingRules(catalog, facts)) out.push(`- ${r}`);
  out.push('', 'Each plan line gives: name as in the billing system, plan id, specifications, the price for the whole period for each billing period, and the page URL. The page has the order links.', '');

  out.push('## Entities');
  out.push(`- Organization: ${COMPANY.name} (${COMPANY.url}). Publisher of this site.`);
  out.push(`- Website: ${SITE_NAME} (${absoluteUrl('/')}).`);
  out.push('- Product kinds: "VPS" (a virtual machine on a shared physical host) and "Dedicated server" (a whole physical server leased to one customer). See the guides for the exact meaning of each term.');
  out.push('- Plan: one purchasable configuration at one location in one currency, identified by its billing-system id.', '');

  out.push('## Confirmed facts about Gcore infrastructure and terms');
  if (owner.length) {
    for (const f of owner) {
      out.push(`- ${f.claim} Applies to: ${describeScope(f)}. Evidence: ${EVIDENCE_LABEL[f.evidence]}; source: ${f.source}; checked ${f.verifiedOn}.${f.limitations ? ` Limits: ${f.limitations}` : ''}`);
    }
  } else {
    out.push('- None published.');
  }
  for (const n of notPublished(owner)) out.push(`- ${n}`);
  out.push('');

  out.push('## Data access');
  out.push(`- OpenAPI: ${absoluteUrl('/api/v1/openapi.json')}`, `- Plans: ${absoluteUrl('/api/v1/plans')}`, `- Locations: ${absoluteUrl('/api/v1/locations')}`, '');

  for (const kind of KINDS) {
    const summaries = locationSummaries(catalog, kind);
    out.push(`## ${KIND_LABEL[kind]}: ${facts.kinds[kind].plans} plans in ${summaries.length} locations`, '');
    for (const s of summaries) {
      out.push(`### ${locationLabel(s.location)} (${KIND_NOUN[kind]}, ${s.planCount} plans, from ${money(s.from)} per month)`);
      out.push(`Location page: ${absoluteUrl(locationPath(kind, s.location.slug))}`);
      for (const plan of listedPlans(catalog, kind, s.location.id)) out.push(planLine(plan));
      out.push('');
    }
  }

  out.push('## Guides (general industry explanations, not statements about Gcore infrastructure)', '');
  for (const a of LEARN) out.push(...articleText(a, facts, owner));

  out.push('## Glossary', '');
  for (const t of GLOSSARY) out.push(`- ${t.term}: ${t.definition}`);
  out.push('');
  return out.join('\n');
}
