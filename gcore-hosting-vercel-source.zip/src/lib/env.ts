import { z } from 'zod';

const schema = z.object({
  SITE_URL: z.string().url().default('https://gcore.hosting'),
  CALC_API_BASE_URL: z.string().url().default('https://hosting-calc-prod.i.gc.onl'),
  BILLMANAGER_BASE_URL: z.string().url().default('https://hosting.gcore.com'),
  S2_CURRENCIES: z.string().default('EUR'),
  REDIS_URL: z.string().optional(),
  REVALIDATE_HMAC_SECRET: z.string().min(32, 'must be at least 32 characters').optional(),
  SYNC_S2_BATCH_SIZE: z.coerce.number().int().min(1).max(10).default(5),
  SYNC_S2_CONCURRENCY: z.coerce.number().int().min(1).max(4).default(2),
  SYNC_S2_MAX_AGE_HOURS: z.coerce.number().positive().default(6),
  SYNC_MAX_DROP_RATIO: z.coerce.number().min(0).max(1).default(0.2),
  /** "on": configurator order links carry addon_<id>=<value>. Keep "off" until a real test order proves BILLmanager honours them. */
  ORDER_ADDON_PARAMS: z.enum(['on', 'off']).default('off'),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  /** Local smoke tests of a production build only: read the file snapshot instead of Redis. Never set in production. */
  ALLOW_FILE_STORE: z.enum(['1']).optional(),
  /** Where a replica reaches its own server for background revalidation (default http://127.0.0.1:$PORT). */
  INTERNAL_BASE_URL: z.string().url().optional(),
  /**
   * Reverse proxies in front of the app that each append the address they saw to X-Forwarded-For (CDN, load
   * balancer). The client address is the entry that many positions from the right; anything to its left was
   * supplied by the client and is ignored.
   */
  TRUSTED_PROXY_HOPS: z.coerce.number().int().min(0).max(5).default(1),
});

export type Env = Omit<z.infer<typeof schema>, 'S2_CURRENCIES'> & {
  S2_CURRENCIES: Array<'EUR' | 'USD'>;
};

/** What a production process cannot run without. Empty when the configuration is complete. */
export function productionConfigProblems(env: Env): string[] {
  const problems: string[] = [];
  if (!env.REDIS_URL && env.ALLOW_FILE_STORE !== '1') problems.push('REDIS_URL is required (snapshot store, rate limits, replay protection, replica coordination)');
  if (!env.REVALIDATE_HMAC_SECRET) problems.push('REVALIDATE_HMAC_SECRET (at least 32 characters) is required: replicas refresh their page cache through signed internal requests');
  const site = new URL(env.SITE_URL);
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(site.hostname);
  if (site.protocol !== 'https:' && !local) problems.push(`SITE_URL must be https (canonical URLs, sitemap and structured data are built from it), got ${env.SITE_URL}`);
  return problems;
}

/** Fail fast at boot: a half-configured production replica would otherwise only fail on its first request. */
export function assertProductionConfig(env: Env = getEnv()): void {
  const problems = productionConfigProblems(env);
  if (problems.length) throw new Error(`Invalid production configuration:\n- ${problems.join('\n- ')}`);
}

let cached: Env | undefined;

/** Tests only: drop the memoized environment so changed process.env values are re-read. */
export function resetEnvCache(): void {
  cached = undefined;
}

/** Parse and validate server-side environment once. Never import this from client components. */
export function getEnv(source: NodeJS.ProcessEnv = process.env): Env {
  if (source === process.env && cached) return cached;
  // Treat empty strings (e.g. "REDIS_URL=" in .env) as unset.
  const raw = Object.fromEntries(Object.entries(source).filter(([, v]) => v !== undefined && v !== ''));
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    throw new Error(`Invalid environment configuration:\n${z.prettifyError(parsed.error)}`);
  }
  const currencies = parsed.data.S2_CURRENCIES.split(',')
    .map((c) => c.trim().toUpperCase())
    .filter(Boolean);
  const validCurrencies = z.array(z.enum(['EUR', 'USD'])).safeParse(currencies);
  if (!validCurrencies.success) {
    throw new Error(`Invalid environment configuration: S2_CURRENCIES must be a list of EUR/USD, got "${parsed.data.S2_CURRENCIES}"`);
  }
  const env: Env = { ...parsed.data, S2_CURRENCIES: validCurrencies.data };
  if (source === process.env) cached = env;
  return env;
}
