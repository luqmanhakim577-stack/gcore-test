import type { CalcRow } from '@/lib/billmanager/calc-feed';
import { annotatePlans } from './annotate';
import { hashOf } from './hash';
import { buildLocations, planCodeOf, type LocationSource } from './locations';
import { CATALOG_SCHEMA, type Catalog, type CatalogStats, type Plan, type ProductKind } from './model';
import { normalizePlan, type S2State } from './normalize';

export interface BuildInput {
  feeds: Array<{ kind: ProductKind; rows: CalcRow[]; fetchedAt: string }>;
  /** BILLmanager state per plan id; ids missing here are treated as not-attempted. */
  s2: Map<string, S2State>;
  billmanagerBaseUrl: string;
  version: number;
  now: string;
}

/** Pure: feeds + BILLmanager detail -> normalized, annotated catalog. */
export function buildCatalog(input: BuildInput): Catalog {
  const plans: Plan[] = [];
  const locationSources: LocationSource[] = [];

  for (const feed of input.feeds) {
    for (const row of feed.rows) {
      plans.push(
        normalizePlan({
          kind: feed.kind,
          row,
          s1At: feed.fetchedAt,
          s2: input.s2.get(row.id) ?? { status: 'not-attempted' },
          billmanagerBaseUrl: input.billmanagerBaseUrl,
        }),
      );
      locationSources.push({
        country: row.country,
        dataCenter: row.data_center,
        code: planCodeOf(row.name),
        kind: feed.kind,
      });
    }
  }

  return finalizeCatalog(plans, buildLocations(locationSources), input.version, input.now);
}

/** Annotate, re-hash (flags are part of the published state) and compute stats. */
export function finalizeCatalog(plans: Plan[], locations: Catalog['locations'], version: number, now: string): Catalog {
  annotatePlans(plans);
  for (const p of plans) p.source.hash = hashOf({ ...p, source: undefined });
  plans.sort((a, b) => a.kind.localeCompare(b.kind) || a.locationId.localeCompare(b.locationId) || a.name.localeCompare(b.name) || a.currency.localeCompare(b.currency));

  return { schema: CATALOG_SCHEMA, version, generatedAt: now, plans, locations, stats: computeStats(plans) };
}

export function computeStats(plans: Plan[]): CatalogStats {
  const count = (k: ProductKind) => plans.filter((p) => p.kind === k).length;
  return {
    plans: plans.length,
    byKind: { vps: count('vps'), dedicated: count('dedicated') },
    orderable: plans.filter((p) => p.availability === 'orderable').length,
    unknown: plans.filter((p) => p.availability === 'unknown').length,
    flagged: plans.filter((p) => p.flags.some((f) => f.severity !== 'info')).length,
  };
}
