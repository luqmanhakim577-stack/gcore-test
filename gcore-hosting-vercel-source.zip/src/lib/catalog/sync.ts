import { fetchCalcFeed, type CalcFeedResult } from '@/lib/billmanager/calc-feed';
import { fetchPricelists, type PricelistClientConfig } from '@/lib/billmanager/pricelist-client';
import { getEnv } from '@/lib/env';
import { buildCatalog, computeStats } from './build';
import { diffCatalogs, tagsForDiff, type CatalogDiff } from './diff';
import { hashOf } from './hash';
import { CATALOG_SCHEMA, type Catalog, type CatalogMeta, type Plan, type ProductKind } from './model';
import type { Currency } from './money';
import type { S2State } from './normalize';
import type { CatalogStore } from './store';

type Logger = {
  info: (o: object, msg?: string) => void;
  warn: (o: object, msg?: string) => void;
  error: (o: object, msg?: string) => void;
};

export interface SyncConfig {
  calcBaseUrl: string;
  billmanagerBaseUrl: string;
  s2Currencies: Currency[];
  s2BatchSize: number;
  s2Concurrency: number;
  /** BILLmanager detail older than this is refetched even if the calc feed row is unchanged. */
  s2MaxAgeMs: number;
  maxDropRatio: number;
  /** Retry backoff for BILLmanager requests (tests set 0). */
  s2BackoffMs?: number;
  fetchImpl?: typeof fetch;
  now?: () => Date;
  log?: Logger;
}

export function syncConfigFromEnv(log?: Logger): SyncConfig {
  const env = getEnv();
  return {
    calcBaseUrl: env.CALC_API_BASE_URL,
    billmanagerBaseUrl: env.BILLMANAGER_BASE_URL,
    s2Currencies: env.S2_CURRENCIES,
    s2BatchSize: env.SYNC_S2_BATCH_SIZE,
    s2Concurrency: env.SYNC_S2_CONCURRENCY,
    s2MaxAgeMs: env.SYNC_S2_MAX_AGE_HOURS * 3600_000,
    maxDropRatio: env.SYNC_MAX_DROP_RATIO,
    log,
  };
}

export type SyncOutcome =
  | { status: 'published'; catalog: Catalog; diff: CatalogDiff; tags: string[] }
  /** Nothing changed commercially. `refreshed` is true when BILLmanager detail timestamps were renewed. */
  | { status: 'unchanged'; version: number; refreshed: boolean }
  | { status: 'locked' }
  | { status: 'rejected'; reason: string }
  | { status: 'failed'; reason: string };

const KINDS: ProductKind[] = ['vps', 'dedicated'];
const LOCK_TTL_MS = 10 * 60_000;

/**
 * S1 index -> S2 detail (incremental) -> normalize/reconcile -> validate -> publish.
 * On any failure the previous snapshot stays live.
 *
 * Incremental rule: a plan's BILLmanager detail is reused only when its S1 row is byte-identical
 * (same hash) AND the detail is younger than `s2MaxAgeMs`. Any S1 change triggers a refetch, so
 * new prices are never published alongside stale availability/order links.
 */
export async function runSync(store: CatalogStore, cfg: SyncConfig, opts: { force?: boolean } = {}): Promise<SyncOutcome> {
  const now = cfg.now ?? (() => new Date());
  const log = cfg.log;
  const token = await store.acquireLock(LOCK_TTL_MS);
  if (!token) return { status: 'locked' };

  try {
    const prev = await store.getLive();
    const prevMeta = await store.getMeta();
    const fail = async (status: 'failed' | 'rejected', reason: string): Promise<SyncOutcome> => {
      const at = now().toISOString();
      log?.error({ reason }, `sync ${status}`);
      await store.setMeta({
        version: prevMeta?.version ?? prev?.version ?? 0,
        lastCheckedAt: at,
        lastPublishedAt: prevMeta?.lastPublishedAt ?? '',
        lastError: { at, message: reason },
      });
      return { status, reason };
    };

    // 1. S1: complete index. Any shape problem aborts and keeps the old snapshot.
    let feeds: CalcFeedResult[];
    try {
      feeds = await Promise.all(
        KINDS.map((kind) => fetchCalcFeed(kind, { baseUrl: cfg.calcBaseUrl, fetchImpl: cfg.fetchImpl })),
      );
    } catch (e) {
      return fail('failed', `calc feed: ${(e as Error).message}`);
    }
    const total = feeds.reduce((n, f) => n + f.rows.length, 0);
    if (prev && total < prev.plans.length * (1 - cfg.maxDropRatio)) {
      return fail('rejected', `calc feed shrank from ${prev.plans.length} to ${total} plans (limit ${cfg.maxDropRatio * 100}%)`);
    }

    // 2. Decide which plans need BILLmanager detail.
    const nowMs = now().getTime();
    const prevById = new Map((prev?.plans ?? []).map((p) => [p.id, p]));
    // A snapshot written by older code may lack fields the current code relies on: never reuse its detail.
    const schemaStale = prev !== null && prev.schema !== CATALOG_SCHEMA;
    if (schemaStale) log?.warn({ stored: prev?.schema, current: CATALOG_SCHEMA }, 'snapshot schema changed: refetching all BILLmanager detail');
    const s2 = new Map<string, S2State>();
    const reused = new Map<string, Plan>();
    const toFetch: string[] = [];

    for (const feed of feeds) {
      for (const row of feed.rows) {
        if (!cfg.s2Currencies.includes(row.server_price.currency)) {
          s2.set(row.id, { status: 'not-attempted' });
          continue;
        }
        const old = prevById.get(row.id);
        const checked = old?.source.s2CheckedAt;
        const detailFresh = checked !== undefined && nowMs - new Date(checked).getTime() < cfg.s2MaxAgeMs;
        const definitive = old?.source.s2Status === 'ok' || old?.source.s2Status === 'not-public';
        const sameRow = old?.source.s1Hash === hashOf(row);
        if (old && !opts.force && !schemaStale && detailFresh && definitive && sameRow) reused.set(row.id, old);
        else toFetch.push(row.id);
      }
    }

    const clientCfg: PricelistClientConfig = {
      baseUrl: cfg.billmanagerBaseUrl,
      batchSize: cfg.s2BatchSize,
      concurrency: cfg.s2Concurrency,
      backoffMs: cfg.s2BackoffMs,
      fetchImpl: cfg.fetchImpl,
      onEvent: (e) => log?.warn({ event: e.type, idCount: e.ids?.length, detail: e.detail }, 'pricelist.export'),
    };
    const fetched = await fetchPricelists(toFetch, clientCfg);
    const at = now().toISOString();
    for (const id of toFetch) {
      const plan = fetched.plans.get(id);
      if (plan) s2.set(id, { status: 'ok', plan, at });
      else if (fetched.notPublic.has(id)) s2.set(id, { status: 'not-public', at });
      else s2.set(id, { status: 'failed' });
    }

    // 3. Normalize + reconcile.
    const version = (prevMeta?.version ?? prev?.version ?? 0) + 1;
    const next = buildCatalog({
      feeds: feeds.map((f) => ({ kind: f.kind, rows: f.rows, fetchedAt: f.fetchedAt })),
      s2,
      billmanagerBaseUrl: cfg.billmanagerBaseUrl,
      version,
      now: at,
    });
    reuseDetail(next, schemaStale ? new Map() : prevById, reused, s2); // old-schema plans are never carried over
    stampChangedAt(next, prevById, at);

    // 4. Publish. A refetch that changed nothing still renews s2At (silently), otherwise the same
    //    plans would be refetched on every run once their detail ages out.
    const diff = diffCatalogs(prev, next);
    const refreshedDetail = toFetch.length > 0 && (fetched.plans.size > 0 || fetched.notPublic.size > 0);
    const meta = (publishedNow: boolean): CatalogMeta => ({
      version: publishedNow ? next.version : (prev?.version ?? next.version),
      lastCheckedAt: at,
      lastPublishedAt: publishedNow ? at : (prevMeta?.lastPublishedAt ?? at),
    });

    if (diff.empty && prev && !opts.force) {
      if (!refreshedDetail) {
        await store.setMeta(meta(false));
        log?.info({ version: prev.version, plans: next.plans.length }, 'sync: no changes');
        return { status: 'unchanged', version: prev.version, refreshed: false };
      }
      await store.publish(next, meta(true));
      log?.info({ version: next.version, s2Fetched: toFetch.length }, 'sync: detail refreshed, no content change');
      return { status: 'unchanged', version: next.version, refreshed: true };
    }

    await store.publish(next, meta(true));
    const tags = tagsForDiff(diff);
    log?.info(
      { version: next.version, added: diff.added.length, removed: diff.removed.length, changed: diff.changed.length, s2Fetched: toFetch.length, s2Reused: reused.size },
      'sync: published',
    );
    return { status: 'published', catalog: next, diff, tags };
  } catch (e) {
    const reason = (e as Error).message;
    log?.error({ reason }, 'sync failed');
    try {
      const at = now().toISOString();
      const prevMeta = await store.getMeta();
      await store.setMeta({
        version: prevMeta?.version ?? 0,
        lastCheckedAt: at,
        lastPublishedAt: prevMeta?.lastPublishedAt ?? '',
        lastError: { at, message: reason },
      });
    } catch {
      /* the store itself is down; the original error is what matters */
    }
    return { status: 'failed', reason };
  } finally {
    await store.releaseLock(token);
  }
}

/** A plan keeps its previous `changedAt` unless its content hash changed (or it is new). */
function stampChangedAt(next: Catalog, prevById: Map<string, Plan>, now: string): void {
  for (const plan of next.plans) {
    const old = prevById.get(plan.id);
    plan.source.changedAt = old && old.source.hash === plan.source.hash ? (old.source.changedAt ?? old.source.s1At) : now;
  }
}

/**
 * - Reused plans (unchanged row, fresh detail): take the previous plan as-is.
 * - Plans whose BILLmanager fetch failed this round but whose S1 row is unchanged: keep the previous
 *   detail and mark it `s2-stale`, so a transient outage does not flip orderable plans to unknown.
 * - Plans whose row changed and whose fetch failed stay unconfirmed: new prices are never mixed
 *   with old availability or order links.
 */
function reuseDetail(next: Catalog, prevById: Map<string, Plan>, reused: Map<string, Plan>, s2: Map<string, S2State>): void {
  next.plans = next.plans.map((plan) => {
    const old = prevById.get(plan.id);
    if (!old) return plan;
    if (reused.has(plan.id)) return { ...old, source: { ...old.source, s1At: plan.source.s1At } };
    if (s2.get(plan.id)?.status === 'failed' && old.source.s1Hash === plan.source.s1Hash && old.availability !== 'unknown') {
      const flags = [
        ...old.flags.filter((f) => f.code !== 's2-stale'),
        { severity: 'info' as const, code: 's2-stale', message: 'BILLmanager detail is from an earlier sync (fetch failed this round)' },
      ];
      return { ...old, flags, source: { ...old.source, s1At: plan.source.s1At } };
    }
    return plan;
  });
  next.stats = computeStats(next.plans);
}
