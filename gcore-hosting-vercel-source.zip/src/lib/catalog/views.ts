import { isVerified } from './public';
import type { Catalog, Location, Plan, ProductKind } from './model';
import { dec, type Currency, type Money } from './money';
import { KIND_BASE } from '@/lib/site';

/**
 * Pure view-models for pages. They take a catalog snapshot and return plain JSON, so they are
 * trivial to test and safe to cache. Rules enforced here, once, for every page:
 *  - only plans BILLmanager confirmed (verified) and in the display currency are listed or priced
 *  - "from" prices are computed only from those plans
 */
export const DISPLAY_CURRENCY: Currency = 'EUR';

const listed = (p: Plan) => p.currency === DISPLAY_CURRENCY && isVerified(p);
const byMonthly = (a: Plan, b: Plan) => dec(a.prices.monthly).cmp(dec(b.prices.monthly)) || a.name.localeCompare(b.name);
const cheapest = (plans: Plan[]): Money | null => (plans.length ? [...plans].sort(byMonthly)[0]!.prices.monthly : null);

export function listedPlans(catalog: Catalog, kind: ProductKind, locationId?: string): Plan[] {
  return catalog.plans.filter((p) => p.kind === kind && listed(p) && (!locationId || p.locationId === locationId)).sort(byMonthly);
}

export interface LocationSummary {
  location: Location;
  planCount: number;
  from: Money;
}

export function locationSummaries(catalog: Catalog, kind: ProductKind): LocationSummary[] {
  const out: LocationSummary[] = [];
  for (const location of catalog.locations) {
    const plans = listedPlans(catalog, kind, location.id);
    const from = cheapest(plans);
    if (from) out.push({ location, planCount: plans.length, from });
  }
  return out.sort((a, b) => a.location.country.localeCompare(b.location.country) || a.location.city.localeCompare(b.location.city));
}

export interface HubView {
  kind: ProductKind;
  locations: LocationSummary[];
  planCount: number;
  from: Money | null;
  generatedAt: string;
}

export function hubView(catalog: Catalog, kind: ProductKind): HubView {
  const plans = listedPlans(catalog, kind);
  return { kind, locations: locationSummaries(catalog, kind), planCount: plans.length, from: cheapest(plans), generatedAt: catalog.generatedAt };
}

export interface LocationPageView {
  kind: ProductKind;
  location: Location;
  plans: Plan[];
  from: Money;
  otherLocations: LocationSummary[];
  generatedAt: string;
}

export function locationPageView(catalog: Catalog, kind: ProductKind, slug: string): LocationPageView | null {
  const location = catalog.locations.find((l) => l.slug === slug);
  if (!location) return null;
  const plans = listedPlans(catalog, kind, location.id);
  const from = cheapest(plans);
  if (!from) return null;
  return {
    kind,
    location,
    plans,
    from,
    otherLocations: locationSummaries(catalog, kind).filter((s) => s.location.id !== location.id),
    generatedAt: catalog.generatedAt,
  };
}

export interface PlanPageView {
  plan: Plan;
  location: Location;
  /** Priced and orderable. Otherwise the page shows no price and no order button. */
  orderable: boolean;
  siblingsHere: Plan[];
  elsewhere: Array<{ plan: Plan; location: Location }>;
  generatedAt: string;
}

/** Identity of a plan page: the BILLmanager id, plus the slug used for the canonical URL. */
export function planKey(catalog: Catalog, kind: ProductKind, id: string): { plan: Plan; location: Location } | null {
  const plan = catalog.plans.find((p) => p.id === id);
  if (!plan || plan.kind !== kind || plan.currency !== DISPLAY_CURRENCY) return null;
  const location = catalog.locations.find((l) => l.id === plan.locationId);
  return location ? { plan, location } : null;
}

export function planPageView(catalog: Catalog, kind: ProductKind, id: string): PlanPageView | null {
  const key = planKey(catalog, kind, id);
  if (!key) return null;
  const { plan, location } = key;
  const locations = new Map(catalog.locations.map((l) => [l.id, l]));
  const siblingsHere = listedPlans(catalog, kind, location.id).filter((p) => p.id !== plan.id);
  const elsewhere = listedPlans(catalog, kind)
    .filter((p) => p.slug === plan.slug && p.locationId !== plan.locationId)
    .flatMap((p) => {
      const l = locations.get(p.locationId);
      return l ? [{ plan: p, location: l }] : [];
    });
  return { plan, location, orderable: listed(plan), siblingsHere, elsewhere, generatedAt: catalog.generatedAt };
}

export interface HomeView {
  hubs: Record<ProductKind, HubView>;
  locations: Array<{ location: Location; kinds: Array<{ kind: ProductKind; planCount: number; from: Money }> }>;
  generatedAt: string;
}

export function homeView(catalog: Catalog): HomeView {
  const hubs = { vps: hubView(catalog, 'vps'), dedicated: hubView(catalog, 'dedicated') };
  return { hubs, locations: locationsIndexView(catalog).locations, generatedAt: catalog.generatedAt };
}

export function locationsIndexView(catalog: Catalog): Pick<HomeView, 'locations'> & { generatedAt: string } {
  const locations = catalog.locations
    .map((location) => ({
      location,
      kinds: (['vps', 'dedicated'] as const).flatMap((kind) => {
        const plans = listedPlans(catalog, kind, location.id);
        const from = cheapest(plans);
        return from ? [{ kind, planCount: plans.length, from }] : [];
      }),
    }))
    .filter((l) => l.kinds.length > 0)
    .sort((a, b) => a.location.country.localeCompare(b.location.country) || a.location.city.localeCompare(b.location.city));
  return { locations, generatedAt: catalog.generatedAt };
}

export function locationDetailView(catalog: Catalog, slug: string) {
  const entry = locationsIndexView(catalog).locations.find((l) => l.location.slug === slug);
  return entry ? { ...entry, generatedAt: catalog.generatedAt } : null;
}

// ---- URLs -----------------------------------------------------------------------------------

export function planPath(plan: Pick<Plan, 'kind' | 'locationId' | 'slug' | 'id'>): string {
  return `${KIND_BASE[plan.kind]}/${plan.locationId}/${plan.slug}-${plan.id}`;
}

/** `kvm-ssd-1-175055` -> { slug: 'kvm-ssd-1', id: '175055' } */
export function parsePlanParam(param: string): { slug: string; id: string } | null {
  const m = /^([a-z0-9-]+)-(\d{1,12})$/.exec(param);
  return m ? { slug: m[1]!, id: m[2]! } : null;
}

export function locationPath(kind: ProductKind, locationId: string): string {
  return `${KIND_BASE[kind]}/${locationId}`;
}

/** Everything that should exist as a static page. */
export function staticParams(catalog: Catalog) {
  const plans = (['vps', 'dedicated'] as const).flatMap((kind) =>
    listedPlans(catalog, kind).map((p) => ({ kind, location: p.locationId, plan: `${p.slug}-${p.id}` })),
  );
  const locations = (['vps', 'dedicated'] as const).flatMap((kind) =>
    locationSummaries(catalog, kind).map((s) => ({ kind, location: s.location.slug })),
  );
  return { plans, locations, locationSlugs: locationsIndexView(catalog).locations.map((l) => l.location.slug) };
}
