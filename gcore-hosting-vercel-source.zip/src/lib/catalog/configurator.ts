import type { Addon, Plan } from './model';
import { fxAdd, fxMulInt, fxToString, toFx } from './fx';
import { PERIODS, type Currency, type PeriodKey } from './periods';

/**
 * Product configurator: which BILLmanager add-ons a customer may choose, what they cost, and how to
 * express the choice in an order link. Pure and dependency-free (no decimal library, no React), so
 * the server renders the initial state and the browser recomputes with the same code.
 *
 * What is modelled, and why it is safe (verified against the live BILLmanager data, ARCHITECTURE.md):
 *  - quantity add-ons: "Based on order", integer, in pieces (extra IPv4/IPv6 addresses). BILLmanager's
 *    `addonlimit` ("Tariff plan includes") is already in the plan price; each further step costs the
 *    add-on's period price. The period price is used as given, never monthly x months.
 *  - traffic tiers (dedicated): "Client can choose" children of a parent traffic add-on; exactly one
 *    tier applies; the zero-priced tier is what the plan price already includes.
 * Not modelled (not changeable, or meaning unverified): disk/RAM/vCPU (billed as "Do not bill", fixed to the
 * plan), OS and licences, the burst-billed unlimited-traffic option, boolean options.
 */

export interface QuantityControl {
  id: string;
  label: string;
  included: number;
  step: number;
  max: number;
  /** Price of ONE additional step, per billing period. */
  unitPrices: Record<PeriodKey, string>;
}

export interface TrafficChoice {
  id: string;
  /** BILLmanager's own wording, shown verbatim (it states the included traffic and the overage price). */
  label: string;
  /** Surcharge on top of the plan price, per billing period. Zero for the tier the plan already includes. */
  prices: Record<PeriodKey, string>;
}

export interface TrafficControl {
  /** The parent add-on that the order link addresses (`addon_<parentId>=<choiceId>`). */
  parentId: string;
  defaultId: string;
  choices: TrafficChoice[];
}

export interface ConfigModel {
  currency: Currency;
  quantities: QuantityControl[];
  traffic: TrafficControl | null;
  /** VPS only: disk, RAM and vCPU are included in the plan and cannot be changed individually. */
  fixedResources: boolean;
}

export interface Selection {
  quantities: Record<string, number>;
  traffic?: string;
}

export class SelectionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SelectionError';
  }
}

const ID = /^\d{1,12}$/;

function allPeriods(prices: Addon['prices']): Record<PeriodKey, string> | null {
  const out = {} as Record<PeriodKey, string>;
  for (const p of PERIODS) {
    const v = prices[p];
    if (v === undefined) return null;
    out[p] = v;
  }
  return out;
}

const positive = (r: Record<PeriodKey, string>) => PERIODS.every((p) => toFx(r[p]) > 0n);
const zero = (r: Record<PeriodKey, string>) => PERIODS.every((p) => toFx(r[p]) === 0n);

function quantityControls(addons: Addon[]): QuantityControl[] {
  const out: QuantityControl[] = [];
  for (const a of addons) {
    if (a.type !== '2' || a.billType !== '2' || a.unit !== 'pcs') continue;
    if (!ID.test(a.id) || a.included === undefined || a.max === undefined || (a.step ?? 0) < 1) continue;
    if (a.max <= a.included) continue;
    const prices = allPeriods(a.prices);
    if (!prices || !positive(prices)) continue;
    out.push({ id: a.id, label: a.name.trim(), included: a.included, step: a.step!, max: a.max, unitPrices: prices });
  }
  return out;
}

function trafficControl(addons: Addon[]): TrafficControl | null {
  const byType = new Map<string, Addon[]>();
  for (const a of addons) if (a.typeId) byType.set(a.typeId, [...(byType.get(a.typeId) ?? []), a]);

  const children = addons.filter((a) => a.billType === '3' && a.intname === 'out' && a.parentTypeId && byType.has(a.parentTypeId));
  const first = children[0];
  if (!first?.parentTypeId) return null;
  const parents = byType.get(first.parentTypeId)!.filter((p) => !children.includes(p));
  const parent = parents[0];
  if (parents.length !== 1 || !parent || !ID.test(parent.id)) return null;

  const choices: TrafficChoice[] = [];
  for (const c of children.filter((x) => x.parentTypeId === first.parentTypeId)) {
    const prices = allPeriods(c.prices);
    if (!prices || !ID.test(c.id)) return null; // incomplete data: offer no control rather than a partial one
    choices.push({ id: c.id, label: c.name.trim(), prices });
  }
  const def = choices.find((c) => zero(c.prices));
  if (choices.length < 2 || !def || !choices.some((c) => !zero(c.prices))) return null;
  return { parentId: parent.id, defaultId: def.id, choices };
}

export function buildConfigModel(plan: Pick<Plan, 'kind' | 'currency' | 'addons'>): ConfigModel | null {
  const quantities = quantityControls(plan.addons);
  const traffic = trafficControl(plan.addons);
  const fixedResources =
    plan.kind === 'vps' &&
    ['Disk space', 'RAM', 'CPU number'].every((n) => plan.addons.some((a) => a.name.trim() === n && a.billType === '1'));
  if (quantities.length === 0 && !traffic && !fixedResources) return null;
  return { currency: plan.currency, quantities, traffic, fixedResources };
}

export function defaultSelection(model: ConfigModel): Selection {
  return {
    quantities: Object.fromEntries(model.quantities.map((q) => [q.id, q.included])),
    traffic: model.traffic?.defaultId,
  };
}

export function validateSelection(model: ConfigModel, sel: Selection): void {
  for (const [id, qty] of Object.entries(sel.quantities)) {
    const q = model.quantities.find((x) => x.id === id);
    if (!q) throw new SelectionError(`Unknown option ${id}`);
    if (!Number.isInteger(qty) || qty < q.included || qty > q.max || (qty - q.included) % q.step !== 0) {
      throw new SelectionError(`Invalid quantity ${String(qty)} for ${q.label}`);
    }
  }
  if (sel.traffic !== undefined) {
    if (!model.traffic?.choices.some((c) => c.id === sel.traffic)) throw new SelectionError(`Unknown traffic option ${sel.traffic}`);
  }
}

export interface QuoteLine {
  id: string;
  label: string;
  /** e.g. "2 × 2.00" */
  detail: string;
  amount: string;
}

export interface Quote {
  period: PeriodKey;
  base: string;
  lines: QuoteLine[];
  total: string;
}

/**
 * Estimated total = the plan's own period price + each selected extra at BILLmanager's period price.
 * "Estimated" because the order page is authoritative; this reproduces the documented add-on rules.
 */
export function quote(model: ConfigModel, basePrice: string, period: PeriodKey, sel: Selection): Quote {
  validateSelection(model, sel);
  let total = toFx(basePrice);
  const lines: QuoteLine[] = [];

  for (const q of model.quantities) {
    const qty = sel.quantities[q.id] ?? q.included;
    const steps = (qty - q.included) / q.step;
    if (steps <= 0) continue;
    const amount = fxMulInt(toFx(q.unitPrices[period]), steps);
    total = fxAdd(total, amount);
    lines.push({ id: q.id, label: q.label, detail: `${qty - q.included} × ${q.unitPrices[period]}`, amount: fxToString(amount) });
  }

  const t = model.traffic;
  if (t && sel.traffic && sel.traffic !== t.defaultId) {
    const c = t.choices.find((x) => x.id === sel.traffic)!;
    total = fxAdd(total, toFx(c.prices[period]));
    lines.push({ id: c.id, label: c.label, detail: 'traffic option', amount: c.prices[period] });
  }
  return { period, base: basePrice, lines, total: fxToString(total) };
}

/**
 * Order link for a configuration. BILLmanager's own link (`orderlink`) is the base; a configuration is
 * expressed as extra `addon_<id>=<value>` pairs INSIDE its `redirect` value, the way BILLmanager builds
 * parameters itself (docs: Integration with website). The register page was observed echoing such pairs
 * back in the parsed redirect. Whether the order form then honours them could not be tested without an
 * account, so they are only added when `params` is true (env ORDER_ADDON_PARAMS=on).
 * With no change from the default, or with params off, the link is returned unmodified.
 */
export function buildOrderLink(baseLink: string, model: ConfigModel, sel: Selection, opts: { params: boolean }): string {
  validateSelection(model, sel);
  if (!opts.params) return baseLink;

  const pairs: Array<[string, string]> = [];
  for (const q of model.quantities) {
    const qty = sel.quantities[q.id] ?? q.included;
    if (qty > q.included) pairs.push([`addon_${q.id}`, String(qty)]);
  }
  const t = model.traffic;
  if (t && sel.traffic && sel.traffic !== t.defaultId) pairs.push([`addon_${t.parentId}`, sel.traffic]);
  if (pairs.length === 0) return baseLink;

  const url = new URL(baseLink);
  const redirect = url.searchParams.get('redirect');
  if (redirect === null) throw new SelectionError('Order link has no redirect parameter');
  const extended = redirect + pairs.map(([k, v]) => `&${k}=${v}`).join('');
  const out = baseLink.replace(/([?&]redirect=)[^&]*/, (_m, head: string) => head + encodeURIComponent(extended));
  if (new URL(out).origin !== url.origin) throw new SelectionError('Order link origin changed');
  return out;
}
