import { randomUUID } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import type { Redis } from 'ioredis';
import { getRedis } from '@/lib/redis';
import type { Catalog, CatalogMeta } from './model';

/**
 * Snapshot store. Pages and the public API read only from here, never from BILLmanager.
 * Publishing is atomic: readers see either the old or the new snapshot, never a mix.
 */
export interface CatalogStore {
  getLive(): Promise<Catalog | null>;
  getMeta(): Promise<CatalogMeta | null>;
  /** Persist a new snapshot and make it live. */
  publish(catalog: Catalog, meta: CatalogMeta): Promise<void>;
  /** Record a sync that found nothing to publish (or failed) without touching the live snapshot. */
  setMeta(meta: CatalogMeta): Promise<void>;
  /** Single-flight guard for sync. Returns a token when acquired. */
  acquireLock(ttlMs: number): Promise<string | null>;
  releaseLock(token: string): Promise<void>;
}

export class MemoryStore implements CatalogStore {
  private live: Catalog | null = null;
  private meta: CatalogMeta | null = null;
  private lock: { token: string; until: number } | null = null;

  async getLive() {
    return this.live;
  }
  async getMeta() {
    return this.meta;
  }
  async publish(catalog: Catalog, meta: CatalogMeta) {
    this.live = catalog;
    this.meta = meta;
  }
  async setMeta(meta: CatalogMeta) {
    this.meta = meta;
  }
  async acquireLock(ttlMs: number) {
    if (this.lock && this.lock.until > Date.now()) return null;
    const token = randomUUID();
    this.lock = { token, until: Date.now() + ttlMs };
    return token;
  }
  async releaseLock(token: string) {
    if (this.lock?.token === token) this.lock = null;
  }
}

/** Development only: lets `next dev` and the sync script share a snapshot without Redis. */
export class FileStore extends MemoryStore {
  constructor(private readonly dir = path.join(process.cwd(), '.cache')) {
    super();
  }
  private get file() {
    return path.join(this.dir, 'catalog.json');
  }
  private async read(): Promise<{ catalog: Catalog | null; meta: CatalogMeta | null }> {
    try {
      return JSON.parse(await fs.readFile(this.file, 'utf8'));
    } catch {
      return { catalog: null, meta: null };
    }
  }
  async getLive() {
    return (await this.read()).catalog;
  }
  async getMeta() {
    return (await this.read()).meta;
  }
  async publish(catalog: Catalog, meta: CatalogMeta) {
    await fs.mkdir(this.dir, { recursive: true });
    const tmp = `${this.file}.${process.pid}.tmp`;
    await fs.writeFile(tmp, JSON.stringify({ catalog, meta }));
    await fs.rename(tmp, this.file); // atomic replace
  }
  async setMeta(meta: CatalogMeta) {
    const { catalog } = await this.read();
    await fs.mkdir(this.dir, { recursive: true });
    await fs.writeFile(this.file, JSON.stringify({ catalog, meta }));
  }
}

const KEY_PREFIX = 'gcore:catalog';
/** A superseded snapshot lingers briefly for readers that already resolved the old pointer, then expires. */
const SUPERSEDED_TTL_SECONDS = 3600;

/** Release only if we still own the lock. */
const RELEASE_LUA = `if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end`;

export class RedisStore implements CatalogStore {
  constructor(private readonly redis: Redis) {}

  async getLive() {
    const version = await this.redis.get(`${KEY_PREFIX}:live`);
    if (!version) return null;
    const raw = await this.redis.get(`${KEY_PREFIX}:v:${version}`);
    return raw ? (JSON.parse(raw) as Catalog) : null;
  }
  async getMeta() {
    const raw = await this.redis.get(`${KEY_PREFIX}:meta`);
    return raw ? (JSON.parse(raw) as CatalogMeta) : null;
  }
  async publish(catalog: Catalog, meta: CatalogMeta) {
    const previous = await this.redis.get(`${KEY_PREFIX}:live`);
    // Write the immutable versioned snapshot first, then flip the pointer. The live snapshot has NO expiry:
    // if upstream is unreachable for weeks the site must keep serving the last good data, not lose it.
    await this.redis.set(`${KEY_PREFIX}:v:${catalog.version}`, JSON.stringify(catalog));
    await this.redis.set(`${KEY_PREFIX}:live`, String(catalog.version));
    await this.redis.set(`${KEY_PREFIX}:meta`, JSON.stringify(meta));
    if (previous && previous !== String(catalog.version)) await this.redis.expire(`${KEY_PREFIX}:v:${previous}`, SUPERSEDED_TTL_SECONDS);
  }
  async setMeta(meta: CatalogMeta) {
    await this.redis.set(`${KEY_PREFIX}:meta`, JSON.stringify(meta));
  }
  async acquireLock(ttlMs: number) {
    const token = randomUUID();
    const ok = await this.redis.set(`${KEY_PREFIX}:lock`, token, 'PX', ttlMs, 'NX');
    return ok === 'OK' ? token : null;
  }
  async releaseLock(token: string) {
    await this.redis.eval(RELEASE_LUA, 1, `${KEY_PREFIX}:lock`, token);
  }
}

const globalForStore = globalThis as unknown as { __catalogStore?: CatalogStore };

/**
 * Redis in production (required), file-backed in development without REDIS_URL.
 * The instance is cached on globalThis so dev hot-reload does not leak connections.
 */
export function getStore(): CatalogStore {
  if (globalForStore.__catalogStore) return globalForStore.__catalogStore;
  let store: CatalogStore;
  // `next build` pre-renders pages from the snapshot written by the prebuild sync (file store).
  // Redis is a runtime dependency; the build must not need it.
  const redis = process.env.NEXT_PHASE === 'phase-production-build' ? null : getRedis();
  if (process.env.NEXT_PHASE === 'phase-production-build') {
    store = new FileStore();
  } else if (redis) {
    store = new RedisStore(redis);
  } else if (process.env.NODE_ENV === 'production' && process.env.ALLOW_FILE_STORE !== '1') {
    throw new Error('REDIS_URL is required in production');
  } else {
    store = new FileStore();
  }
  globalForStore.__catalogStore = store;
  return store;
}
