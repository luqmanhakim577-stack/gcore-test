import type { Plan, QualityFlag } from './model';
import { dec } from './money';

/**
 * Catalog-level checks that need to see peers. Adds informational/warning flags only;
 * prices are never altered.
 */
export function annotatePlans(plans: Plan[]): void {
  addCurrencyTwinFlags(plans);
  addMissingDiscountFlags(plans);
}

function add(plan: Plan, f: QualityFlag): void {
  if (!plan.flags.some((x) => x.code === f.code)) plan.flags.push(f);
}

/** Plans are normally published in both EUR and USD; one-currency plans are worth a look. */
function addCurrencyTwinFlags(plans: Plan[]): void {
  const groups = new Map<string, Plan[]>();
  for (const p of plans) {
    const key = `${p.kind}|${p.locationId}|${p.name}`;
    const g = groups.get(key);
    if (g) g.push(p);
    else groups.set(key, [p]);
  }
  for (const g of groups.values()) {
    if (g.length === 1 && g[0]) {
      add(g[0], {
        severity: 'info',
        code: 'no-currency-twin',
        message: `Only published in ${g[0].currency}; the same plan has no counterpart in the other currency`,
      });
    }
  }
}

const hasPeriodDiscount = (p: Plan) => dec(p.prices.annually).lt(dec(p.prices.monthly).mul(12));

/** If nearly all peers of a kind+currency discount long periods, a plan without any discount stands out. */
function addMissingDiscountFlags(plans: Plan[]): void {
  const groups = new Map<string, Plan[]>();
  for (const p of plans) {
    const key = `${p.kind}|${p.currency}`;
    const g = groups.get(key);
    if (g) g.push(p);
    else groups.set(key, [p]);
  }
  for (const g of groups.values()) {
    const discounted = g.filter(hasPeriodDiscount).length;
    if (g.length < 20 || discounted / g.length < 0.9) continue;
    for (const p of g) {
      if (!hasPeriodDiscount(p)) {
        add(p, {
          severity: 'warn',
          code: 'missing-period-discount',
          message: 'No period discount although almost all comparable plans have one',
        });
      }
    }
  }
}
