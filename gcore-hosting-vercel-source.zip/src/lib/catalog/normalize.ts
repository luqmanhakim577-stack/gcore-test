import Decimal from 'decimal.js';
import type { CalcRow } from '@/lib/billmanager/calc-feed';
import { guardOrderLink, type S2Plan } from '@/lib/billmanager/pricelist';
import {
  parseCpu,
  parseDedicatedDisks,
  parsePortMbps,
  parseRamMiB,
  parseTraffic,
  parseVcpu,
  parseVpsDescription,
  parseVpsDiskGB,
} from '@/lib/billmanager/specs';
import { hashOf, slugify } from './hash';
import { locationIdOf, planCodeOf } from './locations';
import type { Disk, Plan, PlanSpecs, ProductKind, QualityFlag } from './model';
import { dec, perMonth, PERIOD_MONTHS, PERIODS, toMoney, type Money, type PeriodKey } from './money';

/** What we know about BILLmanager's own view (S2) of a plan. */
export type S2State =
  | { status: 'ok'; plan: S2Plan; at: string }
  | { status: 'not-public'; at: string }
  | { status: 'not-attempted' }
  | { status: 'failed' };

export interface NormalizeInput {
  kind: ProductKind;
  row: CalcRow;
  s1At: string;
  s2: S2State;
  billmanagerBaseUrl: string;
}

const PRICE_TOLERANCE = new Decimal('0.005');

function flag(severity: QualityFlag['severity'], code: string, message: string): QualityFlag {
  return { severity, code, message };
}

function pricesOf(block: CalcRow['server_price']): Record<PeriodKey, Money> {
  const c = block.currency;
  return {
    monthly: toMoney(block.monthly, c),
    quarterly: toMoney(block.quarterly, c),
    semiannually: toMoney(block.semiannually, c),
    annually: toMoney(block.annually, c),
  };
}

function parseSpecs(kind: ProductKind, row: CalcRow, planBase: string, flags: QualityFlag[]): PlanSpecs {
  const specs: PlanSpecs = {};
  const unparsed = (field: string, raw: string) =>
    flags.push(flag('warn', 'spec-unparsed', `Could not parse ${field} "${raw}"`));

  const ram = parseRamMiB(row.ram);
  if (ram === undefined) unparsed('ram', row.ram);
  else specs.ramMiB = ram;

  if (kind === 'vps') {
    const vcpu = parseVcpu(row.cpu);
    if (vcpu === undefined) unparsed('cpu', row.cpu);
    else specs.vcpu = vcpu;

    const gb = parseVpsDiskGB(row.hdd);
    if (gb === undefined) unparsed('hdd', row.hdd);
    else if (/(^|-)SSD(-|$)/.test(planBase)) {
      const disk: Disk = { count: 1, sizeGB: gb, type: 'SSD', typeSource: 'plan-name' };
      specs.disks = [disk];
    }
  } else {
    const cpu = parseCpu(row.cpu);
    if (!cpu) unparsed('cpu', row.cpu);
    else Object.assign(specs, cpu);

    const disks = parseDedicatedDisks(row.hdd);
    if (!disks) unparsed('hdd', row.hdd);
    else specs.disks = disks;

    if (row.gpu) specs.gpu = row.gpu;
    if (typeof row.raid === 'boolean') specs.raid = row.raid;
  }

  const port = parsePortMbps(row.connection_speed);
  if (port === undefined) unparsed('connection_speed', row.connection_speed);
  else specs.portMbps = port;

  const traffic = parseTraffic(row.traffic);
  if (!traffic) unparsed('traffic', row.traffic);
  else specs.traffic = traffic;

  return specs;
}

function checkPriceSanity(prices: Record<PeriodKey, Money>, flags: QualityFlag[]): void {
  const monthly = dec(prices.monthly);
  if (monthly.lte(0)) {
    flags.push(flag('error', 'price-nonpositive', 'Monthly price is not positive'));
    return;
  }
  const anomalies: string[] = [];
  const nonPositive: string[] = [];
  for (const key of PERIODS) {
    if (key === 'monthly') continue;
    const total = dec(prices[key]);
    const ceiling = monthly.mul(PERIOD_MONTHS[key]);
    if (total.lte(0)) nonPositive.push(key);
    else if (total.gt(ceiling.plus(PRICE_TOLERANCE))) {
      anomalies.push(`${key} ${total.toFixed(2)} > ${PERIOD_MONTHS[key]} x monthly (${ceiling.toFixed(2)})`);
    }
  }
  if (nonPositive.length) flags.push(flag('error', 'price-nonpositive', `${nonPositive.join(', ')} price is not positive`));
  if (anomalies.length) flags.push(flag('error', 'period-price-anomaly', anomalies.join('; ')));
}

export function normalizePlan(input: NormalizeInput): Plan {
  const { kind, row, s1At, s2, billmanagerBaseUrl } = input;
  const flags: QualityFlag[] = [];

  const currency = row.server_price.currency;
  const code = planCodeOf(row.name);
  const base = code ? row.name.slice(0, row.name.length - code.length - 1) : row.name;
  const familyMatch = kind === 'vps' ? /^(KVM(?:-HIGHCPU)?-SSD)-(\d+)$/.exec(base) : null;
  if (kind === 'vps' && !familyMatch) {
    flags.push(flag('info', 'family-unparsed', `VPS plan name "${row.name}" does not match a known family pattern`));
  }

  const specs = parseSpecs(kind, row, base, flags);
  const specRaw: Record<string, string> = {
    cpu: row.cpu,
    ram: row.ram,
    hdd: row.hdd,
    connection_speed: row.connection_speed,
    traffic: row.traffic,
  };
  if (row.gpu) specRaw['gpu'] = row.gpu;

  const prices = pricesOf(row.server_price);
  const order: Plan['order'] = { byPeriod: {} };
  let availability: Plan['availability'] = 'unknown';
  let addons: Plan['addons'] = [];
  let s2At: string | undefined;

  if (s2.status === 'ok') {
    const p = s2.plan;
    s2At = s2.at;
    addons = p.addons;

    if (p.itemtype !== kind) {
      flags.push(flag('error', 'itemtype-mismatch', `BILLmanager item type "${p.rawItemtype ?? '?'}" does not match ${kind}`));
    }
    if (p.currency && p.currency !== currency) {
      flags.push(flag('error', 'currency-mismatch', `Feed currency ${currency} vs BILLmanager ${p.currency}`));
    }
    if (p.name !== row.name) {
      flags.push(flag('warn', 'name-mismatch', `Feed name "${row.name}" vs BILLmanager "${p.name}"`));
    }

    // BILLmanager is the source of truth: its period price wins; any difference is flagged
    // (one flag per plan listing every differing period).
    const mismatches: string[] = [];
    for (const key of PERIODS) {
      const period = p.periods[key];
      if (!period) {
        flags.push(flag('warn', 'period-missing-in-s2', `BILLmanager has no ${key} period for this plan`));
        continue;
      }
      if (dec(period.cost).minus(dec(prices[key])).abs().gt(PRICE_TOLERANCE)) {
        mismatches.push(`${key}: calc feed ${prices[key].amount} vs BILLmanager ${period.cost}`);
        prices[key] = toMoney(period.cost, currency);
      }
      const link = guardOrderLink(period.orderLink, billmanagerBaseUrl);
      if (link) order.byPeriod[key] = link;
      else if (period.orderLink) flags.push(flag('error', 'order-link-rejected', `${key} order link failed host/path validation`));
    }
    if (mismatches.length) flags.push(flag('error', 'price-mismatch', mismatches.join('; ')));
    const baseLink = guardOrderLink(p.orderLink, billmanagerBaseUrl);
    if (baseLink) order.base = baseLink;
    else if (p.orderLink) flags.push(flag('error', 'order-link-rejected', 'Plan order link failed host/path validation'));

    if (kind === 'vps') {
      compareVpsDescription(p.descriptionText, specs, flags);
      crossCheckIncludedResources(p.addons, specs, flags);
    }

    const hasLink = Object.keys(order.byPeriod).length > 0;
    if (p.active && !p.hidden) {
      if (hasLink) availability = 'orderable';
      else flags.push(flag('error', 'no-order-link', 'Active in BILLmanager but no valid order link'));
    } else {
      availability = 'unavailable';
    }
  } else if (s2.status === 'failed') {
    flags.push(flag('warn', 's2-fetch-failed', 'BILLmanager detail could not be fetched; availability unconfirmed'));
  } else {
    flags.push(
      flag(
        'info',
        'no-s2',
        s2.status === 'not-public'
          ? 'BILLmanager does not expose this plan to anonymous users; availability and order link unconfirmed'
          : 'BILLmanager detail not requested for this currency',
      ),
    );
  }

  checkPriceSanity(prices, flags);

  const perMonthEquiv = Object.fromEntries(PERIODS.map((k) => [k, perMonth(prices[k], k)])) as Record<PeriodKey, Money>;
  const osPriceUnconfirmed = row.os_price
    ? (pricesOf(row.os_price) as Record<PeriodKey, Money>)
    : undefined;

  const plan: Plan = {
    id: row.id,
    kind,
    name: row.name,
    slug: slugify(base),
    family: familyMatch?.[1],
    tier: familyMatch ? Number(familyMatch[2]) : undefined,
    locationId: locationIdOf(row.country, row.data_center),
    currency,
    specs,
    specRaw,
    prices,
    perMonthEquiv,
    osPriceUnconfirmed,
    addons,
    order,
    availability,
    flags,
    source: {
      s1At,
      s2At,
      s2Status: s2.status,
      s2CheckedAt: s2.status === 'ok' || s2.status === 'not-public' ? s2.at : undefined,
      changedAt: s1At, // sync replaces this with the previous value when the content hash is unchanged
      s1Hash: hashOf(row),
      hash: '',
    },
  };
  plan.source.hash = hashOf({ ...plan, source: undefined });
  return plan;
}

/**
 * BILLmanager bills a VPS's disk, RAM and vCPU as "Do not bill" add-ons whose "Tariff plan includes"
 * value is the plan's own resource. That is an independent source for the calc feed's specs: all 180
 * live VPS plans agreed when this was written. Units differ per plan (GiB or MiB), so they are converted.
 */
export function crossCheckIncludedResources(addons: Plan['addons'], specs: PlanSpecs, flags: QualityFlag[]): void {
  const find = (name: string) => addons.find((a) => a.name.trim() === name && a.billType === '1');
  const toGiB = (v: number, unit?: string) => (unit === 'MiB' ? v / 1024 : unit === 'GiB' ? v : undefined);
  const mismatch = (field: string, feed: unknown, billing: unknown) =>
    flags.push(flag('warn', 'addon-spec-mismatch', `${field}: calc feed ${String(feed)} vs BILLmanager included resource ${String(billing)}`));

  const disk = find('Disk space');
  const diskGiB = disk?.included !== undefined ? toGiB(disk.included, disk.unit) : undefined;
  const feedDisk = specs.disks?.[0]?.sizeGB;
  if (diskGiB !== undefined && feedDisk !== undefined && diskGiB !== feedDisk) mismatch('disk GB', feedDisk, diskGiB);

  const ram = find('RAM');
  const ramGiB = ram?.included !== undefined ? toGiB(ram.included, ram.unit) : undefined;
  if (ramGiB !== undefined && specs.ramMiB !== undefined && ramGiB * 1024 !== specs.ramMiB) mismatch('RAM MiB', specs.ramMiB, ramGiB * 1024);

  const cpu = find('CPU number');
  if (cpu?.included !== undefined && specs.vcpu !== undefined && cpu.included !== specs.vcpu) mismatch('vCPU', specs.vcpu, cpu.included);
}

/** Cross-check BILLmanager's own description line against the calc feed specs (VPS only). */
function compareVpsDescription(text: string, specs: PlanSpecs, flags: QualityFlag[]): void {
  const d = parseVpsDescription(text);
  const mismatch = (field: string, a: unknown, b: unknown) =>
    flags.push(flag('warn', 'spec-mismatch', `${field}: calc feed ${String(a)} vs BILLmanager description ${String(b)}`));

  if (d.vcpu !== undefined && specs.vcpu !== undefined && d.vcpu !== specs.vcpu) mismatch('vCPU', specs.vcpu, d.vcpu);
  if (d.ramMiB !== undefined && specs.ramMiB !== undefined && d.ramMiB !== specs.ramMiB) mismatch('RAM MiB', specs.ramMiB, d.ramMiB);
  if (d.portMbps !== undefined && specs.portMbps !== undefined && d.portMbps !== specs.portMbps) mismatch('port Mbit/s', specs.portMbps, d.portMbps);
  if (d.trafficUnlimited && specs.traffic && specs.traffic.kind !== 'unlimited') mismatch('traffic', specs.traffic.kind, 'unlimited');

  const disk = specs.disks?.[0];
  if (d.diskGB !== undefined && disk && disk.sizeGB !== d.diskGB) mismatch('disk GB', disk.sizeGB, d.diskGB);
  if (d.diskType && disk) {
    if (disk.type !== d.diskType) mismatch('disk type', disk.type, d.diskType);
    disk.type = d.diskType;
    disk.typeSource = 'billmanager';
  }
}
