import { withheldSpecs } from '@/lib/format';
import { isTrustworthy, type Addon, type Catalog, type Location, type Plan, type PlanSpecs, type ProductKind } from './model';
import type { Currency, Money, PeriodKey } from './money';

/**
 * Public, versioned representation of the catalog (JSON API, llms-full.txt, JSON-LD all derive from it).
 * Deliberately omits internal fields: quality flags, hashes, the unconfirmed os_price, raw feed strings.
 */
export interface PublicPlan {
  id: string;
  kind: ProductKind;
  name: string;
  slug: string;
  family?: string;
  location: { id: string; country: string; city: string; dcLabel?: string };
  currency: Currency;
  specs: PlanSpecs;
  prices: Record<PeriodKey, Money>;
  /** Derived for display; the commercial price is `prices`. */
  perMonthEquivalent: Record<PeriodKey, Money>;
  availability: Plan['availability'];
  /**
   * true when BILLmanager confirmed the plan this sync and the data passed validation.
   * Only verified plans carry order URLs.
   */
  verified: boolean;
  orderUrls: Partial<Record<PeriodKey, string>>;
  addons: Array<Pick<Addon, 'id' | 'name' | 'min' | 'max' | 'step' | 'prices'>>;
}

export interface PublicLocation {
  id: string;
  country: string;
  city: string;
  dcLabel?: string;
  products: ProductKind[];
}

export const isVerified = (p: Plan): boolean => p.source.s2Status === 'ok' && p.availability === 'orderable' && isTrustworthy(p);

/**
 * Specs the site withholds (BILLmanager's own text contradicts the feed) must be withheld in the API
 * too: a machine reader would otherwise get the very value the page refuses to state.
 */
export function publicSpecs(plan: Plan): PlanSpecs {
  const hide = withheldSpecs(plan);
  const { vcpu, ramMiB, disks, portMbps, traffic, ...rest } = plan.specs;
  return {
    ...rest,
    ...(!hide.has('vcpu') && vcpu !== undefined ? { vcpu } : {}),
    ...(!hide.has('ram') && ramMiB !== undefined ? { ramMiB } : {}),
    ...(!hide.has('disk') && disks !== undefined ? { disks } : {}),
    ...(!hide.has('port') && portMbps !== undefined ? { portMbps } : {}),
    ...(!hide.has('traffic') && traffic !== undefined ? { traffic } : {}),
  };
}

export function toPublicPlan(plan: Plan, locations: Map<string, Location>): PublicPlan {
  const loc = locations.get(plan.locationId);
  const verified = isVerified(plan);
  return {
    id: plan.id,
    kind: plan.kind,
    name: plan.name,
    slug: plan.slug,
    family: plan.family,
    location: {
      id: plan.locationId,
      country: loc?.country ?? '',
      city: loc?.city ?? '',
      dcLabel: loc?.dcLabel,
    },
    currency: plan.currency,
    specs: publicSpecs(plan),
    prices: plan.prices,
    perMonthEquivalent: plan.perMonthEquiv,
    availability: plan.availability,
    verified,
    orderUrls: verified ? plan.order.byPeriod : {},
    addons: plan.addons.map(({ id, name, min, max, step, prices }) => ({ id, name, min, max, step, prices })),
  };
}

export function toPublicLocation(l: Location): PublicLocation {
  return { id: l.id, country: l.country, city: l.city, dcLabel: l.dcLabel, products: l.kinds };
}

export function locationMap(catalog: Catalog): Map<string, Location> {
  return new Map(catalog.locations.map((l) => [l.id, l]));
}
