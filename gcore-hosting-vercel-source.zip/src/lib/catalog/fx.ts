/**
 * Tiny fixed-point decimal (4 places, BigInt) for the configurator, which runs in the browser.
 * It avoids shipping a decimal library to every plan page. Amounts are BILLmanager decimal strings;
 * only addition and multiplication by whole numbers are needed, and both are exact at 4 places.
 */
const ONE = 10_000n;

export function toFx(amount: string): bigint {
  const m = /^(-?)(\d+)(?:\.(\d{1,4}))?$/.exec(amount.trim());
  if (!m) throw new Error(`Not a decimal amount: ${amount}`);
  const v = BigInt(m[2]!) * ONE + BigInt((m[3] ?? '').padEnd(4, '0') || '0');
  return m[1] ? -v : v;
}

/** At least 2 decimals, at most 4, trailing zeros beyond 2 trimmed: matches normalizeAmount(). */
export function fxToString(v: bigint): string {
  const neg = v < 0n;
  const abs = neg ? -v : v;
  const whole = abs / ONE;
  let frac = (abs % ONE).toString().padStart(4, '0');
  while (frac.length > 2 && frac.endsWith('0')) frac = frac.slice(0, -1);
  return `${neg ? '-' : ''}${whole}.${frac}`;
}

export const fxAdd = (a: bigint, b: bigint): bigint => a + b;

export function fxMulInt(a: bigint, n: number): bigint {
  if (!Number.isInteger(n)) throw new Error('fxMulInt needs a whole number');
  return a * BigInt(n);
}
