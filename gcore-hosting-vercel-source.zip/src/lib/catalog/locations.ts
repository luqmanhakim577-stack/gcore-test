import { slugify } from './slug'; // not ./hash: this module is imported by client code and hash needs node:crypto
import type { Location, ProductKind } from './model';

/**
 * Feed locations are "country" + "data_center" strings such as ("USA", "Ashburn"),
 * ("Netherlands", "Amsterdam, DC 2") and ("Luxembourg", "DC 2").
 * The slug is derived from the city (or the country when the data center has no city).
 */
export function splitLocation(country: string, dataCenter: string): { city: string; dcLabel?: string } {
  const parts = dataCenter.split(',').map((p) => p.trim()).filter(Boolean);
  const first = parts[0] ?? dataCenter;
  if (parts.length === 1 && /^DC\s*\d+$/i.test(first)) return { city: country, dcLabel: first };
  const rest = parts.slice(1).join(', ');
  return { city: first, dcLabel: rest || undefined };
}

export function locationIdOf(country: string, dataCenter: string): string {
  return slugify(splitLocation(country, dataCenter).city);
}

/** Short BILLmanager code = last "-" token of the plan name (ANX, FRN, DRA4 ...). */
export function planCodeOf(name: string): string {
  const parts = name.split('-');
  return parts.length > 1 ? (parts[parts.length - 1] ?? '') : '';
}

export interface LocationSource {
  country: string;
  dataCenter: string;
  code: string;
  kind: ProductKind;
}

export function buildLocations(sources: LocationSource[]): Location[] {
  const byId = new Map<
    string,
    { loc: Omit<Location, 'codes' | 'kinds'>; codes: Record<ProductKind, Map<string, number>>; kinds: Set<ProductKind> }
  >();

  for (const s of sources) {
    const id = locationIdOf(s.country, s.dataCenter);
    const { city, dcLabel } = splitLocation(s.country, s.dataCenter);
    let entry = byId.get(id);
    if (!entry) {
      entry = {
        loc: { id, slug: id, country: s.country, city, dcLabel },
        codes: { vps: new Map(), dedicated: new Map() },
        kinds: new Set(),
      };
      byId.set(id, entry);
    } else if (entry.loc.country !== s.country) {
      throw new Error(`Location slug collision: "${id}" is used by "${entry.loc.country}" and "${s.country}"`);
    }
    entry.kinds.add(s.kind);
    if (s.code) entry.codes[s.kind].set(s.code, (entry.codes[s.kind].get(s.code) ?? 0) + 1);
  }

  const mostFrequent = (m: Map<string, number>) => [...m.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
  return [...byId.values()]
    .map(({ loc, codes, kinds }) => {
      const out: Location['codes'] = {};
      for (const k of ['vps', 'dedicated'] as const) {
        const code = mostFrequent(codes[k]);
        if (code) out[k] = code;
      }
      return { ...loc, codes: out, kinds: [...kinds].sort() };
    })
    .sort((a, b) => a.country.localeCompare(b.country) || a.city.localeCompare(b.city));
}
