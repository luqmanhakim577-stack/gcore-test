/** Billing periods and currencies. No dependencies, so client components can import it cheaply. */
export type Currency = 'EUR' | 'USD';

export const PERIODS = ['monthly', 'quarterly', 'semiannually', 'annually'] as const;
export type PeriodKey = (typeof PERIODS)[number];

export const PERIOD_MONTHS: Record<PeriodKey, number> = {
  monthly: 1,
  quarterly: 3,
  semiannually: 6,
  annually: 12,
};
