import Decimal from 'decimal.js';
import { PERIOD_MONTHS, PERIODS, type Currency, type PeriodKey } from './periods';

export { PERIOD_MONTHS, PERIODS };
export type { Currency, PeriodKey };

/** Amounts are decimal strings; floats never carry money. */
export interface Money {
  amount: string;
  currency: Currency;
}

/**
 * Normalise a number/string into a decimal string with at least 2 and at most 4 decimals
 * (BILLmanager add-ons can be priced per GB with 4 decimals; plans use 2).
 */
export function normalizeAmount(value: number | string): string {
  const d = new Decimal(typeof value === 'number' ? value.toString() : value.trim());
  if (!d.isFinite()) throw new Error(`Not a finite amount: ${String(value)}`);
  let s = d.toDecimalPlaces(4).toFixed(4);
  while (s.endsWith('0') && /\.\d{3,}$/.test(s)) s = s.slice(0, -1);
  return s;
}

export function toMoney(value: number | string, currency: Currency): Money {
  return { amount: normalizeAmount(value), currency };
}

export function dec(m: Money | string): Decimal {
  return new Decimal(typeof m === 'string' ? m : m.amount);
}

/** Per-month equivalent for display only; the commercial price is always the BILLmanager period price. */
export function perMonth(total: Money, period: PeriodKey): Money {
  return {
    amount: dec(total).div(PERIOD_MONTHS[period]).toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
    currency: total.currency,
  };
}

/** Percentage saved by a period price relative to paying monthly for the same months (display only). */
export function savingPercent(monthly: Money, total: Money, period: PeriodKey): number {
  const gross = dec(monthly).mul(PERIOD_MONTHS[period]);
  if (gross.lte(0)) return 0;
  return gross.minus(dec(total)).div(gross).mul(100).toDecimalPlaces(1).toNumber();
}
