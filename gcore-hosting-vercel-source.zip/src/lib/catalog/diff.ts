import type { Catalog, ProductKind } from './model';

export interface CatalogDiff {
  added: string[];
  removed: string[];
  changed: string[];
  /** Locations whose set of plans changed in any way. */
  touchedLocationIds: string[];
  touchedKinds: ProductKind[];
  /** `${kind}:${slug}`: the same plan offered across locations (plan pages link to these siblings). */
  touchedGroups: string[];
  empty: boolean;
}

/** Plan-level diff by content hash. `prev` null means first publish: everything is "added". */
export function diffCatalogs(prev: Catalog | null, next: Catalog): CatalogDiff {
  const prevById = new Map((prev?.plans ?? []).map((p) => [p.id, p]));
  const nextById = new Map(next.plans.map((p) => [p.id, p]));
  const added: string[] = [];
  const removed: string[] = [];
  const changed: string[] = [];
  const locations = new Set<string>();
  const kinds = new Set<ProductKind>();
  const groups = new Set<string>();

  const touch = (p: { locationId: string; kind: ProductKind; slug: string }) => {
    locations.add(p.locationId);
    kinds.add(p.kind);
    groups.add(`${p.kind}:${p.slug}`);
  };

  for (const p of next.plans) {
    const old = prevById.get(p.id);
    if (!old) added.push(p.id);
    else if (old.source.hash !== p.source.hash) changed.push(p.id);
    else continue;
    touch(p);
  }
  for (const p of prevById.values()) {
    if (!nextById.has(p.id)) {
      removed.push(p.id);
      touch(p);
    }
  }
  return {
    added,
    removed,
    changed,
    touchedLocationIds: [...locations].sort(),
    touchedKinds: [...kinds].sort(),
    touchedGroups: [...groups].sort(),
    empty: added.length + removed.length + changed.length === 0,
  };
}

/**
 * Cache tags to revalidate for a diff. Pages tag the data they render:
 *   plan pages  `plan:{id}`, `location:{slug}`, `group:{kind}:{slug}` (siblings in other locations)
 *   location pages `location:{slug}`, hubs `kind:{kind}`, site-wide lists `catalog`.
 * Only plans that actually changed produce tags, so unrelated pages stay cached.
 */
export function tagsForDiff(diff: CatalogDiff): string[] {
  if (diff.empty) return [];
  const tags = new Set<string>(['catalog']);
  for (const id of [...diff.added, ...diff.removed, ...diff.changed]) tags.add(`plan:${id}`);
  for (const l of diff.touchedLocationIds) tags.add(`location:${l}`);
  for (const k of diff.touchedKinds) tags.add(`kind:${k}`);
  for (const g of diff.touchedGroups) tags.add(`group:${g}`);
  return [...tags].sort();
}
