import { unstable_cache } from 'next/cache';
import { notFound } from 'next/navigation';
import { CATALOG_SCHEMA, type Catalog, type ProductKind } from './model';
import { OWNER_FACTS } from '@/content/facts';
import { SITE_TAG } from '@/lib/cache/tags';
import { catalogFacts } from '@/lib/aeo/catalog-facts';
import { llmsFullTxt, llmsTxt } from '@/lib/aeo/llms';
import { sitemapEntries } from '@/lib/seo/sitemap';
import { loadCatalog } from './read';
import {
  homeView,
  hubView,
  locationDetailView,
  locationPageView,
  locationsIndexView,
  planKey,
  planPageView,
  staticParams,
} from './views';

/**
 * Tagged, cached page data. Each loader declares the cache tags of the data it reads, so a sync
 * that changes one plan revalidates only the pages that show that plan (see tagsForDiff).
 * `revalidate` is only a safety net; tags are the real invalidation.
 */
const SAFETY_NET_SECONDS = 600; // = SYNC_INTERVAL_MINUTES * 60 (checked by tests/cache/freshness.test.ts)

/** Pages must never be generated from an empty store: throwing keeps the previous page (or errors), not a cached "nothing". */
async function requireCatalog(): Promise<Catalog> {
  const c = await loadCatalog();
  if (!c) throw new Error('Catalog snapshot unavailable');
  return c;
}

/**
 * Bump when the shape of Plan or of any view-model changes. Next persists this data cache across builds
 * (`.next/cache`), so without a new key a deploy could render pages from objects of the OLD shape
 * (this happened when add-on fields were introduced: pages built without the configurator).
 */
const DATA_SHAPE_VERSION = `schema-${CATALOG_SCHEMA}`; // bump CATALOG_SCHEMA (model.ts) for either reason

/** Every loader also carries `site`, the "revalidate everything" tag (see cache/tags.ts). */
const cached = <T>(fn: () => Promise<T>, key: string[], tags: string[]) =>
  unstable_cache(fn, ['page-data', DATA_SHAPE_VERSION, ...key], { tags: [...tags, SITE_TAG], revalidate: SAFETY_NET_SECONDS })();

export const getHome = () => cached(async () => homeView(await requireCatalog()), ['home'], ['catalog']);

export const getLocationsIndex = () => cached(async () => locationsIndexView(await requireCatalog()), ['locations'], ['catalog']);

export async function getLocationDetail(slug: string) {
  const view = await cached(async () => locationDetailView(await requireCatalog(), slug), ['location', slug], ['catalog', `location:${slug}`]);
  if (!view) notFound();
  return view;
}

export const getHub = (kind: ProductKind) => cached(async () => hubView(await requireCatalog(), kind), ['hub', kind], [`kind:${kind}`]);

export async function getKindLocation(kind: ProductKind, slug: string) {
  const view = await cached(
    async () => locationPageView(await requireCatalog(), kind, slug),
    ['kind-location', kind, slug],
    [`kind:${kind}`, `location:${slug}`],
  );
  if (!view) notFound();
  return view;
}

/** Plan pages are tagged with the plan, its location and its sibling group (same plan elsewhere). */
export async function getPlan(kind: ProductKind, id: string) {
  const catalog = await requireCatalog();
  const key = planKey(catalog, kind, id);
  if (!key) notFound();
  const view = await cached(
    async () => planPageView(await requireCatalog(), kind, id),
    ['plan', kind, id],
    [`plan:${id}`, `location:${key.location.slug}`, `group:${kind}:${key.plan.slug}`],
  );
  if (!view) notFound();
  return view;
}

/** Aggregates quoted by the editorial pages and by llms.txt; changes whenever any plan changes. */
export const getCatalogFacts = () => cached(async () => catalogFacts(await requireCatalog()), ['facts'], ['catalog']);

/** Rendered once per catalog change; the routes serve the cached text. */
export const getLlmsTxt = () =>
  cached(async () => { const c = await requireCatalog(); return llmsTxt(c, catalogFacts(c), OWNER_FACTS); }, ['llms'], ['catalog']);
export const getLlmsFullTxt = () =>
  cached(async () => { const c = await requireCatalog(); return llmsFullTxt(c, catalogFacts(c), OWNER_FACTS); }, ['llms-full'], ['catalog']);

export const getSitemapEntries = () => cached(async () => sitemapEntries(await requireCatalog()), ['sitemap'], ['catalog']);

/** For generateStaticParams. An empty store yields no params; pages are then generated on first request. */
export async function getStaticParams() {
  try {
    const c = await loadCatalog();
    return c ? staticParams(c) : { plans: [], locations: [], locationSlugs: [] };
  } catch {
    return { plans: [], locations: [], locationSlugs: [] };
  }
}
