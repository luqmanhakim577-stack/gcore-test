import type { Catalog } from './model';
import { getStore } from './store';

/**
 * Read access for pages and the public API. Short in-process memo so one render pass
 * (hundreds of pages at build time, bursts at runtime) parses the snapshot once, not per call.
 * Freshness comes from tag revalidation of the Next cache; this memo only bounds repeated parsing.
 *
 * The memo lives on globalThis: Next compiles routes, pages and instrumentation into separate bundles, and a
 * module-level variable would be a different copy in each, so a reset in one would not reach the others and a
 * page regenerated right after a sync could be rendered from the previous snapshot.
 */
const MEMO_MS = 5_000;
type Memo = { at: number; catalog: Catalog | null };
const g = globalThis as unknown as { __catalogMemo?: Memo };

export async function loadCatalog(): Promise<Catalog | null> {
  const now = Date.now();
  const memo = g.__catalogMemo;
  if (memo && now - memo.at < MEMO_MS) return memo.catalog;
  const catalog = await getStore().getLive();
  g.__catalogMemo = { at: now, catalog };
  return catalog;
}

export function resetCatalogMemo(): void {
  g.__catalogMemo = undefined;
}
