import type { Currency, Money, PeriodKey } from './money';

export type ProductKind = 'vps' | 'dedicated';

/**
 * orderable   - BILLmanager (pricelist.export) lists the plan as active and visible.
 * unavailable - BILLmanager lists it but inactive/hidden.
 * unknown     - BILLmanager did not (or could not) confirm. Never rendered as orderable.
 */
export type Availability = 'orderable' | 'unavailable' | 'unknown';

export type DiskType = 'SSD' | 'NVMe' | 'SATA' | 'SAS' | 'HDD';

export interface Disk {
  count: number;
  sizeGB: number;
  type: DiskType;
  /** Where the type came from: BILLmanager's own text, or a token in the plan name. */
  typeSource: 'billmanager' | 'plan-name';
}

export type Traffic = { kind: 'unlimited' } | { kind: 'metered'; includedGB: number };

/** Every field is optional: a spec that cannot be parsed is left out and flagged, never guessed. */
export interface PlanSpecs {
  vcpu?: number;
  ramMiB?: number;
  disks?: Disk[];
  cpuModel?: string;
  cpuSockets?: number;
  gpu?: string;
  raid?: boolean;
  portMbps?: number;
  traffic?: Traffic;
}

export type FlagSeverity = 'info' | 'warn' | 'error';

export interface QualityFlag {
  code: string;
  severity: FlagSeverity;
  message: string;
}

export interface Addon {
  id: string;
  name: string;
  intname?: string;
  /** Raw BILLmanager addontype/billtype. Semantics are verified before the configurator uses them (Phase 5). */
  type?: string;
  billType?: string;
  min?: number;
  max?: number;
  step?: number;
  /** BILLmanager `addonlimit`, "Tariff plan includes": the quantity already covered by the plan price. */
  included?: number;
  /** BILLmanager add-on type id (`itemtype`), and the type id of its parent (`addon_itemtype_info.parent`). */
  typeId?: string;
  parentTypeId?: string;
  /** Unit of measure name from BILLmanager ("GiB", "pcs", "Mbit/sec"). */
  unit?: string;
  currency?: Currency;
  prices: Partial<Record<PeriodKey, string>>;
}

export interface PlanOrder {
  /** Plan-level order link (BILLmanager `orderlink`), already validated against the BILLmanager host. */
  base?: string;
  /** Per-period order links (BILLmanager `price.period[].orderlink`). Only periods with a link are orderable. */
  byPeriod: Partial<Record<PeriodKey, string>>;
}

export interface Plan {
  /** BILLmanager pricelist id (stable). */
  id: string;
  kind: ProductKind;
  /** Exactly as in BILLmanager. */
  name: string;
  /** URL-safe slug of the name without the location code. Unique per (kind, location, currency). */
  slug: string;
  /** e.g. KVM-SSD, KVM-HIGHCPU-SSD (VPS only; parsed from the name, not invented). */
  family?: string;
  tier?: number;
  locationId: string;
  currency: Currency;
  specs: PlanSpecs;
  /** Original strings from the feed, always kept next to the parsed values. */
  specRaw: Record<string, string>;
  /** Exactly BILLmanager's period prices. */
  prices: Record<PeriodKey, Money>;
  /** Derived for display only. */
  perMonthEquiv: Record<PeriodKey, Money>;
  /**
   * `os_price` from the calc feed. Its meaning is unconfirmed (ARCHITECTURE.md D3):
   * must not be displayed or labelled until confirmed.
   */
  osPriceUnconfirmed?: Record<PeriodKey, Money>;
  addons: Addon[];
  order: PlanOrder;
  availability: Availability;
  flags: QualityFlag[];
  source: {
    s1At: string;
    /** When BILLmanager detail was last fetched successfully. */
    s2At?: string;
    /** Outcome of the last BILLmanager lookup. */
    s2Status: 'ok' | 'not-public' | 'failed' | 'not-attempted';
    /** When BILLmanager was last asked (ok or not-public); drives incremental refresh. */
    s2CheckedAt?: string;
    /**
     * When this plan's published content last changed (by content hash). Drives sitemap `lastmod`,
     * so crawlers are told about real changes only, not about every sync.
     */
    changedAt: string;
    /** Hash of the S1 row, used for incremental sync. */
    s1Hash: string;
    /** Hash of the whole normalized plan (excluding timestamps), used for change detection. */
    hash: string;
  };
}

export interface Location {
  id: string;
  slug: string;
  country: string;
  city: string;
  dcLabel?: string;
  /**
   * Short BILLmanager code from plan names (ANX, FRN, ...), per product kind. VPS and dedicated can
   * carry different codes for the same city (Sao Paulo: SP3 vs ASP5); we do not assume they are the
   * same facility.
   */
  codes: Partial<Record<ProductKind, string>>;
  kinds: ProductKind[];
}

export interface CatalogStats {
  plans: number;
  byKind: Record<ProductKind, number>;
  orderable: number;
  unknown: number;
  flagged: number;
}

/**
 * Shape version of the stored snapshot. Bump it whenever Plan (or what is parsed from BILLmanager into it)
 * gains or changes a field. A snapshot with another schema is never reused: the next sync refetches all
 * BILLmanager detail, so stored data cannot silently lack fields the code now relies on.
 */
export const CATALOG_SCHEMA = 3;

export interface Catalog {
  /** Absent on snapshots written before schema versioning (treated as stale). */
  schema?: number;
  version: number;
  generatedAt: string;
  plans: Plan[];
  locations: Location[];
  stats: CatalogStats;
}

/** Identifies one published snapshot. The version alone could repeat if the store were ever emptied and re-synced. */
export function catalogId(c: Pick<Catalog, 'version' | 'generatedAt'>): string {
  return `${c.version}@${c.generatedAt}`;
}

export interface CatalogMeta {
  version: number;
  lastCheckedAt: string;
  lastPublishedAt: string;
  lastError?: { at: string; message: string };
}

/** A plan whose own data cannot be trusted for aggregates ("from X"), comparisons or Offer markup. */
export function isTrustworthy(plan: Plan): boolean {
  return !plan.flags.some((f) => f.severity === 'error');
}
