import pino from 'pino';

/**
 * Structured logger. Never log secrets, full upstream payloads or personal data;
 * log ids, counts, durations and error codes.
 */
export const log = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  base: { service: 'gcore-hosting-web' },
  redact: ['req.headers.authorization', 'req.headers.cookie', '*.secret', '*.password'],
});
