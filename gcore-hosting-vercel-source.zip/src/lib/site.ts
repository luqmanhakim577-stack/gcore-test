import type { ProductKind } from '@/lib/catalog/model';

export const SITE_NAME = 'Gcore Hosting';

/** How often the scheduler re-syncs the catalog from the billing system. Public copy quotes it; a test keeps them equal. */
export const SYNC_INTERVAL_MINUTES = 10;

export const KIND_BASE: Record<ProductKind, string> = {
  vps: '/vps',
  dedicated: '/dedicated-servers',
};

export const KIND_LABEL: Record<ProductKind, string> = {
  vps: 'VPS',
  dedicated: 'Dedicated servers',
};

/** Singular, for sentences: "VPS in Frankfurt", "dedicated servers in Frankfurt". */
export const KIND_NOUN: Record<ProductKind, string> = {
  vps: 'VPS',
  dedicated: 'dedicated servers',
};

export const NAV = [
  { href: KIND_BASE.vps, label: KIND_LABEL.vps },
  { href: KIND_BASE.dedicated, label: KIND_LABEL.dedicated },
  { href: '/locations', label: 'Locations' },
  { href: '/learn', label: 'Guides' },
] as const;

/** Machine-readable entry points, linked from the footer so crawlers and people can find them. */
export const MACHINE_LINKS = [
  { href: '/api/v1/openapi.json', label: 'API (OpenAPI)' },
  { href: '/llms.txt', label: 'llms.txt' },
  { href: '/llms-full.txt', label: 'llms-full.txt' },
  { href: '/sitemap.xml', label: 'Sitemap' },
] as const;

export function kindFromBase(segment: string): ProductKind | null {
  return (Object.entries(KIND_BASE).find(([, base]) => base === `/${segment}`)?.[0] as ProductKind | undefined) ?? null;
}
