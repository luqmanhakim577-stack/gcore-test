import { loopbackApply } from '@/lib/cache/loopback';
import { Revalidator } from '@/lib/cache/revalidator';
import { getRevalidationLog, replicaId } from '@/lib/cache/revalidation-log';
import { catalogId } from '@/lib/catalog/model';
import { resetCatalogMemo } from '@/lib/catalog/read';
import { getStore } from '@/lib/catalog/store';
import { runSync, syncConfigFromEnv } from '@/lib/catalog/sync';
import { getEnv } from '@/lib/env';
import { log } from '@/lib/log';
import { SYNC_INTERVAL_MINUTES } from '@/lib/site';

/**
 * Background work of one replica.
 *
 * Sync: safe with several replicas because runSync takes a Redis lock; a replica that loses the race returns
 * "locked" and does nothing. Disable with SYNC_SCHEDULER=off when an external scheduler calls
 * POST /api/internal/sync instead.
 *
 * Revalidation: `revalidateTag` throws outside a request, so this code never calls it. It applies tags through
 * the replica's own signed internal endpoint (loopback), and it replays the announcements other replicas
 * append to the shared log, so every replica's Next cache follows the live snapshot.
 */
const SYNC_INTERVAL_MS = SYNC_INTERVAL_MINUTES * 60_000;
const REPLICA_TICK_MS = 15_000;

export function startScheduler(): void {
  const revalidator = new Revalidator({
    log: getRevalidationLog(),
    applyLocal: async (tags) => {
      resetCatalogMemo();
      await loopbackApply()(tags);
    },
    replicaId: replicaId(),
    logger: log,
    boot: {
      buildId: process.env.BUILD_CATALOG_ID ?? 'none',
      liveId: async () => {
        const live = await getStore().getLive();
        return live ? catalogId(live) : null;
      },
    },
  });

  if (!getEnv().REVALIDATE_HMAC_SECRET) {
    log.warn({}, 'REVALIDATE_HMAC_SECRET is not set: this replica cannot refresh its page cache after a sync (pages renew on their own every sync interval)');
  }

  // Also retries tags this replica could not apply yet (its server may not have been listening at the first tick).
  setTimeout(() => void revalidator.tick(), 3_000).unref();
  setInterval(() => void revalidator.tick(), REPLICA_TICK_MS).unref();

  if (process.env.SYNC_SCHEDULER === 'off') return;

  const tick = async () => {
    try {
      const outcome = await runSync(getStore(), syncConfigFromEnv(log));
      if (outcome.status === 'published') await revalidator.announce(outcome.tags, outcome.catalog.version);
    } catch (e) {
      log.error({ err: (e as Error).message }, 'scheduled sync crashed');
    }
  };

  // First run shortly after boot (lets the server start serving), then on an interval.
  setTimeout(tick, 5_000).unref();
  setInterval(tick, SYNC_INTERVAL_MS).unref();
}
