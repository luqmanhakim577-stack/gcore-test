import { NextResponse, type NextRequest } from 'next/server';
import { absoluteUrl } from '@/lib/seo/config';

/**
 * Indexation control for URL variants. Our pages do not change with query parameters (the billing
 * period is a form control, not a URL), so `?period=…`, `?utm_…`, `?sort=…` and any other combination
 * must never become separate indexed pages. Such requests get `X-Robots-Tag: noindex, follow` and a
 * canonical Link header pointing at the clean URL. They are not blocked in robots.txt, because a
 * blocked URL cannot be crawled to discover its canonical.
 */
export function middleware(request: NextRequest) {
  const { pathname, searchParams } = request.nextUrl;
  const keys = [...searchParams.keys()].filter((k) => k !== '_rsc'); // Next's own RSC marker
  const res = NextResponse.next();
  if (keys.length > 0) {
    res.headers.set('X-Robots-Tag', 'noindex, follow');
    res.headers.set('Link', `<${absoluteUrl(pathname)}>; rel="canonical"`);
  }
  return res;
}

export const config = {
  // Pages only: not API routes, Next internals or static files.
  matcher: ['/((?!api/|_next/|favicon.ico|sitemap.xml|robots.txt).*)'],
};
