/**
 * Editorial content: general hosting-industry explanations.
 *
 * Rules for everything in this file (enforced by tests/content/claims.test.ts):
 *  - It explains industry concepts. It makes NO statement about Gcore's own network, data centers,
 *    hardware, SLA or DDoS protection. Those need owner-supplied, sourced facts (src/content/facts.ts).
 *  - Anything specific to the catalog is computed from the billing data at render time
 *    (src/lib/aeo/learn-data.ts) and shown in a separate, labelled block.
 *  - No absolute marketing claims (100% uptime, complete protection, enterprise-grade, ...).
 * Plain strings only: the same text feeds the page, the FAQPage JSON-LD and llms-full.txt, so they cannot drift.
 */

export interface QA {
  q: string;
  a: string;
}

export interface Section {
  heading: string;
  body: string[];
  list?: string[];
}

export interface Article {
  slug: string;
  title: string;
  /** Meta description. */
  description: string;
  /** Direct answer first: what an assistant or a skimming reader should take away. */
  summary: string;
  /** ISO date of the last editorial revision. Feeds the sitemap lastmod. */
  updated: string;
  sections: Section[];
  qa: QA[];
  related: string[];
}

export const LEARN: Article[] = [
  {
    slug: 'vps-vs-dedicated-server',
    title: 'VPS vs dedicated server: what is the difference?',
    description:
      'A VPS is a virtual machine on a shared physical host; a dedicated server is a whole physical machine for one customer. How they differ in isolation, performance, hardware choice and price.',
    summary:
      "A VPS is a virtual machine that runs on a physical host shared with other customers' virtual machines. A dedicated server is a whole physical machine allocated to one customer. The trade-off is lower entry price and flexibility on one side, and exclusive hardware with more predictable performance on the other.",
    updated: '2026-11-01',
    sections: [
      {
        heading: 'What a VPS is',
        body: [
          "A virtual private server (VPS) is a virtual machine running under a hypervisor, for example KVM, on a physical host that also runs other customers' virtual machines. You get your own operating system instance, normally with administrative (root) access, and a defined number of vCPUs, amount of RAM and disk space.",
          'The provider operates the physical host and the hypervisor. You operate everything inside the virtual machine. A vCPU is a virtual processor presented to your machine; it is not automatically a dedicated physical core.',
        ],
      },
      {
        heading: 'What a dedicated server is',
        body: [
          'A dedicated server is a physical server that is leased to a single customer, so no other customer runs on the same hardware. A server delivered without a customer-facing virtualization layer is often called bare metal.',
          'You choose from the configurations on offer: CPU model, number of sockets, memory, drive types and count, and whether the drives are in RAID. You can install a hypervisor yourself and run your own virtual machines on it.',
        ],
      },
      {
        heading: 'Main differences',
        body: [],
        list: [
          'Isolation: on a VPS the physical host is shared, so other machines on it can affect yours when resources are contended. A dedicated server has no other customers on the hardware.',
          'Performance predictability: a dedicated server removes contention from other customers, which makes performance steadier. It does not by itself make it faster than a VPS on newer hardware.',
          'Hardware choice: VPS plans come in fixed sizes. A dedicated server lets you pick a specific CPU model, storage layout and memory size, within what the provider offers.',
          'Scaling: resizing a VPS usually means moving to another plan. A dedicated server is bound to its hardware, so changing it means changing or adding a server.',
          'Price: a VPS usually costs less per month at small sizes. A dedicated server costs more but gives the whole machine; compare price per unit of resource you actually use.',
          'Failure domain: a hardware fault affects every machine on a VPS host, and on a dedicated server it affects you alone. Neither replaces backups.',
        ],
      },
      {
        heading: 'Which one to choose',
        body: [
          'A VPS fits small and medium workloads, test and staging environments, and workloads whose size changes. A dedicated server fits sustained heavy load, very large memory or storage, software licensed per physical core, and workloads that need known hardware or must not share it.',
        ],
      },
    ],
    qa: [
      {
        q: 'Is a VPS slower than a dedicated server?',
        a: 'Not necessarily. Speed depends on the CPU generation, how the vCPUs are allocated, the storage type and how busy the host is. A dedicated server removes contention from other customers, but a VPS on newer hardware can still be faster than a dedicated server on older hardware.',
      },
      {
        q: 'What does bare metal mean?',
        a: 'Bare metal is a physical server allocated to one customer with no customer-facing virtualization layer between you and the hardware. In hosting the term is used for dedicated servers.',
      },
      {
        q: 'Does a dedicated server include a backup?',
        a: 'No. RAID keeps a server running when a drive fails, but it is not a backup: deleted files, corruption and ransomware are copied across the drives. Keep backups on separate storage.',
      },
    ],
    related: ['shared-vs-dedicated-cpu', 'ssd-vs-nvme', 'billing-periods-and-prices'],
  },
  {
    slug: 'shared-vs-dedicated-cpu',
    title: 'Shared vs dedicated CPU: what does a vCPU mean?',
    description:
      'A vCPU is a virtual processor, not necessarily a physical core. How shared, reserved and pinned CPU allocation differ, why equal vCPU counts do not mean equal performance, and how to check.',
    summary:
      "A vCPU is a virtual processor that the hypervisor schedules onto the host's physical CPUs. Whether it is backed by a dedicated physical core or shared with other machines depends on the provider's allocation policy, so the vCPU count alone does not describe performance.",
    updated: '2026-11-01',
    sections: [
      {
        heading: 'What a vCPU is',
        body: [
          "A vCPU is a processor as the virtual machine sees it. The hypervisor runs it on a physical core or hardware thread of the host when it is scheduled. Providers define a vCPU differently: it may correspond to a hardware thread or to a share of a core.",
        ],
      },
      {
        heading: 'Shared, reserved and pinned CPU',
        body: [],
        list: [
          'Shared (oversubscribed): the hypervisor schedules the vCPUs of many machines onto fewer physical cores. It works well while machines are not all busy at once. When many are, each gets less than it expects (contention).',
          'Reserved or guaranteed share: a minimum portion of CPU time is set aside for the machine, with more available when the host is idle.',
          'Dedicated or pinned: vCPUs are tied to specific physical cores or threads that no other machine uses. Performance is the most predictable and the plan usually costs more.',
        ],
      },
      {
        heading: 'Why equal vCPU counts are not equal performance',
        body: [
          'Two plans with 4 vCPUs can differ a lot. The CPU model and generation, clock speed, cache size, memory speed, the allocation policy above and the load on the host all change what a vCPU delivers. A vCPU count should only be compared between plans that share these properties.',
        ],
      },
      {
        heading: 'Dedicated servers: sockets, cores and threads',
        body: [
          'On a dedicated server you get whole processors. Describe them by socket count, physical cores per socket and threads per core. A CPU with 8 cores and 16 threads has 8 physical cores; the 16 is logical processors.',
        ],
      },
      {
        heading: 'How to check what you actually get',
        body: [
          'Ask the provider for the CPU model and the allocation policy. Then measure with your own workload. On Linux, the steal time figure (st in top) shows CPU time the hypervisor gave to other machines while yours was ready to run; a persistently high value means contention.',
        ],
      },
    ],
    qa: [
      {
        q: 'Is a vCPU the same as a CPU core?',
        a: 'No. A vCPU is a virtual processor. Depending on the provider it can map to a hardware thread, to a share of a core, or to a pinned core. Only the allocation policy tells you which.',
      },
      {
        q: 'What is CPU steal time?',
        a: 'Steal time is the share of time a virtual machine was ready to run but the hypervisor was running something else on the physical CPU. A consistently high value suggests the host is contended.',
      },
      {
        q: 'How many vCPUs do I need?',
        a: 'Start from measured use: the peak and the sustained CPU load of your application, and whether it can use several cores at once. Many workloads are limited by memory or disk, not CPU, so measure before buying more vCPUs.',
      },
    ],
    related: ['vps-vs-dedicated-server', 'ssd-vs-nvme'],
  },
  {
    slug: 'ssd-vs-nvme',
    title: 'SSD vs NVMe: what is the difference for hosting?',
    description:
      'NVMe is a type of SSD that uses the PCIe interface instead of SATA. What that changes for latency and throughput, why a plan labelled SSD says little about speed, and why neither is a backup.',
    summary:
      'Both are flash storage. A SATA SSD uses the SATA interface; an NVMe SSD uses PCIe with the NVMe protocol, which allows much more parallelism. NVMe usually gives lower latency and higher throughput, but real performance depends on the drive, the controller, the virtualization layer and what else uses the storage.',
    updated: '2026-11-01',
    sections: [
      {
        heading: 'SSD is the category, NVMe is a kind of SSD',
        body: [
          'A solid-state drive (SSD) stores data in flash memory. SSDs differ in how they connect to the server. A SATA SSD uses the SATA interface, which tops out at about 600 MB/s of usable bandwidth for SATA III. A SAS SSD uses the SAS interface found in servers. An NVMe SSD talks over PCIe lanes with the NVMe protocol, which supports many parallel queues and reaches several GB/s on current drives.',
          'So "SSD" on a plan page does not say whether the drive is SATA or NVMe. A plan that is described as NVMe has an SSD; a plan described as SSD may or may not.',
        ],
      },
      {
        heading: 'What actually determines speed',
        body: [
          'Interface speed is a ceiling, not a result. The measured speed depends on the drive model and its endurance class, the controller, whether the disks are in RAID, and the workload: sequential reads behave differently from small random writes. Quote IOPS (operations per second), throughput (MB/s) and latency together, for a stated block size and queue depth.',
          'On a VPS there is also the virtualization layer. The virtual disk may sit on local drives or on network storage, and other machines on the same storage can affect it. A figure counts only if it was measured on the product you are buying or is written into the terms.',
        ],
      },
      {
        heading: 'Redundancy is not backup',
        body: [
          'RAID combines drives so that a failed drive does not stop the server. It does not protect against deleted files, corruption, ransomware or a mistake, because those changes are written to every drive. A snapshot kept on the same storage is not an independent backup either. A backup is a separate copy, ideally in a different location.',
        ],
      },
    ],
    qa: [
      {
        q: 'Is NVMe always faster than SSD?',
        a: 'NVMe drives usually have lower latency and higher throughput than SATA SSDs, but not in every case. A slow NVMe drive, a busy shared storage backend or a workload that is limited by CPU or network can remove the advantage.',
      },
      {
        q: 'Does SSD mean NVMe?',
        a: 'No. NVMe is one kind of SSD. A SATA SSD and a SAS SSD are also SSDs. Check whether the plan names the interface.',
      },
      {
        q: 'Is RAID a backup?',
        a: 'No. RAID protects against a drive failing. It does not protect against deletion, corruption, ransomware or a facility problem, so you still need backups on separate storage.',
      },
    ],
    related: ['vps-vs-dedicated-server', 'shared-vs-dedicated-cpu'],
  },
  {
    slug: 'port-speed-vs-traffic',
    title: 'Port speed, bandwidth and traffic: what is included in a hosting plan?',
    description:
      'Port speed is the speed of the network interface, traffic is the monthly volume, throughput is what you get end to end. Why a 1 Gbit/s port is not a 1 Gbit/s guarantee and what unmetered really means.',
    summary:
      'Port speed is the speed of the server network interface, the traffic allowance is the volume you may transfer per month, and throughput is what you actually get to a destination. A 1 Gbit/s port does not guarantee 1 Gbit/s end to end, and unmetered traffic is not the same as unlimited use.',
    updated: '2026-11-01',
    sections: [
      {
        heading: 'Port speed',
        body: [
          'Port speed is the link speed of the network interface, for example 100 Mbit/s, 1 Gbit/s or 10 Gbit/s. It is the upper limit for that interface. It is not a promise of throughput: the path to the other end crosses shared links, other networks and the remote server, and any of them can be slower. Whether the capacity behind the port is dedicated, shared or oversubscribed is a separate property that a plan must state.',
        ],
      },
      {
        heading: 'Traffic allowance, metered and unmetered',
        body: [
          'A traffic allowance is the volume of data you may transfer per month, for example 10 TB. Metered means the volume is counted. What happens when it is used up (extra charges, a reduced speed, or suspension) is set by the provider terms. Which direction is counted, outbound only or both, also differs between providers, so read it.',
          'Unmetered means the volume is not counted against an allowance. The port speed still limits the rate, and a fair-use or acceptable-use policy can still apply. Unmetered is not unlimited performance and it does not mean unrestricted use. A plan with a stated allowance is metered, never unmetered.',
        ],
      },
      {
        heading: 'Bandwidth commitments and billing models',
        body: [
          'Some network services bill by committed rate or by a percentile of measured usage instead of by volume. Hosting plans with an allowance or an unmetered port are simpler: you pay a fixed price, and the allowance or the policy sets the limit.',
        ],
      },
      {
        heading: 'How much a port can move',
        body: [
          'A 1 Gbit/s port running at full rate for 30 days moves about 324 TB (decimal terabytes) in one direction. A 10 TB allowance is therefore a bit over 3 percent of what the port could carry, which is why metered plans often combine a fast port with a modest allowance.',
        ],
      },
    ],
    qa: [
      {
        q: 'Does a 1 Gbit/s port mean I get 1 Gbit/s?',
        a: 'No. The port speed is the maximum rate of that interface. What you get to a given destination also depends on shared capacity, routing and the other end. Only a stated, contractual bandwidth commitment guarantees a rate.',
      },
      {
        q: 'What happens if I use up the traffic allowance?',
        a: 'It depends on the provider terms. Typical outcomes are extra charges per unit, a reduced port speed, or suspension. Check the terms of the plan before you rely on a quota.',
      },
      {
        q: 'Is unmetered traffic really unlimited?',
        a: 'No. Unmetered means the volume is not counted against an allowance. The port speed still caps the rate, and fair-use or acceptable-use terms can still restrict very heavy or abusive use.',
      },
    ],
    related: ['vps-vs-dedicated-server', 'billing-periods-and-prices'],
  },
  {
    slug: 'billing-periods-and-prices',
    title: 'How billing periods and prices work',
    description:
      'Each plan has a price for 1, 3, 6 and 12 months, taken unchanged from the billing system. What the per-month figure means, how to compare periods, and where the final amount is shown.',
    summary:
      'Each plan has a price for 1, 3, 6 and 12 months, taken unchanged from our billing system. A price is the amount for the whole period. The per-month figure is only that price divided by the number of months, shown for comparison.',
    updated: '2026-11-01',
    sections: [
      {
        heading: 'Where the numbers come from',
        body: [
          'Prices, billing periods, specifications and order links on this site are read from the BILLmanager 6 billing system and refreshed about every 10 minutes. They are not typed into the pages and not recalculated. If the billing system and another source disagree, the billing system wins, and a plan whose data is inconsistent is withheld from the site instead of being shown with a guess.',
        ],
      },
      {
        heading: 'Period price and per-month equivalent',
        body: [
          'The period price is what you pay for the whole period: for a 12-month period, the 12-month price. The per-month equivalent is that price divided by the number of months, rounded for display. Compare periods using the per-month figures, but pay the period price.',
          'A longer period often costs less per month than monthly billing, but the difference varies from plan to plan and is not a fixed discount. Look at the plan page for the actual figures.',
        ],
      },
      {
        heading: 'What the displayed price does not include',
        body: [
          'The order page shows the final payable amount. Taxes, optional add-ons and any conditions are applied there. This site does not state renewal or promotional pricing: it shows the current price in the billing system.',
          'Extra IPv4 or IPv6 addresses and, on dedicated servers, other traffic tiers are priced per billing period. The configurator on a plan page adds them up as an estimate; the order page is authoritative.',
        ],
      },
    ],
    qa: [
      {
        q: 'Is it cheaper to pay for 12 months?',
        a: 'Often the per-month cost is lower on a longer period, but not on every plan and by different amounts. The plan page lists the price and the per-month equivalent for each of the four periods, so compare them there.',
      },
      {
        q: 'Are prices shown with taxes?',
        a: 'The site shows the price from the billing system. Whether and how taxes apply is shown on the order page, which displays the final payable amount.',
      },
      {
        q: 'Why would a price here differ from another source?',
        a: 'Because the billing system is the source of truth for this site and it is refreshed about every 10 minutes. Other lists can be older. If the two sources disagree for a plan, the plan is withheld from this site until the data is consistent.',
      },
    ],
    related: ['vps-vs-dedicated-server', 'port-speed-vs-traffic'],
  },
  {
    slug: 'ddos-protection-explained',
    title: 'DDoS protection explained: layers, limits and what to ask',
    description:
      'What volumetric, protocol and application-layer DDoS attacks are, where mitigation runs, why a mitigation capability is not a guarantee, and which questions to ask a hosting provider.',
    summary:
      'DDoS mitigation filters attack traffic before it reaches your server. What it covers (which layers, attack types and sizes), where it runs and whether it is included differ by provider, location and plan. A mitigation capability is not the same as a contractual guarantee, and no service stops every attack.',
    updated: '2026-11-01',
    sections: [
      {
        heading: 'Types of attack',
        body: [],
        list: [
          'Volumetric attacks try to fill the network link with traffic, for example UDP floods and reflection or amplification attacks that abuse open DNS or NTP servers. They work at layers 3 and 4.',
          'Protocol attacks exhaust connection state in servers or devices, for example TCP SYN floods. They work at layer 4.',
          'Application-layer attacks send requests that look legitimate, for example floods of HTTP requests that are expensive to answer. They work at layer 7 and are harder to separate from real users.',
        ],
      },
      {
        heading: 'Where mitigation happens',
        body: [
          'Mitigation can run upstream in a scrubbing centre, in the provider network, on the server itself (firewall rules, rate limiting) or in front of a website (a CDN or web application firewall). Network-level protection mostly covers layers 3 and 4. Application-level attacks usually need protection that understands the application, so a network-level service should not be assumed to cover layer 7.',
        ],
      },
      {
        heading: 'Limits to understand',
        body: [
          'Every service has a capacity limit and takes some time to detect and react. Filtering can block legitimate traffic (false positives). When an attack exceeds what can be absorbed, some networks null-route the target address: the traffic is dropped upstream to protect the rest of the network, and the target is offline until the attack ends. A mitigation capacity figure is not a service-level guarantee, and protection scope can differ between locations.',
        ],
      },
      {
        heading: 'Questions to ask a provider',
        body: [],
        list: [
          'Which layers and attack types are covered, and which are not?',
          'Is protection always on, or does it start after detection? How long does that take?',
          'What is the mitigation capacity, and what happens when an attack exceeds it?',
          'Is it included in the plan or an add-on, and does it differ per location?',
          'Is any of this written into the service terms, or is it only a description of the technology?',
        ],
      },
    ],
    qa: [
      {
        q: 'Does DDoS protection mean my server cannot be taken offline?',
        a: 'No. No service stops every attack. A very large attack, an attack type outside the protected scope, or an application-level flood can still cause downtime or a null route.',
      },
      {
        q: 'Does network DDoS protection cover HTTP floods?',
        a: 'Not necessarily. Network-level protection focuses on layers 3 and 4. HTTP floods are layer 7 and usually need protection that understands web traffic, such as a web application firewall.',
      },
      {
        q: 'What is a null route?',
        a: 'A null route, or blackhole, drops all traffic to the attacked IP address upstream so that the attack does not saturate the network. It protects the network, and it makes the target address unreachable until the null route is lifted.',
      },
    ],
    related: ['port-speed-vs-traffic', 'vps-vs-dedicated-server'],
  },
];

export const LEARN_BY_SLUG = new Map(LEARN.map((a) => [a.slug, a]));

export interface Term {
  term: string;
  definition: string;
}

/** Industry-general definitions. A term defined here is not a statement that Gcore offers the service. */
export const GLOSSARY: Term[] = [
  { term: 'ASN (autonomous system number)', definition: 'A number that identifies a network that has its own routing policy on the internet. Networks use ASNs when they exchange routes with each other over BGP.' },
  { term: 'Bare metal', definition: 'A physical server allocated to one customer with no customer-facing virtualization layer. In hosting the term is used for dedicated servers.' },
  { term: 'BGP (Border Gateway Protocol)', definition: 'The protocol networks use to tell each other which IP address ranges they can reach. A customer can only announce its own address space or ASN over BGP if the provider supports and has agreed to it.' },
  { term: 'Billing period', definition: 'The length of time one payment covers, for example 1, 3, 6 or 12 months. The period price is the amount for the whole period.' },
  { term: 'Colocation', definition: 'Renting rack space, power, cooling and network connectivity in a data center for hardware that the customer owns and operates.' },
  { term: 'Cross-connect', definition: 'A physical cable between two networks or pieces of equipment inside the same data center or building.' },
  { term: 'DDoS (distributed denial of service)', definition: 'An attack that uses traffic from many sources to make a service unavailable. Mitigation filters that traffic; its scope and capacity differ by service, and it is not a guarantee against every attack.' },
  { term: 'Dedicated server', definition: 'A physical server leased to a single customer, so no other customer runs on the same hardware.' },
  { term: 'Fair-use policy', definition: 'A provider rule that limits heavy or abusive use of a service that is advertised without a hard cap, for example unmetered traffic.' },
  { term: 'Hypervisor', definition: 'Software that runs virtual machines on a physical host and shares the host CPU, memory and storage between them. KVM is a widely used hypervisor on Linux.' },
  { term: 'IP transit', definition: 'A paid service in which a provider carries your traffic to and from the whole internet through its own network connections. It is different from peering and from a hosting traffic allowance.' },
  { term: 'IPMI (out-of-band management)', definition: 'A management interface of a physical server that works independently of the operating system, for example to power-cycle the machine or reach its console remotely. Availability depends on the server and the plan.' },
  { term: 'IPv4 and IPv6', definition: 'The two versions of the internet address system. IPv4 addresses are scarce and are usually priced individually; IPv6 addresses are plentiful and allocated in large blocks.' },
  { term: 'KVM', definition: 'Kernel-based Virtual Machine, a hypervisor built into Linux that gives each virtual machine its own kernel. Not to be confused with KVM over IP, which is remote keyboard, video and mouse access to a physical server.' },
  { term: 'Metered traffic', definition: 'Network traffic that is counted against a monthly allowance. What happens when the allowance is used up is set by the provider terms.' },
  { term: 'NVMe', definition: 'A protocol for flash storage that runs over PCIe. NVMe SSDs usually have lower latency and higher throughput than SATA SSDs, but real performance depends on the drive and the setup.' },
  { term: 'Oversubscription', definition: 'Allocating more virtual capacity, for example vCPUs, than the physical hardware provides, on the assumption that customers will not all use it at once.' },
  { term: 'Peering', definition: 'Two networks exchanging traffic directly, usually for their own and their customers\' traffic, at an internet exchange or by a private link. It is not the same as buying transit.' },
  { term: 'Port speed', definition: 'The link speed of a network interface, for example 1 Gbit/s. It is an upper limit, not a guarantee of throughput to every destination.' },
  { term: 'RAID', definition: 'A way to combine several drives for redundancy or speed. RAID keeps a server running after a drive fails; it is not a backup.' },
  { term: 'Root access', definition: 'Administrative access inside a Linux operating system. It does not imply access to the physical server or to the host that runs a virtual machine.' },
  { term: 'SLA (service level agreement)', definition: 'The contractual commitments a provider makes about a service, with the remedy if they are missed, usually service credits. A technical capability is not an SLA.' },
  { term: 'Snapshot', definition: 'A point-in-time state of a virtual disk. A snapshot stored on the same storage as the original is not an independent backup.' },
  { term: 'SSD (solid-state drive)', definition: 'A drive that stores data in flash memory. SATA SSD, SAS SSD and NVMe SSD are different kinds that connect in different ways.' },
  { term: 'Unmetered traffic', definition: 'Traffic that is not counted against a volume allowance. The port speed still limits the rate and a fair-use or acceptable-use policy can apply. It does not mean unlimited performance.' },
  { term: 'vCPU', definition: 'A virtual processor presented to a virtual machine. Whether it is backed by a dedicated physical core depends on the provider\'s allocation policy.' },
  { term: 'VPS (virtual private server)', definition: 'A virtual machine with its own operating system instance, running on a physical host shared with other customers\' virtual machines.' },
];

export const LEARN_UPDATED = LEARN.reduce((max, a) => (a.updated > max ? a.updated : max), '2000-01-01');
