import { z } from 'zod';

/**
 * Owner-confirmed facts about Gcore's own infrastructure and service terms.
 *
 * This is the ONLY place a claim about network, DDoS scope, SLA, CPU model/allocation, data-center
 * operator, support or similar may enter the site. Nothing in it is invented: an entry needs a source
 * and a verification date, and says how strong the evidence is (the scale used in the hosting
 * industry review checklist). It is empty until the owner supplies sourced facts; see docs/OWNER-FACTS.md.
 *
 * Every consumer renders the scope next to the claim, so a fact about one location or plan family can
 * never read as a statement about all products.
 */

export const FACT_TOPICS = ['ddos', 'sla', 'cpu', 'network', 'datacenter', 'support', 'storage', 'other'] as const;
export type FactTopic = (typeof FACT_TOPICS)[number];

export const EVIDENCE = ['VERIFIED', 'CONFIGURED', 'PROVIDER_STATED', 'ESTIMATED'] as const;
export type Evidence = (typeof EVIDENCE)[number];

export const EVIDENCE_LABEL: Record<Evidence, string> = {
  VERIFIED: 'verified against documentation or direct measurement',
  CONFIGURED: 'confirmed from the deployed configuration',
  PROVIDER_STATED: 'stated by a supplier or data center, not independently verified',
  ESTIMATED: 'an estimate',
};

export const factSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]+$/),
  topic: z.enum(FACT_TOPICS),
  /** One plain sentence. No superlatives; state numbers with their units and conditions. */
  claim: z.string().min(10).max(400),
  scope: z.discriminatedUnion('type', [
    z.object({ type: z.literal('company') }),
    z.object({ type: z.literal('location'), locationId: z.string() }),
    z.object({ type: z.literal('plan-family'), kind: z.enum(['vps', 'dedicated']), family: z.string() }),
  ]),
  evidence: z.enum(EVIDENCE),
  /** Document, contract clause, panel or person that backs the claim. */
  source: z.string().min(3),
  /** ISO date (YYYY-MM-DD) when the claim was last checked against the source. */
  verifiedOn: z.iso.date(),
  /** Exclusions and conditions that a reader needs to avoid reading the claim too broadly. */
  limitations: z.string().optional(),
});

export type OwnerFact = z.infer<typeof factSchema>;

export const OWNER_FACTS: OwnerFact[] = [];

export function describeScope(f: OwnerFact): string {
  switch (f.scope.type) {
    case 'company':
      return 'all products';
    case 'location':
      return `location ${f.scope.locationId} only`;
    case 'plan-family':
      return `${f.scope.kind} plan family ${f.scope.family} only`;
  }
}

export const hasFactsAbout = (topic: FactTopic, facts: OwnerFact[] = OWNER_FACTS): boolean => facts.some((f) => f.topic === topic);

/** Topics with no published fact. Used to say plainly what the site does not state, instead of leaving it to inference. */
export const unpublishedTopics = (facts: OwnerFact[] = OWNER_FACTS): FactTopic[] =>
  (['ddos', 'sla', 'cpu', 'network', 'datacenter', 'support'] as const).filter((t) => !hasFactsAbout(t, facts));

export const TOPIC_LABEL: Record<FactTopic, string> = {
  ddos: 'DDoS protection scope',
  sla: 'service level agreement (SLA)',
  cpu: 'CPU model and allocation policy',
  network: 'network, upstream providers and peering',
  datacenter: 'data center operators and facility characteristics',
  support: 'support terms',
  storage: 'storage performance',
  other: 'other',
};
