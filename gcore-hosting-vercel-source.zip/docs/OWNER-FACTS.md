# Facts only the owner can supply

The site deliberately says nothing about the following until someone with authority gives a statement **and a source**.
Without that, a model reading the site could attribute a capability to every product, which is the failure this project
is built to avoid. Until an entry exists, `llms.txt`, `llms-full.txt` and the DDoS guide say plainly that the topic is not stated.

| Topic (`topic`) | What we need | Typical trap to avoid |
|---|---|---|
| `ddos` | Which layers and attack types are covered, capacity if published, always-on or on-demand, included or add-on, **per location** | Writing "DDoS protected" for every location; stating a Tbit/s figure that is a supplier's capacity, not a commitment |
| `sla` | SLA percentage, measurement period, exclusions, remedy (credits), link to the terms | Calling a technical capability or an uptime goal an SLA |
| `cpu` | CPU models per location/plan family, and the VPS allocation policy (shared, reserved, pinned), oversubscription ratio if it will be published | Calling a vCPU a dedicated core; transferring a CPU model from one location to another |
| `network` | Upstream providers, IXPs, whether BGP sessions or customer ASNs are supported, port-speed policy (shared or guaranteed), traffic direction counted, fair-use policy for unmetered plans | Mixing up transit, peering and a traffic allowance; implying control over upstream routing |
| `datacenter` | Facility operator per location, whether Gcore owns or leases the space and the hardware, certifications **with scope and date** | Presenting leased infrastructure as owned; inferring a tier or certification from a marketing page |
| `support` | Channels, hours, response targets only if contractual | Promising response times that are not in the terms |

## How to add one

Edit `src/content/facts.ts` and append to `OWNER_FACTS`:

```ts
{
  id: 'ddos-frankfurt-l34',
  topic: 'ddos',
  claim: 'Layer 3 and 4 attack filtering is active on the Frankfurt network.',
  scope: { type: 'location', locationId: 'frankfurt' },   // or { type: 'company' } or { type: 'plan-family', kind: 'vps', family: 'KVM-SSD' }
  evidence: 'PROVIDER_STATED',     // VERIFIED | CONFIGURED | PROVIDER_STATED | ESTIMATED
  source: 'Upstream datasheet v3, section 2',
  verifiedOn: '2026-10-30',
  limitations: 'Layer 7 attacks are not covered.',
}
```

- **Scope is mandatory.** A fact about one location must not read as a statement about all products; every consumer prints the scope next to the claim.
- **Evidence levels** are not interchangeable: `PROVIDER_STATED` stays labelled "stated by a supplier, not independently verified" wherever it appears. Do not promote it to `VERIFIED` without checking.
- Unknown things are **not** entered. There is no `UNKNOWN` level: absence is the correct representation.
- Write one plain sentence with numbers and units. No superlatives (the claims test rejects "100% uptime", "enterprise-grade", "complete protection" and similar).
- `npm test` validates every entry (`tests/content/claims.test.ts`); `npm run build` then regenerates the guides and both llms files.

Facts that belong on a product page (for example "this plan family uses CPU X") should be added here first and shown from here, so one source feeds the pages, the API descriptions and the llms files.

## Also needed from the owner (not part of the facts registry)

- Legal entity name, address and contact details for `Organization` markup and an About/legal page.
- Confirmation of the BILLmanager anomalies listed in the README (6 mispriced EUR plans, plan 176811, `os_price` meaning, vCPU of plan 173591).
- One real test order to verify the configurator prefill before `ORDER_ADDON_PARAMS=on`.
