# Launch checklist

Everything here is either **verified** (how is stated), **needs someone with access** (staging, DNS, CDN, Redis,
Search Console), or **needs the owner** (facts, legal text, brand assets). Nothing is marked done that was not run.

## 0. What is and is not verified

| Area | State | How |
|---|---|---|
| Unit, API, security, page-render tests | verified | `npm test` (about 280 tests) |
| Build output (SEO, JSON-LD, prices, CSP compatibility, performance budgets) | verified | `npm run build && npm run test:ssr` |
| CSP, security headers, CORS on public data | verified on a real production server | response headers read over HTTP; page hydrated and the configurator worked in a browser with no console errors |
| Replica coordination (announce on A, B follows; boot reconciliation) | verified with real production servers | `npm run check:replicas` against an in-memory stand-in for Redis |
| Lighthouse (mobile profile, local server) | verified once | performance 97-99, accessibility 100, best practices 100, SEO 100, CLS 0, LCP 1.6-2.0 s. A local server has no network latency and no CDN: treat as a regression baseline, not a field result |
| **Real Redis** (the Redis classes and the stream log against a real server) | **not verified** | no Redis or Docker on the development machine. Run `REDIS_URL=redis://<throwaway> npm run check:replicas` (section 2) |
| **Docker image** | **not verified** | not built here. Section 3 |
| **CDN behaviour, real client IPs behind the proxy** | **not verified** | section 4 |
| **Google Rich Results Test, Search Console, Core Web Vitals field data** | **not verified** | need the public site (section 5) |
| **Order prefill (`ORDER_ADDON_PARAMS=on`)** | **not verified, off** | needs one real test order (README) |
| Effect on AI-assistant citations | **unmeasurable before launch** | nothing guarantees citation or recommendation |

## 1. Environment

The process refuses to start in production when a required value is missing, and lists every problem at once.

| Variable | Production | Notes |
|---|---|---|
| `REDIS_URL` | required | dedicated instance or logical DB; `rediss://` with auth if it crosses a network |
| `REVALIDATE_HMAC_SECRET` | required, at least 32 chars | `openssl rand -hex 32`. Signs internal requests, **including the replica's own background revalidation** (without it a replica cannot refresh its page cache after a sync) |
| `SITE_URL` | required, `https://...` | canonical URLs, sitemap, JSON-LD. Pick the apex or `www` once; the other must 301 to it |
| `TRUSTED_PROXY_HOPS` | set to the real number | proxies in front of the app that each append to `X-Forwarded-For` (CDN + load balancer = 2). Too low: everyone behind the proxy shares one rate-limit bucket. Too high: a client can pick its own bucket |
| `SYNC_SCHEDULER` | default on | every replica may run it (Redis lock, one wins). `off` when an external scheduler calls `POST /api/internal/sync` |
| `INTERNAL_BASE_URL` | optional | where a replica reaches its own server; default `http://127.0.0.1:$PORT` |
| `ORDER_ADDON_PARAMS` | `off` | until the real test order succeeds |
| `ALLOW_FILE_STORE` | **never** | local smoke tests of a production build only |

## 2. Redis

- `maxmemory-policy noeviction`. An evicting policy can delete the live snapshot or the sync lock. Memory use is about
  2 MB for the snapshot plus a few KB of rate-limit and nonce keys.
- Persistence is optional: after a restart with an empty Redis the first sync (a few minutes) rebuilds everything, and
  already-rendered pages keep being served meanwhile. The live snapshot has **no expiry** (fixed in Phase 7; it used to
  expire after 7 days of failed syncs).
- Verify the Redis code paths against the real server, once, on a throwaway instance (the script writes the project's
  real keys `gcore:catalog:*` and `gcore:revalidation`; never point it at production):

```bash
npm run build
REDIS_URL=redis://localhost:6379 npm run check:replicas
```

  Expected: 10 of 10 checks. If a check fails, the Redis stand-in and the real server disagree somewhere, and the
  failing step names it.

## 3. Container

- `docker compose up --build` starts Redis and two replicas (`web` on 3000, `web2` on 3001). `REVALIDATE_HMAC_SECRET`
  must be in the shell. **This has not been run.**
- The image build needs network access: `prebuild` fetches the live catalog so that pages can be pre-rendered.
- The runtime user is not root, but `.next` must be writable: ISR writes regenerated pages there. Do not use a read-only
  root filesystem unless `.next/server` and `.next/cache` are tmpfs or volumes.
- Pin the base images by digest (`node:22-alpine@sha256:...`) once a digest is chosen, and rebuild on security releases.
- `HEALTHCHECK` calls `/api/health`: 200 for `ok` and `stale`, 503 while there is no snapshot.

## 4. Proxy and CDN

1. TLS 1.2+, HTTP to HTTPS redirect. The app already sends HSTS (2 years, `includeSubDomains`). Add `preload` and submit
   the domain only after every subdomain is HTTPS: it is hard to undo.
2. **Honour the origin's cache headers.** HTML is `public, s-maxage=600, stale-while-revalidate=60`; the public API and
   `llms*.txt` are `public, s-maxage=300, stale-while-revalidate=60, stale-if-error=86400`; `/_next/static` is immutable.
   Next's own default for pages was a one-year `stale-while-revalidate`, which a CDN could use to show a price that is
   months old to the first visitor after an idle spell; the explicit header replaces it.
3. **A tag revalidation reaches the origin and every replica, not the CDN.** A CDN keeps its copy until `s-maxage`
   (10 minutes) ends. That is the worst-case page staleness on top of the 10-minute sync interval. If that is too long
   for commercial data, purge by URL after a sync from a hook of your own, or shorten `s-maxage` (the `revalidate`
   literals and `next.config.ts` must change together; `tests/cache/freshness.test.ts` enforces it).
4. Never cache `/api/internal/*` or `/api/health`. Restrict `/api/internal/*` at the edge to the scheduler and operator
   addresses as a second layer (the HMAC and one-time nonce are the first).
5. Overwrite, do not trust, a client-supplied `X-Forwarded-For`: the proxy must append the address it saw, and
   `TRUSTED_PROXY_HOPS` must match.
6. The cache key may ignore `utm_*` and similar parameters. Pages carry `rel=canonical` in the HTML, so a cached clean
   response served for a tracking URL is still canonicalised.
7. Add edge rate limiting or a WAF in front. The app's limiter (120 requests per minute per address on the public API)
   is a backstop, not DDoS protection.

## 5. Search and AI launch

Legacy inventory of `gcore.hosting`, read on 2026-11-01:

| URL | Today | Plan |
|---|---|---|
| `/` | one VPS landing page, `noindex, nofollow`, canonical `https://gcore.com/ghost-landing` | replaced; the new pages are indexable |
| `/legal`, `/legal?tab=privacy_policy` | linked from the old page, **return 404** | nothing to preserve; the new site has **no legal pages** (owner, section 6) |
| `/sitemap.xml` | serves **gcore.com's** sitemap index | replaced by this site's own sitemap |
| `/robots.txt` | `Allow: /` | replaced |
| anything else | 404 | nothing to redirect |

So there are **no indexable legacy URLs and no redirect map to build**. Confirm with the owner: paid or partner links
that point at gcore.hosting (they land on `/`, which is fine), and whether `gcore.com/ghost-landing` should redirect to
this site. When a URL list arrives, add `redirects()` to `next.config.ts`: permanent, one hop, destination present in
the sitemap, no chains.

After DNS points at the new deployment:

1. `curl -sI https://gcore.hosting/vps` shows the CSP and no `X-Robots-Tag` on clean URLs.
2. Search Console (Domain property) and Bing Webmaster: submit `https://gcore.hosting/sitemap.xml`; use URL Inspection on
   the home page, one VPS plan page, one dedicated plan page and one guide.
3. Run Google's Rich Results Test on those pages. Expect `BreadcrumbList` everywhere, `Product` with `Offer` on plan
   pages. `FAQPage` is valid markup on the guides, but Google limits FAQ rich results to a few site types, so do not
   expect one.
4. Watch Search Console coverage for a week: crawl errors, "Duplicate, Google chose different canonical", soft 404s.
5. Check `https://gcore.hosting/llms.txt`, `/llms-full.txt` and `/api/v1/openapi.json` from outside the network.
6. Core Web Vitals field data needs about 28 days of real traffic; until then the Lighthouse numbers above are the only
   evidence.

## 6. Needed from the owner before the site goes public

- Facts for the registry (`docs/OWNER-FACTS.md`): DDoS scope per location, SLA, CPU model and allocation, upstreams,
  data-center operators, support terms. **The old landing page claims "Free CDN & DDoS Protection". The new site does
  not repeat that until it has a source.** Without it, `llms.txt` and the DDoS guide say the topic is not stated.
- Legal pages: Terms of Service and Privacy Policy (or the URLs where they live) for the footer. The old page linked to
  `/legal`; a commerce site should not launch without them.
- Legal entity name, address and contact details (`Organization` markup, About page).
- Brand assets: the header logo and `src/app/icon.svg` now use the Gcore wordmark and "G" mark as served on the live
  gcore.hosting (2026-11-02). Confirm with brand owners that these are the current approved versions, and supply PNG
  touch icons (apple-touch-icon) if wanted.
- BILLmanager anomalies: 6 mispriced EUR plans and plan 176811 (withheld from the site), what `os_price` means, the real
  vCPU of plan 173591.
- One real test order before `ORDER_ADDON_PARAMS=on`.
- ~~A decision on the CDN staleness window (section 4, item 3).~~ Decided 2026-11-01: keep 10 minutes (`s-maxage=600`),
  so a price can be up to about 20 minutes old counting the sync interval. Revisit only if the CDN supports purge-by-URL.

## 7. Monitoring

- Uptime check on `/api/health`: alert on 503, and on `stale` for more than 15 minutes.
- Alert on these log messages (JSON logs, `msg` field): `sync failed`, `sync rejected`,
  `revalidation not propagated to other replicas`, `could not revalidate this replica yet`,
  `boot reconciliation will be retried`, `scheduled sync crashed`. The last three repeating means a replica cannot reach
  its own server or Redis.
- `lastSyncFailed: true` in `/api/health` means the last sync did not publish: pages keep the previous good data.

## 8. Staging run-through (about 30 minutes)

1. Deploy two replicas and Redis with the section 1 variables. Both must start; a missing variable stops the process
   with a list.
2. `curl https://staging/api/health` returns `ok` after the first sync.
3. `REDIS_URL=<throwaway> npm run check:replicas` passes 10 of 10 (section 2).
4. Compare a plan's price on the page, in `/api/v1/plans/{id}`, in `/llms-full.txt` and on the BILLmanager order page.
5. Rate limit: 130 requests in a minute to `/api/v1/plans` from one address gives 429 from request 121; from a second
   address, none. Repeat with a forged `X-Forwarded-For` to confirm it changes nothing.
6. `POST /api/internal/revalidate` unsigned returns 401; signed with `scope: "local"` revalidates one replica only.
7. Stop Redis for a minute: pages keep serving, `/api/health` and the API report the failure, no crash loop. Start it again
   and the replicas recover without a restart.
8. Run Lighthouse against staging through the CDN and compare with section 0.

## 9. Rollback

Redeploy the previous image. The snapshot in Redis stays live. If the previous image expects another `CATALOG_SCHEMA`,
its first sync refetches all BILLmanager detail (a few minutes) and its boot reconciliation revalidates every page once.
